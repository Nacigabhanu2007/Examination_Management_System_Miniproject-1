-- =============================================================================
-- COLLEGE EXAMINATION MANAGEMENT SYSTEM (EMS)
-- COMPLETE DATABASE CREATION & MODIFICATION SQL SCRIPT
-- =============================================================================
-- Database Management System: MySQL 8.0+
-- Application Platform: Java SE 21 / Java Swing / JDBC
-- Target Database: examination_management
--
-- This script contains all actual SQL queries used to create, alter, and configure
-- the Examination Management System database from the inception of the project
-- to its final production-ready state.
--
-- Table Creation Order (Respecting Foreign Key Dependencies):
--   1. department
--   2. subject               (FK -> department)
--   3. exam                  (FK -> subject)
--   4. student               (Initial schema + ALTER additions)
--   5. faculty               (Initial schema + ALTER additions)
--   6. users
--   7. examregistration
--   8. hall
--   9. staff_allocation      (FK -> faculty)
--  10. hall_seat_allocation  (FK -> hall, student)
--  11. marks                 (FK -> student, subject)
--  12. results               (FK -> student)
-- =============================================================================

-- =============================================================================
-- PART 1: DATABASE INITIALIZATION
-- =============================================================================
CREATE DATABASE IF NOT EXISTS `examination_management`
CHARACTER SET utf8mb4
COLLATE utf8mb4_0900_ai_ci;

USE `examination_management`;

-- =============================================================================
-- PART 2: INITIAL CORE TABLES (CREATED AT PROJECT INCEPTION)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. Table: department
-- Purpose: Academic departments offering degree courses and subjects
-- -----------------------------------------------------------------------------
-- [Reconstructed from existing table structure]
CREATE TABLE IF NOT EXISTS `department` (
  `department_id` VARCHAR(20) NOT NULL,
  `department_name` VARCHAR(100) NOT NULL,
  `hod` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 2. Table: subject
-- Purpose: Curriculum subjects and course codes mapped to departments
-- -----------------------------------------------------------------------------
-- [Reconstructed from existing table structure]
CREATE TABLE IF NOT EXISTS `subject` (
  `subject_id` VARCHAR(20) NOT NULL,
  `subject_name` VARCHAR(100) NOT NULL,
  `department_id` VARCHAR(20) DEFAULT NULL,
  `semester` INT DEFAULT NULL,
  `credits` DECIMAL(2,1) DEFAULT NULL,
  PRIMARY KEY (`subject_id`),
  KEY `department_id` (`department_id`),
  CONSTRAINT `subject_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 3. Table: exam
-- Purpose: Examination schedules, sessions, time slots, and maximum marks
-- -----------------------------------------------------------------------------
-- [Reconstructed from existing table structure]
CREATE TABLE IF NOT EXISTS `exam` (
  `exam_number` INT NOT NULL AUTO_INCREMENT,
  `exam_id` VARCHAR(20) DEFAULT NULL,
  `subject_id` VARCHAR(20) NOT NULL,
  `exam_name` VARCHAR(100) NOT NULL,
  `exam_date` DATE DEFAULT NULL,
  `start_time` TIME DEFAULT NULL,
  `end_time` TIME DEFAULT NULL,
  `total_marks` INT DEFAULT NULL,
  `exam_type` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`exam_number`),
  UNIQUE KEY `exam_id` (`exam_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `exam_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 4. Table: student (Initial Version at Project Beginning)
-- Purpose: Core student demographic and enrollment registry
-- -----------------------------------------------------------------------------
-- [Reconstructed from existing table structure prior to ALTER modifications]
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` VARCHAR(20) NOT NULL,
  `student_name` VARCHAR(100) NOT NULL,
  `department` VARCHAR(50) DEFAULT NULL,
  `year` INT DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `phone` VARCHAR(15) DEFAULT NULL,
  `roll_number` VARCHAR(20) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `gender` VARCHAR(20) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 5. Table: faculty (Initial Version at Project Beginning)
-- Purpose: Teaching staff and academic invigilators
-- -----------------------------------------------------------------------------
-- [Reconstructed from existing table structure prior to ALTER modifications]
CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` INT NOT NULL AUTO_INCREMENT,
  `faculty_name` VARCHAR(100) NOT NULL,
  `department` VARCHAR(50) DEFAULT NULL,
  `email` VARCHAR(100) DEFAULT NULL,
  `phone` VARCHAR(15) DEFAULT NULL,
  `address` VARCHAR(255) DEFAULT NULL,
  `gender` VARCHAR(20) DEFAULT NULL,
  `designation` VARCHAR(50) DEFAULT NULL,
  `qualification` VARCHAR(100) DEFAULT NULL,
  `specialization` VARCHAR(100) DEFAULT NULL,
  `experience` INT DEFAULT NULL,
  PRIMARY KEY (`faculty_id`)
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 6. Table: users
-- Purpose: Unified authentication credentials and role authorization (Admin, Faculty, Student)
-- -----------------------------------------------------------------------------
-- [Reconstructed from existing table structure]
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 7. Table: examregistration
-- Purpose: Student registrations for scheduled examination sessions
-- -----------------------------------------------------------------------------
-- [Reconstructed from existing table structure]
CREATE TABLE IF NOT EXISTS `examregistration` (
  `registrationId` INT NOT NULL AUTO_INCREMENT,
  `studentId` VARCHAR(20) NOT NULL,
  `studentName` VARCHAR(100) NOT NULL,
  `department` VARCHAR(100) DEFAULT NULL,
  `year` VARCHAR(20) NOT NULL,
  `examId` VARCHAR(20) NOT NULL,
  `examName` VARCHAR(100) NOT NULL,
  `subjectId` VARCHAR(20) NOT NULL,
  `registrationDate` DATE NOT NULL,
  `status` VARCHAR(20) DEFAULT 'Registered',
  PRIMARY KEY (`registrationId`)
) ENGINE=InnoDB AUTO_INCREMENT=100001 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- =============================================================================
-- PART 3: SCHEMA MODIFICATIONS & EXTENSIONS (ALTER TABLE QUERIES)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 8. ALTER TABLE: student
-- Purpose: Extended student table with full personal, address, and academic fields
-- Date of Execution: Project Phase 2 (Student Registration & Profile Module)
-- -----------------------------------------------------------------------------
-- [Original query executed in project history]
ALTER TABLE `student`
  ADD COLUMN `dob` DATE NULL,
  ADD COLUMN `blood_group` VARCHAR(10) NULL,
  ADD COLUMN `alt_phone` VARCHAR(15) NULL,
  ADD COLUMN `city` VARCHAR(50) NULL,
  ADD COLUMN `state` VARCHAR(50) NULL,
  ADD COLUMN `pincode` VARCHAR(10) NULL,
  ADD COLUMN `degree` VARCHAR(50) NULL,
  ADD COLUMN `admission_year` INT NULL,
  ADD COLUMN `semester` VARCHAR(20) NULL,
  ADD COLUMN `register_number` VARCHAR(30) NULL;

-- -----------------------------------------------------------------------------
-- 9. ALTER TABLE: faculty
-- Purpose: Extended faculty table with professional identifiers and contact details
-- Date of Execution: Project Phase 2 (Faculty Registration & Profile Module)
-- -----------------------------------------------------------------------------
-- [Original query executed in project history]
ALTER TABLE `faculty`
  ADD COLUMN `employee_id` VARCHAR(30) NULL,
  ADD COLUMN `dob` DATE NULL,
  ADD COLUMN `alt_phone` VARCHAR(15) NULL,
  ADD COLUMN `city` VARCHAR(50) NULL,
  ADD COLUMN `state` VARCHAR(50) NULL,
  ADD COLUMN `pincode` VARCHAR(10) NULL,
  ADD COLUMN `date_of_joining` DATE NULL;

-- =============================================================================
-- PART 4: EXAMINATION LIFECYCLE TABLES (CREATED DURING PROJECT COMPLETION)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 10. Table: hall
-- Purpose: Physical examination halls with defined seating capacity limits
-- -----------------------------------------------------------------------------
-- [Original query executed in project history]
CREATE TABLE IF NOT EXISTS `hall` (
  `hall_number` VARCHAR(20) NOT NULL,
  `hall_name` VARCHAR(100) NOT NULL,
  `capacity` INT NOT NULL,
  PRIMARY KEY (`hall_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 11. Table: staff_allocation
-- Purpose: Assign faculty members to examination invigilation duties
-- Constraint: unique_faculty_slot prevents assigning faculty to two halls at the same time
-- -----------------------------------------------------------------------------
-- [Original query executed in project history]
CREATE TABLE IF NOT EXISTS `staff_allocation` (
  `allocation_id` INT NOT NULL AUTO_INCREMENT,
  `exam_id` VARCHAR(20) NOT NULL,
  `faculty_id` INT NOT NULL,
  `duty_date` DATE NOT NULL,
  `session_time` VARCHAR(50) NOT NULL,
  `hall_number` VARCHAR(20) NOT NULL,
  `duty_role` VARCHAR(50) DEFAULT 'Hall Invigilator',
  PRIMARY KEY (`allocation_id`),
  UNIQUE KEY `unique_faculty_slot` (`faculty_id`, `duty_date`, `session_time`),
  CONSTRAINT `fk_staff_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 12. Table: hall_seat_allocation
-- Purpose: Allot student candidates to specific exam halls and numbered seats
-- Constraints:
--   - unique_exam_seat: Prevents assigning two students to the same seat in the same exam
--   - unique_student_exam: Ensures a student is only allocated one seat per exam session
-- -----------------------------------------------------------------------------
-- [Original query executed in project history]
CREATE TABLE IF NOT EXISTS `hall_seat_allocation` (
  `allocation_id` INT NOT NULL AUTO_INCREMENT,
  `exam_id` VARCHAR(20) NOT NULL,
  `student_id` VARCHAR(20) NOT NULL,
  `hall_number` VARCHAR(20) NOT NULL,
  `seat_number` VARCHAR(20) NOT NULL,
  `allocated_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`allocation_id`),
  UNIQUE KEY `unique_exam_seat` (`exam_id`, `hall_number`, `seat_number`),
  UNIQUE KEY `unique_student_exam` (`exam_id`, `student_id`),
  KEY `fk_hsa_student` (`student_id`),
  KEY `fk_hsa_hall` (`hall_number`),
  CONSTRAINT `fk_hsa_hall` FOREIGN KEY (`hall_number`) REFERENCES `hall` (`hall_number`) ON DELETE CASCADE,
  CONSTRAINT `fk_hsa_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 13. Table: marks
-- Purpose: Evaluated marks obtained by students in exams
-- Constraint: unique_exam_student_sub ensures one mark entry per candidate per subject
-- -----------------------------------------------------------------------------
-- [Original query executed in project history]
CREATE TABLE IF NOT EXISTS `marks` (
  `mark_id` INT NOT NULL AUTO_INCREMENT,
  `exam_id` VARCHAR(20) NOT NULL,
  `student_id` VARCHAR(20) NOT NULL,
  `subject_id` VARCHAR(20) NOT NULL,
  `marks_obtained` DOUBLE NOT NULL,
  `max_marks` DOUBLE NOT NULL DEFAULT '100',
  `remarks` VARCHAR(255) DEFAULT NULL,
  `entered_by` VARCHAR(100) DEFAULT NULL,
  PRIMARY KEY (`mark_id`),
  UNIQUE KEY `unique_exam_student_sub` (`exam_id`, `student_id`, `subject_id`),
  KEY `fk_marks_student` (`student_id`),
  KEY `fk_marks_subject` (`subject_id`),
  CONSTRAINT `fk_marks_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_marks_subject` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- -----------------------------------------------------------------------------
-- 14. Table: results
-- Purpose: Official published results, aggregated percentages, grades, and pass/fail status
-- Constraint: unique_exam_student_res ensures one overall result entry per candidate per exam
-- -----------------------------------------------------------------------------
-- [Original query executed in project history]
CREATE TABLE IF NOT EXISTS `results` (
  `result_id` INT NOT NULL AUTO_INCREMENT,
  `exam_id` VARCHAR(20) NOT NULL,
  `student_id` VARCHAR(20) NOT NULL,
  `total_marks` DOUBLE NOT NULL,
  `max_total_marks` DOUBLE NOT NULL,
  `percentage` DOUBLE NOT NULL,
  `grade` VARCHAR(5) NOT NULL,
  `status` VARCHAR(20) NOT NULL,
  `generated_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`result_id`),
  UNIQUE KEY `unique_exam_student_res` (`exam_id`, `student_id`),
  KEY `fk_res_student` (`student_id`),
  CONSTRAINT `fk_res_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- =============================================================================
-- PART 5: CORE INITIAL SEED DATA
-- =============================================================================

-- Default Administrator User (Password: Admin@123 hashed via SHA-256)
INSERT IGNORE INTO `users` (`user_id`, `username`, `email`, `password_hash`, `role`) VALUES
(1, 'admin', 'admin@ems.edu', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Admin');

-- Academic Departments
INSERT IGNORE INTO `department` (`department_id`, `department_name`, `hod`) VALUES
('AR1867', 'Artificial Intelligence and Data Science', 'Dr. A. Murugan'),
('BI1840', 'BioMedical Engineeing', 'Dr. S. Kavitha'),
('BI4562', 'Biotechnology', 'Dr. M. Geetha'),
('CE9261', 'Civil Engineering', 'Dr. V. Rajesh'),
('CS5496', 'Computer Science and Engineering', 'Dr. K. Ramanathan'),
('EC7323', 'Electronic and Communication Engineering', 'Dr. S. Meenakshi'),
('EE3594', 'Electrical and Electronic Engineering', 'Dr. M. Soundararajan'),
('IT2257', 'Information Technology', 'Dr. P. Vigneswaran'),
('ME6547', 'Mechanical Engineering', 'Dr. R. Chandrasekaran');

-- Examination Halls
INSERT IGNORE INTO `hall` (`hall_number`, `hall_name`, `capacity`) VALUES
('AUD-01', 'University Auditorium', 100),
('HALL-101', 'Main Block - Hall 101', 30),
('HALL-102', 'Main Block - Hall 102', 30),
('HALL-201', 'Science Block - Hall 201', 40),
('HALL-202', 'Science Block - Hall 202', 40);

-- =============================================================================
-- END OF SCRIPT
-- Verification: Matches all 12 tables in MySQL 'examination_management' database
-- =============================================================================
