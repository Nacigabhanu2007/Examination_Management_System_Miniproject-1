package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Modern, Professional Admin Dashboard
 * Direct access to all 12 modules with real-time database metrics.
 * Completely self-contained with no external UI dependencies.
 */
public class AdminDashboard extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);

    private JLabel studentCountLbl;
    private JLabel facultyCountLbl;
    private JLabel subjectCountLbl;
    private JLabel examCountLbl;

    public AdminDashboard() {
        setTitle("Examination Management System - Administrator Portal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 800);
        setMinimumSize(new Dimension(1050, 700));
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // LEFT SIDEBAR
        JPanel sidebar = new JPanel();
        sidebar.setBackground(NAVY);
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(new EmptyBorder(25, 16, 25, 16));

        JLabel logo = new JLabel(" EMS PORTAL");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel(" College Examination System");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(new Color(190, 205, 235));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(25));

        // Navigation Sidebar Buttons
        addSidebarButton(sidebar, "Dashboard");
        addSidebarButton(sidebar, "Student Management");
        addSidebarButton(sidebar, "Faculty Management");
        addSidebarButton(sidebar, "Department Management");
        addSidebarButton(sidebar, "Subject Management");
        addSidebarButton(sidebar, "Exam Management");
        addSidebarButton(sidebar, "Staff Allocation");
        addSidebarButton(sidebar, "Hall & Seat Allocation");
        addSidebarButton(sidebar, "View Registered Students");
        addSidebarButton(sidebar, "Marks & Results");
        addSidebarButton(sidebar, "Admin Settings");

        sidebar.add(Box.createVerticalGlue());

        JButton logoutButton = createDangerButton("Logout");
        logoutButton.setPreferredSize(new Dimension(218, 38));
        logoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        logoutButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        logoutButton.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to log out of the Administrator session?",
                    "Confirm Logout",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (choice == JOptionPane.YES_OPTION) {
                dispose();
                new Login().setVisible(true);
            }
        });

        sidebar.add(logoutButton);
        mainPanel.add(sidebar, BorderLayout.WEST);

        // RIGHT CONTENT PANEL
        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setBackground(BG_LIGHT);
        content.setBorder(new EmptyBorder(25, 30, 25, 30));

        // TOP HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel headingPanel = new JPanel();
        headingPanel.setOpaque(false);
        headingPanel.setLayout(new BoxLayout(headingPanel, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("Admin Dashboard");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 28));
        heading.setForeground(NAVY);

        JLabel welcome = new JLabel("Welcome, Administrator! Real-time system status and operational control.");
        welcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        welcome.setForeground(TEXT_MUTED);

        headingPanel.add(heading);
        headingPanel.add(Box.createVerticalStrut(6));
        headingPanel.add(welcome);

        JLabel adminBadge = new JLabel(" SYSTEM ADMIN ");
        adminBadge.setOpaque(true);
        adminBadge.setBackground(new Color(224, 238, 255));
        adminBadge.setForeground(PRIMARY_BLUE);
        adminBadge.setFont(new Font("Segoe UI", Font.BOLD, 13));
        adminBadge.setBorder(new EmptyBorder(8, 14, 8, 14));

        header.add(headingPanel, BorderLayout.WEST);
        header.add(adminBadge, BorderLayout.EAST);
        content.add(header, BorderLayout.NORTH);

        // MAIN BODY CONTAINER
        JPanel bodyContainer = new JPanel();
        bodyContainer.setLayout(new BoxLayout(bodyContainer, BoxLayout.Y_AXIS));
        bodyContainer.setOpaque(false);

        // REAL-TIME SUMMARY STATS CARDS
        JPanel summaryPanel = new JPanel(new GridLayout(1, 4, 18, 0));
        summaryPanel.setOpaque(false);

        studentCountLbl = new JLabel("0", SwingConstants.LEFT);
        facultyCountLbl = new JLabel("0", SwingConstants.LEFT);
        subjectCountLbl = new JLabel("0", SwingConstants.LEFT);
        examCountLbl = new JLabel("0", SwingConstants.LEFT);

        summaryPanel.add(createSummaryCard("TOTAL STUDENTS", studentCountLbl, "Enrolled Scholars", new Color(30, 64, 124)));
        summaryPanel.add(createSummaryCard("TOTAL FACULTY", facultyCountLbl, "Teaching Staff", new Color(109, 40, 217)));
        summaryPanel.add(createSummaryCard("TOTAL SUBJECTS", subjectCountLbl, "Active Courses", new Color(13, 148, 136)));
        summaryPanel.add(createSummaryCard("EXAMINATIONS", examCountLbl, "Scheduled Exams", new Color(217, 119, 6)));

        bodyContainer.add(summaryPanel);
        bodyContainer.add(Box.createVerticalStrut(25));

        // QUICK ACCESS MODULES GRID
        JPanel centerPanel = new JPanel(new BorderLayout(0, 12));
        centerPanel.setOpaque(false);

        JLabel quickTitle = new JLabel("System Modules & Operations");
        quickTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        quickTitle.setForeground(TEXT_DARK);

        JLabel quickSubtitle = new JLabel("Select an operation module to configure, monitor or allocate examination activities.");
        quickSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        quickSubtitle.setForeground(TEXT_MUTED);

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(quickTitle);
        titlePanel.add(Box.createVerticalStrut(4));
        titlePanel.add(quickSubtitle);

        JPanel buttonGrid = new JPanel(new GridLayout(0, 3, 16, 16));
        buttonGrid.setOpaque(false);

        addModuleCard(buttonGrid, "Student Management", "Add, search, update and manage student profiles.", new Color(30, 64, 124));
        addModuleCard(buttonGrid, "Faculty Management", "Maintain faculty members, credentials and designations.", new Color(109, 40, 217));
        addModuleCard(buttonGrid, "Department Management", "Configure academic departments and branches.", new Color(13, 148, 136));
        addModuleCard(buttonGrid, "Subject Management", "Manage course codes, credits and department mappings.", new Color(217, 119, 6));
        addModuleCard(buttonGrid, "Exam Management", "Schedule dates, times, and exam sessions.", new Color(225, 29, 72));
        addModuleCard(buttonGrid, "Staff Allocation", "Assign faculty invigilators to scheduled exams.", new Color(2, 132, 199));
        addModuleCard(buttonGrid, "Hall & Seat Allocation", "Auto-assign students to examination halls and seats.", new Color(71, 85, 105));
        addModuleCard(buttonGrid, "View Registered Students", "Review and audit all student exam registrations.", new Color(22, 101, 52));
        addModuleCard(buttonGrid, "Marks & Results", "Evaluate student marks, calculate grades and publish results.", new Color(194, 65, 12));
        addModuleCard(buttonGrid, "Admin Settings", "Configure academic year, semester and system preferences.", new Color(82, 82, 91));

        centerPanel.add(titlePanel, BorderLayout.NORTH);
        centerPanel.add(buttonGrid, BorderLayout.CENTER);
        bodyContainer.add(centerPanel);

        JScrollPane scrollPane = new JScrollPane(bodyContainer);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        content.add(scrollPane, BorderLayout.CENTER);

        // FOOTER
        JLabel footer = new JLabel("College Examination Management System • Java SE 21 & MySQL • Production Ready", SwingConstants.CENTER);
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        footer.setForeground(TEXT_MUTED);
        content.add(footer, BorderLayout.SOUTH);

        mainPanel.add(content, BorderLayout.CENTER);

        setContentPane(mainPanel);
        loadLiveMetrics();
        setVisible(true);
    }

    private void addSidebarButton(JPanel sidebar, String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(new Color(226, 232, 240));
        button.setBackground(new Color(30, 48, 86));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(218, 38));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(new EmptyBorder(8, 14, 8, 14));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(PRIMARY_BLUE);
                button.setForeground(Color.WHITE);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(30, 48, 86));
                button.setForeground(new Color(226, 232, 240));
            }
        });

        button.addActionListener(e -> openModule(text));
        sidebar.add(button);
        sidebar.add(Box.createVerticalStrut(5));
    }

    private JButton createDangerButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(DANGER_RED);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(DANGER_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(DANGER_RED);
            }
        });
        return btn;
    }

    private void openModule(String moduleName) {
        switch (moduleName) {
            case "Student Management":
                new AdminStudentManagement().setVisible(true);
                break;
            case "Faculty Management":
                new AdminFacultyManagement().setVisible(true);
                break;
            case "Department Management":
                new AdminDepartmentManagement().setVisible(true);
                break;
            case "Subject Management":
                new AdminSubjectManagement().setVisible(true);
                break;
            case "Exam Management":
                new AdminExamManagement().setVisible(true);
                break;
            case "Staff Allocation":
                new AdminStaffAllocation().setVisible(true);
                break;
            case "Hall & Seat Allocation":
                new AdminHallSeatAllocation().setVisible(true);
                break;
            case "View Registered Students":
            case "View Registered":
            case "View Exam Registrations":
            case "Exam Registration":
                new ExamRegistration().setVisible(true);
                break;
            case "Marks & Results":
                new AdminMarksResults().setVisible(true);
                break;
            case "Admin Settings":
            case "Settings":
                new AdminSettings().setVisible(true);
                break;
            case "Dashboard":
                loadLiveMetrics();
                JOptionPane.showMessageDialog(this, "Dashboard metrics refreshed successfully!");
                break;
            default:
                JOptionPane.showMessageDialog(this, "Module " + moduleName + " selected.");
                break;
        }
    }

    private JPanel createSummaryCard(String title, JLabel countLbl, String description, Color accent) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_COLOR, 1),
                        new EmptyBorder(14, 16, 14, 16)
                )
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLabel.setForeground(TEXT_MUTED);

        countLbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
        countLbl.setForeground(accent);

        JLabel descLabel = new JLabel(description);
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(TEXT_MUTED);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(countLbl);
        card.add(Box.createVerticalStrut(4));
        card.add(descLabel);

        return card;
    }

    private void addModuleCard(JPanel grid, String title, String description, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(color);

        JLabel descLabel = new JLabel("<html>" + description + "</html>");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(TEXT_MUTED);

        JButton openBtn = new JButton("Open Module");
        openBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        openBtn.setForeground(Color.WHITE);
        openBtn.setBackground(PRIMARY_BLUE);
        openBtn.setFocusPainted(false);
        openBtn.setBorderPainted(false);
        openBtn.setOpaque(true);
        openBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        openBtn.setPreferredSize(new Dimension(120, 32));

        openBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                openBtn.setBackground(PRIMARY_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                openBtn.setBackground(PRIMARY_BLUE);
            }
        });

        openBtn.addActionListener(e -> openModule(title));

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(descLabel, BorderLayout.CENTER);
        card.add(openBtn, BorderLayout.SOUTH);

        grid.add(card);
    }

    private void loadLiveMetrics() {
        new Thread(() -> {
            int students = fetchCount("SELECT COUNT(*) FROM student");
            int faculty = fetchCount("SELECT COUNT(*) FROM faculty");
            int subjects = fetchCount("SELECT COUNT(*) FROM subject");
            int exams = fetchCount("SELECT COUNT(*) FROM exam");

            SwingUtilities.invokeLater(() -> {
                studentCountLbl.setText(String.valueOf(students));
                facultyCountLbl.setText(String.valueOf(faculty));
                subjectCountLbl.setText(String.valueOf(subjects));
                examCountLbl.setText(String.valueOf(exams));
            });
        }).start();
    }

    private int fetchCount(String sql) {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception ignored) {}
        return 0;
    }
}
