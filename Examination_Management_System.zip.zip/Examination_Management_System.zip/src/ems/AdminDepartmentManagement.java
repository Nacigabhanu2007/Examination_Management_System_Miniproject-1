package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.Random;

public class AdminDepartmentManagement extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTable table;
    private DefaultTableModel model;

    private JTextField idField;
    private JTextField nameField;
    private JTextField hodField;

    private final Random random = new Random();

    public AdminDepartmentManagement() {
        setTitle("Examination Management System - Department Management");
        setSize(1150, 720);
        setMinimumSize(new Dimension(950, 620));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "DEPARTMENT MANAGEMENT",
                "Configure college academic departments, department codes, and heads of department"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Table
        String[] columns = {
            "Department ID",
            "Department Name",
            "Head of Department (HOD)"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Form & Editor Card
        JPanel formCard = new JPanel(new BorderLayout(0, 12));
        formCard.setBackground(CARD_BG);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(15, 20, 15, 20)
        ));

        JLabel formTitle = new JLabel("Department Information & Setup");
        formTitle.setFont(FONT_HEADER);
        formTitle.setForeground(PRIMARY_BLUE);
        formCard.add(formTitle, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridLayout(1, 3, 15, 10));
        formGrid.setOpaque(false);

        idField = new JTextField();
        idField.setEditable(false);
        idField.setFont(FONT_INPUT);
        idField.setBackground(new Color(241, 245, 249));
        idField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        nameField = new JTextField();
        nameField.setFont(FONT_INPUT);
        nameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        hodField = new JTextField();
        hodField.setFont(FONT_INPUT);
        hodField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        addGridField(formGrid, "Department ID (Auto-generated)", idField);
        addGridField(formGrid, "Department Name", nameField);
        addGridField(formGrid, "Head of Department (HOD)", hodField);

        formCard.add(formGrid, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        buttonPanel.setOpaque(false);

        JButton saveButton = createButton("Save Department", SUCCESS_GREEN, SUCCESS_HOVER);
        JButton searchButton = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton updateButton = createButton("Update", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton deleteButton = createButton("Delete", DANGER_RED, DANGER_HOVER);
        JButton refreshButton = createButton("Refresh / Clear", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backButton = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        buttonPanel.add(backButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(saveButton);

        formCard.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.add(formCard, BorderLayout.SOUTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Events
        loadDepartments();

        saveButton.addActionListener(e -> saveDepartment());
        searchButton.addActionListener(e -> searchDepartment());

        refreshButton.addActionListener(e -> {
            clearFields();
            loadDepartments();
        });

        updateButton.addActionListener(e -> updateDepartment());
        deleteButton.addActionListener(e -> deleteDepartment());
        backButton.addActionListener(e -> dispose());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                idField.setText(valueAt(row, 0));
                nameField.setText(valueAt(row, 1));
                hodField.setText(valueAt(row, 2));
            }
        });
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void addGridField(JPanel panel, String label, JTextField field) {
        JPanel fGroup = new JPanel(new BorderLayout(0, 5));
        fGroup.setOpaque(false);

        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        fGroup.add(lbl, BorderLayout.NORTH);
        fGroup.add(field, BorderLayout.CENTER);
        panel.add(fGroup);
    }

    private String valueAt(int row, int column) {
        Object value = model.getValueAt(row, column);
        return value == null ? "" : value.toString();
    }

    // Generate a prefix from the department name.
    private String getDepartmentPrefix(String departmentName) {
        String name = departmentName.trim().toUpperCase();

        if (name.equals("CSE") || name.contains("COMPUTER SCIENCE")) {
            return "CS";
        }
        if (name.equals("IT") || name.contains("INFORMATION TECHNOLOGY")) {
            return "IT";
        }
        if (name.equals("ECE") || name.contains("ELECTRONIC AND COMMUNICATION")) {
            return "EC";
        }
        if (name.equals("EEE") || name.contains("ELECTRICAL AND ELECTRONIC")) {
            return "EE";
        }
        if (name.equals("MECH") || name.contains("MECHANICAL")) {
            return "ME";
        }
        if (name.equals("CIVIL") || name.contains("CIVIL ENGINEERING")) {
            return "CE";
        }

        // For other department names, use the first two letters.
        String cleaned = name.replaceAll("[^A-Z]", "");

        if (cleaned.length() >= 2) {
            return cleaned.substring(0, 2);
        }
        if (cleaned.length() == 1) {
            return cleaned + "X";
        }
        return "DP";
    }

    // Generate a random ID and check the database for duplicates.
    private String generateDepartmentId(Connection con, String departmentName) throws SQLException {
        String prefix = getDepartmentPrefix(departmentName);
        String checkSql = "SELECT COUNT(*) FROM department WHERE department_id = ?";

        for (int attempt = 0; attempt < 100; attempt++) {
            int number = 1000 + random.nextInt(9000);
            String generatedId = prefix + number;

            try (PreparedStatement ps = con.prepareStatement(checkSql)) {
                ps.setString(1, generatedId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && rs.getInt(1) == 0) {
                        return generatedId;
                    }
                }
            }
        }
        throw new SQLException("Unable to generate a unique Department ID. Try again.");
    }

    // Save department with an automatically generated ID.
    private void saveDepartment() {
        String name = nameField.getText().trim();
        String hod = hodField.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Department Name.");
            return;
        }

        String sql = "INSERT INTO department (department_id, department_name, hod) VALUES (?, ?, ?)";

        try (Connection con = DBConnection.getConnection()) {
            String generatedId = generateDepartmentId(con, name);

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, generatedId);
                ps.setString(2, name);

                if (hod.isEmpty()) {
                    ps.setNull(3, Types.VARCHAR);
                } else {
                    ps.setString(3, hod);
                }

                ps.executeUpdate();
                idField.setText(generatedId);

                JOptionPane.showMessageDialog(this,
                        "Department saved successfully!\nGenerated Department ID: " + generatedId);

                clearFields();
                loadDepartments();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Save failed:\n" + ex.getMessage());
        }
    }

    // Load all departments.
    private void loadDepartments() {
        model.setRowCount(0);

        String sql = "SELECT department_id, department_name, hod FROM department ORDER BY department_name";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("department_id"),
                    rs.getString("department_name"),
                    rs.getString("hod")
                });
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Unable to load departments:\n" + ex.getMessage());
        }
    }

    // Search by Department ID.
    private void searchDepartment() {
        String id = idField.getText().trim();

        if (id.isEmpty()) {
            id = JOptionPane.showInputDialog(this, "Enter Department ID:");
            if (id == null || id.trim().isEmpty()) {
                return;
            }
            id = id.trim();
        }

        String sql = "SELECT department_id, department_name, hod FROM department WHERE department_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                model.setRowCount(0);

                if (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("department_id"),
                        rs.getString("department_name"),
                        rs.getString("hod")
                    });

                    idField.setText(rs.getString("department_id"));
                    nameField.setText(rs.getString("department_name"));
                    hodField.setText(rs.getString("hod"));
                } else {
                    JOptionPane.showMessageDialog(this, "Department not found.");
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search failed:\n" + ex.getMessage());
        }
    }

    // Update department name and HOD.
    private void updateDepartment() {
        String id = idField.getText().trim();
        String name = nameField.getText().trim();
        String hod = hodField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a department from the table first.");
            return;
        }

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Department Name cannot be empty.");
            return;
        }

        String sql = "UPDATE department SET department_name = ?, hod = ? WHERE department_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);

            if (hod.isEmpty()) {
                ps.setNull(2, Types.VARCHAR);
            } else {
                ps.setString(2, hod);
            }

            ps.setString(3, id);

            int result = ps.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Department updated successfully!");
                clearFields();
                loadDepartments();
            } else {
                JOptionPane.showMessageDialog(this, "Department not found.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Update failed:\n" + ex.getMessage());
        }
    }

    // Delete department.
    private void deleteDepartment() {
        String id = idField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a department from the table first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Delete department " + id + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM department WHERE department_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);

            int result = ps.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Department deleted successfully!");
                clearFields();
                loadDepartments();
            } else {
                JOptionPane.showMessageDialog(this, "Department not found.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Delete failed:\n" + ex.getMessage()
                    + "\nCheck whether this department is used by another table.");
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        hodField.setText("");
        table.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AdminDepartmentManagement().setVisible(true);
        });
    }
}
