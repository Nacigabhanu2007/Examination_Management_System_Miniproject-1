package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class AdminExamManagement extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTextField idField, subjectField, nameField;
    private JTextField dateField, startField, endField;
    private JTextField marksField, typeField;
    private JTable table;
    private DefaultTableModel model;

    public AdminExamManagement() {
        setTitle("Examination Management System - Exam Management");
        setSize(1180, 750);
        setMinimumSize(new Dimension(980, 650));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "EXAM MANAGEMENT",
                "Create, schedule, and maintain examination timelines, venues, subjects, and test types"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Table
        String[] columns = {
            "Exam ID", "Subject ID", "Exam Name", "Exam Date", "Start Time", "End Time", "Total Marks", "Exam Type"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Form Card
        JPanel formCard = new JPanel(new BorderLayout(0, 12));
        formCard.setBackground(CARD_BG);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(15, 20, 15, 20)
        ));

        JLabel formTitle = new JLabel("Exam Details & Schedule Settings");
        formTitle.setFont(FONT_HEADER);
        formTitle.setForeground(PRIMARY_BLUE);
        formCard.add(formTitle, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridLayout(2, 4, 12, 10));
        formGrid.setOpaque(false);

        idField = new JTextField();
        idField.setEditable(false);
        idField.setFont(FONT_INPUT);
        idField.setBackground(new Color(241, 245, 249));
        idField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        subjectField = new JTextField();
        subjectField.setFont(FONT_INPUT);
        subjectField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        nameField = new JTextField();
        nameField.setFont(FONT_INPUT);
        nameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        dateField = new JTextField();
        dateField.setFont(FONT_INPUT);
        dateField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        startField = new JTextField();
        startField.setFont(FONT_INPUT);
        startField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        endField = new JTextField();
        endField.setFont(FONT_INPUT);
        endField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        marksField = new JTextField();
        marksField.setFont(FONT_INPUT);
        marksField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        typeField = new JTextField();
        typeField.setFont(FONT_INPUT);
        typeField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        addGridField(formGrid, "Exam ID (Auto)", idField);
        addGridField(formGrid, "Subject ID", subjectField);
        addGridField(formGrid, "Exam Name", nameField);
        addGridField(formGrid, "Exam Date (DD-MM-YYYY)", dateField);

        addGridField(formGrid, "Start Time (HH:MM:SS)", startField);
        addGridField(formGrid, "End Time (HH:MM:SS)", endField);
        addGridField(formGrid, "Total Marks", marksField);
        addGridField(formGrid, "Exam Type (Theory/Practical)", typeField);

        formCard.add(formGrid, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        buttonPanel.setOpaque(false);

        JButton saveButton = createButton("Save Exam", SUCCESS_GREEN, SUCCESS_HOVER);
        JButton searchButton = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton updateButton = createButton("Update", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton deleteButton = createButton("Delete", DANGER_RED, DANGER_HOVER);
        JButton refreshButton = createButton("Refresh / Clear", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backButton = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        buttonPanel.add(backButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(saveButton);

        formCard.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.add(formCard, BorderLayout.SOUTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Events
        saveButton.addActionListener(e -> saveExam());
        searchButton.addActionListener(e -> searchExam());
        refreshButton.addActionListener(e -> {
            clearFields();
            loadExams();
            generateExamId();
        });
        updateButton.addActionListener(e -> updateExam());
        deleteButton.addActionListener(e -> deleteExam());
        backButton.addActionListener(e -> dispose());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                idField.setText(model.getValueAt(row, 0).toString());
                subjectField.setText(model.getValueAt(row, 1).toString());
                nameField.setText(model.getValueAt(row, 2).toString());
                dateField.setText(model.getValueAt(row, 3) != null ? model.getValueAt(row, 3).toString() : "");
                startField.setText(model.getValueAt(row, 4) != null ? model.getValueAt(row, 4).toString() : "");
                endField.setText(model.getValueAt(row, 5) != null ? model.getValueAt(row, 5).toString() : "");
                marksField.setText(model.getValueAt(row, 6) != null ? model.getValueAt(row, 6).toString() : "");
                typeField.setText(model.getValueAt(row, 7) != null ? model.getValueAt(row, 7).toString() : "");
            }
        });

        loadExams();
        generateExamId();
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void addGridField(JPanel panel, String label, JTextField field) {
        JPanel fGroup = new JPanel(new BorderLayout(0, 5));
        fGroup.setOpaque(false);

        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        fGroup.add(lbl, BorderLayout.NORTH);
        fGroup.add(field, BorderLayout.CENTER);
        panel.add(fGroup);
    }

    private void generateExamId() {
        String sql = "SELECT MAX(exam_number) AS max_number FROM Exam";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            int nextNumber = 1;
            if (rs.next()) {
                nextNumber = rs.getInt("max_number") + 1;
            }
            idField.setText(String.format("EXAM%03d", nextNumber));

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Unable to generate Exam ID:\n" + ex.getMessage());
        }
    }

    private void loadExams() {
        model.setRowCount(0);

        String sql = "SELECT exam_id, subject_id, exam_name, exam_date, start_time, end_time, total_marks, exam_type FROM Exam";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("exam_id"),
                    rs.getString("subject_id"),
                    rs.getString("exam_name"),
                    rs.getObject("exam_date"),
                    rs.getObject("start_time"),
                    rs.getObject("end_time"),
                    rs.getObject("total_marks"),
                    rs.getString("exam_type")
                });
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Unable to load exams:\n" + ex.getMessage());
        }
    }

    private void saveExam() {
        String id = idField.getText().trim();
        String subject = subjectField.getText().trim();
        String name = nameField.getText().trim();
        String date = dateField.getText().trim();
        String start = startField.getText().trim();
        String end = endField.getText().trim();
        String marks = marksField.getText().trim();
        String type = typeField.getText().trim();

        if (subject.isEmpty() || name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Subject ID and Exam Name are required.");
            return;
        }

        String sql = "INSERT INTO Exam (exam_id, subject_id, exam_name, exam_date, start_time, end_time, total_marks, exam_type) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ps.setString(2, subject);
            ps.setString(3, name);

            if (date.isEmpty()) {
                ps.setNull(4, Types.DATE);
            } else {
                ps.setDate(4, parseDate(date));
            }

            if (start.isEmpty()) {
                ps.setNull(5, Types.TIME);
            } else {
                ps.setTime(5, Time.valueOf(start));
            }

            if (end.isEmpty()) {
                ps.setNull(6, Types.TIME);
            } else {
                ps.setTime(6, Time.valueOf(end));
            }

            if (marks.isEmpty()) {
                ps.setNull(7, Types.INTEGER);
            } else {
                ps.setInt(7, Integer.parseInt(marks));
            }

            if (type.isEmpty()) {
                ps.setNull(8, Types.VARCHAR);
            } else {
                ps.setString(8, type);
            }

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Exam saved successfully!");
            clearFields();
            loadExams();
            generateExamId();

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    "Check the date, time and marks format.\n"
                    + "Date: DD-MM-YYYY\n"
                    + "Time: HH:MM:SS\n"
                    + "Marks: Numbers only.");

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Save failed:\n" + ex.getMessage());
        }
    }

    private void searchExam() {
        String id = idField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select or enter an Exam ID.");
            return;
        }

        String sql = "SELECT * FROM Exam WHERE exam_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    subjectField.setText(rs.getString("subject_id"));
                    nameField.setText(rs.getString("exam_name"));

                    dateField.setText(rs.getDate("exam_date") == null ? "" : rs.getDate("exam_date").toString());
                    startField.setText(rs.getTime("start_time") == null ? "" : rs.getTime("start_time").toString());
                    endField.setText(rs.getTime("end_time") == null ? "" : rs.getTime("end_time").toString());
                    marksField.setText(rs.getObject("total_marks") == null ? "" : rs.getObject("total_marks").toString());
                    typeField.setText(rs.getString("exam_type") == null ? "" : rs.getString("exam_type"));
                } else {
                    JOptionPane.showMessageDialog(this, "Exam not found.");
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search failed:\n" + ex.getMessage());
        }
    }

    private void updateExam() {
        String id = idField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an exam from the table first.");
            return;
        }

        String sql = "UPDATE Exam SET subject_id=?, exam_name=?, exam_date=?, start_time=?, end_time=?, total_marks=?, exam_type=? WHERE exam_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, subjectField.getText().trim());
            ps.setString(2, nameField.getText().trim());

            String date = dateField.getText().trim();
            String start = startField.getText().trim();
            String end = endField.getText().trim();
            String marks = marksField.getText().trim();
            String type = typeField.getText().trim();

            if (date.isEmpty()) ps.setNull(3, Types.DATE);
            else ps.setDate(3, parseDate(date));

            if (start.isEmpty()) ps.setNull(4, Types.TIME);
            else ps.setTime(4, Time.valueOf(start));

            if (end.isEmpty()) ps.setNull(5, Types.TIME);
            else ps.setTime(5, Time.valueOf(end));

            if (marks.isEmpty()) ps.setNull(6, Types.INTEGER);
            else ps.setInt(6, Integer.parseInt(marks));

            if (type.isEmpty()) ps.setNull(7, Types.VARCHAR);
            else ps.setString(7, type);

            ps.setString(8, id);

            int result = ps.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Exam updated successfully!");
                clearFields();
                loadExams();
                generateExamId();
            } else {
                JOptionPane.showMessageDialog(this, "Exam not found.");
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Check the date, time and marks format.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Update failed:\n" + ex.getMessage());
        }
    }

    private void deleteExam() {
        String id = idField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an exam from the table first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete Exam " + id + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM Exam WHERE exam_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            int result = ps.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Exam deleted successfully!");
                clearFields();
                loadExams();
                generateExamId();
            } else {
                JOptionPane.showMessageDialog(this, "Exam not found.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Delete failed:\n" + ex.getMessage());
        }
    }

    private void clearFields() {
        idField.setText("");
        subjectField.setText("");
        nameField.setText("");
        dateField.setText("");
        startField.setText("");
        endField.setText("");
        marksField.setText("");
        typeField.setText("");
        table.clearSelection();
    }

    private Date parseDate(String dateStr) {
        if (dateStr == null || dateStr.trim().isEmpty()) {
            return null;
        }
        dateStr = dateStr.trim();
        if (dateStr.matches("\\d{2}-\\d{2}-\\d{4}")) {
            String[] parts = dateStr.split("-");
            return Date.valueOf(parts[2] + "-" + parts[1] + "-" + parts[0]);
        }
        return Date.valueOf(dateStr);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminExamManagement().setVisible(true));
    }
}
