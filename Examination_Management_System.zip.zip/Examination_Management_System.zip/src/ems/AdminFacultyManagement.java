package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Modern, Professional Admin Faculty Management
 * Completely self-contained with no external UI dependencies.
 * Allows Admin to Add, View, Search, Update, and Delete Faculty records.
 */
public class AdminFacultyManagement extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTable facultyTable;
    private DefaultTableModel model;

    private JTextField searchField;
    private JTextField idField;
    private JTextField empIdField;
    private JTextField nameField;
    private JComboBox<String> departmentBox;
    private JComboBox<String> designationBox;
    private JComboBox<String> qualificationBox;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField specializationField;
    private JTextField experienceField;

    private int selectedFacultyId = -1;

    public AdminFacultyManagement() {
        setTitle("Examination Management System - Faculty Management");
        setSize(1220, 780);
        setMinimumSize(new Dimension(1000, 680));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "FACULTY MANAGEMENT",
                "Maintain academic staff directories, designations, and exam invigilation allocations"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Search and Toolbar Panel
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(CARD_BG);
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 15, 10, 15)
        ));

        JPanel searchGroup = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchGroup.setOpaque(false);

        JLabel searchLbl = new JLabel("Search (ID / Name / Dept / EmpID):");
        searchLbl.setFont(FONT_LABEL);
        searchGroup.add(searchLbl);

        searchField = new JTextField(20);
        searchField.setFont(FONT_INPUT);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        searchGroup.add(searchField);

        JButton searchButton = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton refreshButton = createButton("Refresh", SECONDARY_GRAY, SECONDARY_HOVER);
        searchGroup.add(searchButton);
        searchGroup.add(refreshButton);

        JPanel actionGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionGroup.setOpaque(false);
        JButton addFacultyBtn = createButton("+ Add New Faculty", SUCCESS_GREEN, SUCCESS_HOVER);
        addFacultyBtn.setPreferredSize(new Dimension(170, 36));
        actionGroup.add(addFacultyBtn);

        topBar.add(searchGroup, BorderLayout.WEST);
        topBar.add(actionGroup, BorderLayout.EAST);
        contentPanel.add(topBar, BorderLayout.NORTH);

        // Table
        String[] columns = {
                "Faculty ID", "Employee ID", "Faculty Name", "Department",
                "Designation", "Qualification", "Email Address", "Phone",
                "Specialization", "Exp (Yrs)"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        facultyTable = new JTable(model);
        styleTable(facultyTable);
        facultyTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(facultyTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Form Edit Card
        JPanel editCard = new JPanel(new BorderLayout(0, 10));
        editCard.setBackground(CARD_BG);
        editCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(15, 20, 15, 20)
        ));

        JLabel editTitle = new JLabel("Selected Faculty Details & Editor");
        editTitle.setFont(FONT_HEADER);
        editTitle.setForeground(PRIMARY_BLUE);
        editCard.add(editTitle, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridLayout(2, 5, 12, 10));
        formGrid.setOpaque(false);

        idField = new JTextField();
        idField.setEditable(false);
        idField.setFont(FONT_INPUT);
        idField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        idField.setBackground(new Color(241, 245, 249));

        empIdField = new JTextField();
        empIdField.setFont(FONT_INPUT);
        empIdField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        nameField = new JTextField();
        nameField.setFont(FONT_INPUT);
        nameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        departmentBox = new JComboBox<>();
        departmentBox.setFont(FONT_INPUT);
        loadDepartments();

        designationBox = new JComboBox<>(new String[]{
                "Professor", "Associate Professor", "Assistant Professor",
                "Lecturer", "Head of Department", "Dean", "Other"
        });
        designationBox.setFont(FONT_INPUT);

        qualificationBox = new JComboBox<>(new String[]{
                "Ph.D.", "M.Tech / M.E.", "M.Sc.", "MCA", "B.Tech / B.E.", "Post-Doctorate", "Other"
        });
        qualificationBox.setFont(FONT_INPUT);

        emailField = new JTextField();
        emailField.setFont(FONT_INPUT);
        emailField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        phoneField = new JTextField();
        phoneField.setFont(FONT_INPUT);
        phoneField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        specializationField = new JTextField();
        specializationField.setFont(FONT_INPUT);
        specializationField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        experienceField = new JTextField();
        experienceField.setFont(FONT_INPUT);
        experienceField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        addGridField(formGrid, "Faculty ID", idField);
        addGridField(formGrid, "Employee ID", empIdField);
        addGridField(formGrid, "Faculty Name", nameField);
        addGridField(formGrid, "Department", departmentBox);
        addGridField(formGrid, "Designation", designationBox);
        addGridField(formGrid, "Qualification", qualificationBox);
        addGridField(formGrid, "Email Address", emailField);
        addGridField(formGrid, "Phone Number", phoneField);
        addGridField(formGrid, "Specialization", specializationField);
        addGridField(formGrid, "Experience (Years)", experienceField);

        editCard.add(formGrid, BorderLayout.CENTER);

        // Buttons
        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 5));
        btnBar.setOpaque(false);

        JButton updateBtn = createButton("Update Faculty", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton deleteBtn = createButton("Delete Faculty", DANGER_RED, DANGER_HOVER);
        JButton clearBtn = createButton("Clear Selection", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backBtn = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        btnBar.add(backBtn);
        btnBar.add(clearBtn);
        btnBar.add(deleteBtn);
        btnBar.add(updateBtn);
        editCard.add(btnBar, BorderLayout.SOUTH);

        contentPanel.add(editCard, BorderLayout.SOUTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Events
        loadFaculty();

        searchButton.addActionListener(e -> searchFaculty());
        searchField.addActionListener(e -> searchFaculty());
        refreshButton.addActionListener(e -> {
            searchField.setText("");
            clearForm();
            loadFaculty();
        });

        addFacultyBtn.addActionListener(e -> {
            new FacultyRegistration();
        });

        facultyTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = facultyTable.getSelectedRow();
                if (row >= 0) {
                    try {
                        selectedFacultyId = Integer.parseInt(String.valueOf(model.getValueAt(row, 0)));
                    } catch (Exception ex) {
                        selectedFacultyId = -1;
                    }
                    idField.setText("FAC" + String.format("%03d", selectedFacultyId));
                    empIdField.setText(String.valueOf(model.getValueAt(row, 1)));
                    nameField.setText(String.valueOf(model.getValueAt(row, 2)));

                    String dept = String.valueOf(model.getValueAt(row, 3));
                    for (int i = 0; i < departmentBox.getItemCount(); i++) {
                        if (departmentBox.getItemAt(i).equalsIgnoreCase(dept)
                                || departmentBox.getItemAt(i).contains(dept)) {
                            departmentBox.setSelectedIndex(i);
                            break;
                        }
                    }

                    String desig = String.valueOf(model.getValueAt(row, 4));
                    for (int i = 0; i < designationBox.getItemCount(); i++) {
                        if (designationBox.getItemAt(i).equalsIgnoreCase(desig)) {
                            designationBox.setSelectedIndex(i);
                            break;
                        }
                    }

                    String qual = String.valueOf(model.getValueAt(row, 5));
                    for (int i = 0; i < qualificationBox.getItemCount(); i++) {
                        if (qualificationBox.getItemAt(i).equalsIgnoreCase(qual)) {
                            qualificationBox.setSelectedIndex(i);
                            break;
                        }
                    }

                    emailField.setText(String.valueOf(model.getValueAt(row, 6)));
                    phoneField.setText(String.valueOf(model.getValueAt(row, 7)));
                    specializationField.setText(String.valueOf(model.getValueAt(row, 8)));
                    experienceField.setText(String.valueOf(model.getValueAt(row, 9)));
                }
            }
        });

        updateBtn.addActionListener(e -> updateFaculty());
        deleteBtn.addActionListener(e -> deleteFaculty());
        clearBtn.addActionListener(e -> clearForm());
        backBtn.addActionListener(e -> dispose());

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(135, 36));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(FONT_INPUT);
        table.setSelectionBackground(new Color(224, 238, 255));
        table.setSelectionForeground(TEXT_DARK);
        table.setGridColor(new Color(241, 245, 249));
        table.setShowVerticalLines(false);

        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(new Color(237, 242, 250));
        th.setForeground(NAVY);
        th.setReorderingAllowed(false);
        th.setPreferredSize(new Dimension(0, 36));
    }

    private void addGridField(JPanel panel, String labelText, Component comp) {
        JPanel grp = new JPanel(new BorderLayout(0, 3));
        grp.setOpaque(false);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);
        grp.add(lbl, BorderLayout.NORTH);
        grp.add(comp, BorderLayout.CENTER);
        panel.add(grp);
    }

    private void loadDepartments() {
        departmentBox.removeAllItems();
        departmentBox.addItem("Select Department");
        String sql = "SELECT department_name FROM department ORDER BY department_name ASC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                departmentBox.addItem(rs.getString("department_name"));
            }
        } catch (SQLException ignored) {}
        if (departmentBox.getItemCount() <= 1) {
            departmentBox.addItem("Computer Science and Engineering");
            departmentBox.addItem("Information Technology");
            departmentBox.addItem("Electronics and Communication");
            departmentBox.addItem("Electrical and Electronics");
            departmentBox.addItem("Mechanical Engineering");
            departmentBox.addItem("Civil Engineering");
        }
    }

    private void loadFaculty() {
        model.setRowCount(0);
        String sql = "SELECT faculty_id, employee_id, faculty_name, department, designation, "
                + "qualification, email, phone, specialization, experience FROM faculty ORDER BY faculty_id ASC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("faculty_id"),
                        rs.getString("employee_id"),
                        rs.getString("faculty_name"),
                        rs.getString("department"),
                        rs.getString("designation"),
                        rs.getString("qualification"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("specialization"),
                        rs.getInt("experience")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load faculty: " + e.getMessage());
        }
    }

    private void searchFaculty() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadFaculty();
            return;
        }

        model.setRowCount(0);
        String sql = "SELECT faculty_id, employee_id, faculty_name, department, designation, "
                + "qualification, email, phone, specialization, experience FROM faculty "
                + "WHERE faculty_name LIKE ? OR department LIKE ? OR employee_id LIKE ? OR email LIKE ? "
                + "ORDER BY faculty_id ASC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String pat = "%" + keyword + "%";
            ps.setString(1, pat);
            ps.setString(2, pat);
            ps.setString(3, pat);
            ps.setString(4, pat);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getInt("faculty_id"),
                            rs.getString("employee_id"),
                            rs.getString("faculty_name"),
                            rs.getString("department"),
                            rs.getString("designation"),
                            rs.getString("qualification"),
                            rs.getString("email"),
                            rs.getString("phone"),
                            rs.getString("specialization"),
                            rs.getInt("experience")
                    });
                }
            }
            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No faculty found matching '" + keyword + "'.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Search error: " + e.getMessage());
        }
    }

    private void updateFaculty() {
        if (selectedFacultyId <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a faculty member from the table to update.");
            return;
        }

        String name = nameField.getText().trim();
        String empId = empIdField.getText().trim();
        String dept = (String) departmentBox.getSelectedItem();
        String desig = (String) designationBox.getSelectedItem();
        String qual = (String) qualificationBox.getSelectedItem();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String spec = specializationField.getText().trim();
        String expStr = experienceField.getText().trim();

        if (name.isEmpty() || empId.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Faculty Name, Employee ID, Email, and Phone are required.");
            return;
        }

        int exp = 0;
        try {
            exp = Integer.parseInt(expStr);
        } catch (NumberFormatException ignored) {}

        String sql = "UPDATE faculty SET faculty_name = ?, employee_id = ?, department = ?, "
                + "designation = ?, qualification = ?, email = ?, phone = ?, specialization = ?, "
                + "experience = ? WHERE faculty_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, empId);
            ps.setString(3, dept);
            ps.setString(4, desig);
            ps.setString(5, qual);
            ps.setString(6, email);
            ps.setString(7, phone);
            ps.setString(8, spec);
            ps.setInt(9, exp);
            ps.setInt(10, selectedFacultyId);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Faculty details updated successfully!");
                loadFaculty();
                clearForm();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Update failed: " + e.getMessage());
        }
    }

    private void deleteFaculty() {
        if (selectedFacultyId <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a faculty member from the table to delete.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this faculty member?\nThis will also remove their invigilation assignments and login account.",
                "Confirm Faculty Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) return;

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                // Delete from staff_allocation
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM staff_allocation WHERE faculty_id = ?")) {
                    ps.setInt(1, selectedFacultyId);
                    ps.executeUpdate();
                }

                // Delete from users if email matches
                String curEmail = emailField.getText().trim();
                if (!curEmail.isEmpty()) {
                    try (PreparedStatement ps = con.prepareStatement("DELETE FROM users WHERE email = ?")) {
                        ps.setString(1, curEmail);
                        ps.executeUpdate();
                    }
                }

                // Delete from faculty
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM faculty WHERE faculty_id = ?")) {
                    ps.setInt(1, selectedFacultyId);
                    ps.executeUpdate();
                }

                con.commit();
                JOptionPane.showMessageDialog(this, "Faculty member deleted successfully!");
                loadFaculty();
                clearForm();

            } catch (SQLException ex) {
                con.rollback();
                JOptionPane.showMessageDialog(this, "Deletion failed: " + ex.getMessage());
            } finally {
                con.setAutoCommit(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    private void clearForm() {
        selectedFacultyId = -1;
        idField.setText("");
        empIdField.setText("");
        nameField.setText("");
        if (departmentBox.getItemCount() > 0) departmentBox.setSelectedIndex(0);
        if (designationBox.getItemCount() > 0) designationBox.setSelectedIndex(0);
        if (qualificationBox.getItemCount() > 0) qualificationBox.setSelectedIndex(0);
        emailField.setText("");
        phoneField.setText("");
        specializationField.setText("");
        experienceField.setText("");
        facultyTable.clearSelection();
    }
}
