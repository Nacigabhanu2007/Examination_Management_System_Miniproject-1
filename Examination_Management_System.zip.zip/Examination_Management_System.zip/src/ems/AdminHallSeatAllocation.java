package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * AdminHallSeatAllocation
 * Multi-hall seat allocation ordered by ascending Roll Number.
 * Allocates registered students continuously (fills Hall 1 to capacity, then Hall 2, etc.).
 * Fixes Hall ID search and allocation retrieval with proper joins and transaction commits.
 */
public class AdminHallSeatAllocation extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    // Search and Filter controls
    private JComboBox<String> searchExamBox;
    private JComboBox<String> searchHallBox;
    private JTextField searchKeywordField;
    private JLabel statusCountLbl;

    // Allocation Form Controls
    private JTextField idField;
    private JComboBox<String> examBox;
    private JComboBox<String> studentBox;
    private JComboBox<String> hallBox;
    private JTextField seatField;

    private JTable table;
    private DefaultTableModel model;

    public AdminHallSeatAllocation() {
        setTitle("Examination Management System - Hall & Seat Allocation");
        setSize(1260, 800);
        setMinimumSize(new Dimension(1050, 680));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "EXAMINATION HALL & SEAT ALLOCATION",
                "Allocate registered exam candidates to venues sorted continuously by ascending Roll Number"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 12));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(12, 20, 15, 20));

        // TOP SEARCH & FILTER BAR (Fixes Hall ID & Exam ID search)
        JPanel searchBar = new JPanel(new BorderLayout());
        searchBar.setBackground(CARD_BG);
        searchBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 14, 10, 14)
        ));

        JPanel searchControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchControls.setOpaque(false);

        JLabel filterLbl = new JLabel("Filter Exam:");
        filterLbl.setFont(FONT_LABEL);
        searchControls.add(filterLbl);

        searchExamBox = new JComboBox<>();
        searchExamBox.setFont(FONT_INPUT);
        searchControls.add(searchExamBox);

        JLabel hallFilterLbl = new JLabel("  Hall ID:");
        hallFilterLbl.setFont(FONT_LABEL);
        searchControls.add(hallFilterLbl);

        searchHallBox = new JComboBox<>();
        searchHallBox.setFont(FONT_INPUT);
        searchControls.add(searchHallBox);

        JLabel kwLbl = new JLabel("  Keyword:");
        kwLbl.setFont(FONT_LABEL);
        searchControls.add(kwLbl);

        searchKeywordField = new JTextField(12);
        searchKeywordField.setFont(FONT_INPUT);
        searchKeywordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        searchControls.add(searchKeywordField);

        JButton searchBtn = createButton("Search by Hall / ID", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton refreshBtn = createButton("Show All / Refresh", SECONDARY_GRAY, SECONDARY_HOVER);
        searchControls.add(searchBtn);
        searchControls.add(refreshBtn);

        statusCountLbl = new JLabel("");
        statusCountLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        statusCountLbl.setForeground(PRIMARY_BLUE);
        searchControls.add(statusCountLbl);

        searchBar.add(searchControls, BorderLayout.CENTER);
        contentPanel.add(searchBar, BorderLayout.NORTH);

        // Table (Displays Student ID, Roll Number, Student Name, Hall ID, Seat Number)
        String[] columns = {
            "Alloc ID", "Exam ID", "Student ID", "Roll Number", "Student Name", "Hall ID", "Hall Name", "Seat Number", "Allocated Time"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(center); // Alloc ID
        table.getColumnModel().getColumn(1).setCellRenderer(center); // Exam ID
        table.getColumnModel().getColumn(2).setCellRenderer(center); // Student ID
        table.getColumnModel().getColumn(3).setCellRenderer(center); // Roll Number
        table.getColumnModel().getColumn(5).setCellRenderer(center); // Hall ID
        table.getColumnModel().getColumn(7).setCellRenderer(center); // Seat No

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Bottom Form Card
        JPanel formCard = new JPanel(new BorderLayout(0, 10));
        formCard.setBackground(CARD_BG);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(12, 18, 12, 18)
        ));

        JLabel formTitle = new JLabel("Seat Assignment & Multi-Hall Auto-Allocation Controls");
        formTitle.setFont(FONT_HEADER);
        formTitle.setForeground(PRIMARY_BLUE);
        formCard.add(formTitle, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridLayout(2, 3, 14, 8));
        formGrid.setOpaque(false);

        idField = new JTextField();
        idField.setEditable(false);
        idField.setFont(FONT_INPUT);
        idField.setBackground(new Color(241, 245, 249));
        idField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        examBox = new JComboBox<>();
        examBox.setFont(FONT_INPUT);

        studentBox = new JComboBox<>();
        studentBox.setFont(FONT_INPUT);

        hallBox = new JComboBox<>();
        hallBox.setFont(FONT_INPUT);

        seatField = new JTextField();
        seatField.setFont(FONT_INPUT);
        seatField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        JButton manageHallsBtn = createButton("Manage Halls Setup", SECONDARY_GRAY, SECONDARY_HOVER);
        manageHallsBtn.addActionListener(e -> openHallManager());

        JPanel hallSetupPanel = new JPanel(new BorderLayout(0, 4));
        hallSetupPanel.setOpaque(false);
        JLabel hallSetupLbl = new JLabel("Venue Configuration");
        hallSetupLbl.setFont(FONT_LABEL);
        hallSetupLbl.setForeground(TEXT_DARK);
        hallSetupPanel.add(hallSetupLbl, BorderLayout.NORTH);
        hallSetupPanel.add(manageHallsBtn, BorderLayout.CENTER);

        addGridField(formGrid, "Allocation ID (Auto)", idField);
        addGridField(formGrid, "Select Exam", examBox);
        addGridField(formGrid, "Select Registered Student", studentBox);
        addGridField(formGrid, "Select Hall", hallBox);
        addGridField(formGrid, "Seat Number (e.g. S-01)", seatField);
        formGrid.add(hallSetupPanel);

        formCard.add(formGrid, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        buttonPanel.setOpaque(false);

        JButton autoAllocateBtn = createButton("Auto-Allocate All (Roll No Order)", PRIMARY_BLUE, PRIMARY_HOVER);
        autoAllocateBtn.setPreferredSize(new Dimension(245, 34));

        JButton allocateBtn = createButton("Allocate Single Seat", SUCCESS_GREEN, SUCCESS_HOVER);
        JButton deleteBtn = createButton("Delete Allocation", DANGER_RED, DANGER_HOVER);
        JButton clearBtn = createButton("Clear Form", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backBtn = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        buttonPanel.add(backBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(allocateBtn);
        buttonPanel.add(autoAllocateBtn);

        formCard.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.add(formCard, BorderLayout.SOUTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Actions
        searchBtn.addActionListener(e -> searchAllocations());
        searchKeywordField.addActionListener(e -> searchAllocations());
        refreshBtn.addActionListener(e -> {
            searchKeywordField.setText("");
            if (searchExamBox.getItemCount() > 0) searchExamBox.setSelectedIndex(0);
            if (searchHallBox.getItemCount() > 0) searchHallBox.setSelectedIndex(0);
            clearForm();
            loadAllocations();
        });

        allocateBtn.addActionListener(e -> allocateSingleSeat());
        autoAllocateBtn.addActionListener(e -> autoAllocateMultiHall());
        deleteBtn.addActionListener(e -> deleteAllocation());
        clearBtn.addActionListener(e -> clearForm());
        backBtn.addActionListener(e -> dispose());

        examBox.addActionListener(e -> {
            if (examBox.getSelectedIndex() > 0) {
                loadRegisteredStudentsForExam();
                suggestSeatNumber();
            }
        });

        hallBox.addActionListener(e -> {
            if (hallBox.getSelectedIndex() > 0) {
                suggestSeatNumber();
            }
        });

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                idField.setText(model.getValueAt(row, 0).toString());
                seatField.setText(model.getValueAt(row, 7).toString());
            }
        });

        loadExams();
        loadHalls();
        loadAllocations();

        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(16, 25, 16, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));
    }

    private void addGridField(JPanel panel, String label, JComponent field) {
        JPanel fGroup = new JPanel(new BorderLayout(0, 4));
        fGroup.setOpaque(false);

        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        fGroup.add(lbl, BorderLayout.NORTH);
        fGroup.add(field, BorderLayout.CENTER);
        panel.add(fGroup);
    }

    private void loadExams() {
        examBox.removeAllItems();
        searchExamBox.removeAllItems();

        examBox.addItem("Select Exam");
        searchExamBox.addItem("All Exams");

        String sql = "SELECT exam_id, exam_name FROM exam ORDER BY exam_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String item = rs.getString("exam_id") + " - " + rs.getString("exam_name");
                examBox.addItem(item);
                searchExamBox.addItem(item);
            }
        } catch (SQLException ignored) {}
    }

    private void loadHalls() {
        hallBox.removeAllItems();
        searchHallBox.removeAllItems();

        hallBox.addItem("Select Hall");
        searchHallBox.addItem("All Halls");

        String sql = "SELECT hall_number, hall_name, capacity FROM hall ORDER BY hall_number";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String item = rs.getString("hall_number") + " - " + rs.getString("hall_name") + " (Cap: " + rs.getInt("capacity") + ")";
                hallBox.addItem(item);
                searchHallBox.addItem(item);
            }
        } catch (SQLException ignored) {}
    }

    private void loadRegisteredStudentsForExam() {
        studentBox.removeAllItems();
        studentBox.addItem("Select Registered Student");

        if (examBox.getSelectedIndex() <= 0) return;
        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();

        // Sort registered students by Roll Number ascending
        String sql = "SELECT r.studentId, r.studentName, COALESCE(s.roll_number, 'N/A') AS roll_number "
                   + "FROM examregistration r "
                   + "LEFT JOIN student s ON r.studentId = s.student_id "
                   + "WHERE r.examId = ? AND r.status = 'Registered' "
                   + "  AND r.studentId NOT IN (SELECT hsa.student_id FROM hall_seat_allocation hsa WHERE hsa.exam_id = ?) "
                   + "ORDER BY s.roll_number ASC, r.studentName ASC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, examId);
            ps.setString(2, examId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    studentBox.addItem(rs.getString("studentId") + " - " + rs.getString("roll_number") + " - " + rs.getString("studentName"));
                }
            }
        } catch (SQLException ignored) {}
    }

    private void suggestSeatNumber() {
        if (examBox.getSelectedIndex() <= 0 || hallBox.getSelectedIndex() <= 0) return;

        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();
        String hallNo = hallBox.getSelectedItem().toString().split(" - ")[0].trim();

        String countSql = "SELECT COUNT(*) FROM hall_seat_allocation WHERE exam_id = ? AND hall_number = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(countSql)) {

            ps.setString(1, examId);
            ps.setString(2, hallNo);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int currentCount = rs.getInt(1);
                    seatField.setText(String.format("S-%02d", currentCount + 1));
                }
            }
        } catch (SQLException ignored) {}
    }

    /**
     * Load all allocations from MySQL.
     * Displays Student ID, Roll Number, Student Name, Hall ID, Seat Number.
     */
    private void loadAllocations() {
        model.setRowCount(0);
        String sql = "SELECT hsa.allocation_id, hsa.exam_id, e.exam_name, hsa.student_id, "
                   + "COALESCE(s.roll_number, 'N/A') AS roll_number, "
                   + "COALESCE(s.student_name, 'N/A') AS student_name, "
                   + "hsa.hall_number, COALESCE(h.hall_name, 'N/A') AS hall_name, "
                   + "hsa.seat_number, hsa.allocated_date "
                   + "FROM hall_seat_allocation hsa "
                   + "LEFT JOIN exam e ON hsa.exam_id = e.exam_id "
                   + "LEFT JOIN student s ON hsa.student_id = s.student_id "
                   + "LEFT JOIN hall h ON TRIM(LOWER(hsa.hall_number)) = TRIM(LOWER(h.hall_number)) "
                   + "ORDER BY hsa.exam_id ASC, hsa.hall_number ASC, s.roll_number ASC, hsa.seat_number ASC";

        int totalCount = 0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                totalCount++;
                model.addRow(new Object[]{
                    rs.getInt("allocation_id"),
                    rs.getString("exam_id"),
                    rs.getString("student_id"),
                    rs.getString("roll_number"),
                    rs.getString("student_name"),
                    rs.getString("hall_number"),
                    rs.getString("hall_name"),
                    rs.getString("seat_number"),
                    rs.getTimestamp("allocated_date")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load allocations: " + e.getMessage());
        }

        statusCountLbl.setText("Total Allocated Records: " + totalCount);
    }

    /**
     * Search allocations by Hall ID, Exam ID, or general keyword.
     * Fixes "Hall Not Found" by using exact trimmed case-insensitive comparisons and proper joins.
     */
    private void searchAllocations() {
        String examSel = (searchExamBox.getSelectedItem() != null) ? searchExamBox.getSelectedItem().toString() : "";
        String hallSel = (searchHallBox.getSelectedItem() != null) ? searchHallBox.getSelectedItem().toString() : "";
        String kw = searchKeywordField.getText().trim();

        String examId = (!examSel.isEmpty() && !examSel.equalsIgnoreCase("All Exams")) ? examSel.split(" - ")[0].trim() : "";
        String hallNo = (!hallSel.isEmpty() && !hallSel.equalsIgnoreCase("All Halls")) ? hallSel.split(" - ")[0].trim() : "";

        model.setRowCount(0);

        StringBuilder sql = new StringBuilder(
                "SELECT hsa.allocation_id, hsa.exam_id, e.exam_name, hsa.student_id, "
                + "COALESCE(s.roll_number, 'N/A') AS roll_number, "
                + "COALESCE(s.student_name, 'N/A') AS student_name, "
                + "hsa.hall_number, COALESCE(h.hall_name, 'N/A') AS hall_name, "
                + "hsa.seat_number, hsa.allocated_date "
                + "FROM hall_seat_allocation hsa "
                + "LEFT JOIN exam e ON hsa.exam_id = e.exam_id "
                + "LEFT JOIN student s ON hsa.student_id = s.student_id "
                + "LEFT JOIN hall h ON TRIM(LOWER(hsa.hall_number)) = TRIM(LOWER(h.hall_number)) "
                + "WHERE 1=1 "
        );

        List<String> params = new ArrayList<>();

        if (!examId.isEmpty()) {
            sql.append(" AND hsa.exam_id = ? ");
            params.add(examId);
        }

        if (!hallNo.isEmpty()) {
            sql.append(" AND TRIM(LOWER(hsa.hall_number)) = TRIM(LOWER(?)) ");
            params.add(hallNo);
        }

        if (!kw.isEmpty()) {
            sql.append(" AND (TRIM(LOWER(hsa.hall_number)) LIKE ? OR s.roll_number LIKE ? OR hsa.student_id LIKE ? OR s.student_name LIKE ? OR hsa.exam_id LIKE ?) ");
            String pat = "%" + kw.toLowerCase() + "%";
            params.add(pat);
            params.add(pat);
            params.add(pat);
            params.add(pat);
            params.add(pat);
        }

        sql.append(" ORDER BY hsa.hall_number ASC, s.roll_number ASC, hsa.seat_number ASC");

        int matchCount = 0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setString(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    matchCount++;
                    model.addRow(new Object[]{
                        rs.getInt("allocation_id"),
                        rs.getString("exam_id"),
                        rs.getString("student_id"),
                        rs.getString("roll_number"),
                        rs.getString("student_name"),
                        rs.getString("hall_number"),
                        rs.getString("hall_name"),
                        rs.getString("seat_number"),
                        rs.getTimestamp("allocated_date")
                    });
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Search error: " + e.getMessage());
        }

        statusCountLbl.setText("Search Results: " + matchCount + " records");

        if (matchCount == 0) {
            String hallMsg = !hallNo.isEmpty() ? (" for Hall " + hallNo) : "";
            String examMsg = !examId.isEmpty() ? (" in Exam " + examId) : "";
            JOptionPane.showMessageDialog(this,
                    "No students allocated" + hallMsg + examMsg + (kw.isEmpty() ? "." : " matching keyword: " + kw),
                    "Search Result", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Requirement 4: Automatic Multi-Hall Seat Allocation
     * - Allocate seats only to students registered for the selected exam.
     * - Sort students by Roll Number in ascending order.
     * - Allocate continuously from the first roll number.
     * - Fill the first hall up to its capacity, then continue with the next hall.
     *   (e.g., if Hall 1 has 50 seats, first 50 students go to Hall 1 and the remaining students go to Hall 2).
     * - Prevent duplicate seat allocation.
     * - Save allocation correctly in MySQL.
     */
    private void autoAllocateMultiHall() {
        if (examBox.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Please select an Examination from the dropdown to auto-allocate registered candidates.");
            return;
        }

        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();
        String examName = examBox.getSelectedItem().toString();

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            // Step 1: Fetch registered unallocated students sorted strictly by Roll Number ascending
            String stuSql = "SELECT r.studentId, s.student_name, COALESCE(s.roll_number, '') AS roll_number "
                          + "FROM examregistration r "
                          + "JOIN student s ON r.studentId = s.student_id "
                          + "WHERE r.examId = ? AND r.status = 'Registered' "
                          + "  AND r.studentId NOT IN (SELECT hsa.student_id FROM hall_seat_allocation hsa WHERE hsa.exam_id = ?) "
                          + "ORDER BY s.roll_number ASC, s.student_name ASC";

            List<String[]> students = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(stuSql)) {
                ps.setString(1, examId);
                ps.setString(2, examId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        students.add(new String[]{
                            rs.getString("studentId"),
                            rs.getString("student_name"),
                            rs.getString("roll_number")
                        });
                    }
                }
            }

            if (students.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "All registered candidates for " + examId + " are already allocated to examination halls.",
                        "Allocation Complete", JOptionPane.INFORMATION_MESSAGE);
                con.setAutoCommit(true);
                return;
            }

            // Step 2: Fetch all halls in order of hall_number
            String hallSql = "SELECT hall_number, hall_name, capacity FROM hall ORDER BY hall_number ASC";
            class HallInfo {
                String hallNumber;
                String hallName;
                int capacity;
                HallInfo(String no, String nm, int cap) { this.hallNumber = no; this.hallName = nm; this.capacity = cap; }
            }

            List<HallInfo> halls = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(hallSql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    halls.add(new HallInfo(rs.getString("hall_number"), rs.getString("hall_name"), rs.getInt("capacity")));
                }
            }

            if (halls.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No examination halls found in database. Please configure halls first.");
                con.setAutoCommit(true);
                return;
            }

            // Step 3: Continuously allocate students across halls up to capacity
            String insertSql = "INSERT INTO hall_seat_allocation (exam_id, student_id, hall_number, seat_number) VALUES (?, ?, ?, ?)";
            int studentIdx = 0;
            int totalAllocated = 0;
            StringBuilder summary = new StringBuilder();

            try (PreparedStatement insPs = con.prepareStatement(insertSql)) {

                for (HallInfo h : halls) {
                    if (studentIdx >= students.size()) break;

                    // Check existing occupied seats in this hall for this exam
                    Set<String> occupiedSeats = new HashSet<>();
                    try (PreparedStatement occPs = con.prepareStatement("SELECT seat_number FROM hall_seat_allocation WHERE exam_id = ? AND hall_number = ?")) {
                        occPs.setString(1, examId);
                        occPs.setString(2, h.hallNumber);
                        try (ResultSet occRs = occPs.executeQuery()) {
                            while (occRs.next()) {
                                occupiedSeats.add(occRs.getString("seat_number").trim().toUpperCase());
                            }
                        }
                    }

                    int hallAvailable = h.capacity - occupiedSeats.size();
                    if (hallAvailable <= 0) continue;

                    int allocatedInThisHall = 0;
                    int seatCounter = 1;

                    while (allocatedInThisHall < hallAvailable && studentIdx < students.size() && seatCounter <= h.capacity) {
                        String seatNo = String.format("S-%02d", seatCounter);
                        seatCounter++;

                        if (occupiedSeats.contains(seatNo.toUpperCase())) {
                            continue; // Skip already occupied seat
                        }

                        String[] stu = students.get(studentIdx);
                        insPs.setString(1, examId);
                        insPs.setString(2, stu[0]); // studentId
                        insPs.setString(3, h.hallNumber);
                        insPs.setString(4, seatNo);
                        insPs.executeUpdate();

                        allocatedInThisHall++;
                        totalAllocated++;
                        studentIdx++;
                    }

                    if (allocatedInThisHall > 0) {
                        summary.append("\n• Hall ").append(h.hallNumber)
                               .append(" (").append(h.hallName).append("): ")
                               .append(allocatedInThisHall).append(" students allocated.");
                    }
                }

                con.commit();
            } catch (SQLException ex) {
                con.rollback();
                throw ex;
            } finally {
                con.setAutoCommit(true);
            }

            // Results summary
            String msg = "Continuous Roll Number Allocation Completed Successfully!\n"
                       + "Exam: " + examName + "\n"
                       + "Total Students Allocated: " + totalAllocated + " of " + students.size()
                       + summary.toString();

            if (studentIdx < students.size()) {
                msg += "\n\nWarning: " + (students.size() - studentIdx) + " students could not be allocated due to insufficient total hall capacity.";
            }

            JOptionPane.showMessageDialog(this, msg, "Allocation Result", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadAllocations();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Auto-allocation failed: " + ex.getMessage());
        }
    }

    /**
     * Single Seat Allocation with duplicate prevention.
     */
    private void allocateSingleSeat() {
        if (examBox.getSelectedIndex() <= 0 || studentBox.getSelectedIndex() <= 0 || hallBox.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Please select Exam, Student, and Hall.");
            return;
        }

        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();
        String studentId = studentBox.getSelectedItem().toString().split(" - ")[0].trim();
        String hallNo = hallBox.getSelectedItem().toString().split(" - ")[0].trim();
        String seatNo = seatField.getText().trim();

        if (seatNo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seat Number is required.");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            // 1. Check Hall Capacity
            int capacity = 0;
            try (PreparedStatement capPs = con.prepareStatement("SELECT capacity FROM hall WHERE hall_number = ?")) {
                capPs.setString(1, hallNo);
                try (ResultSet capRs = capPs.executeQuery()) {
                    if (capRs.next()) capacity = capRs.getInt("capacity");
                }
            }

            try (PreparedStatement countPs = con.prepareStatement("SELECT COUNT(*) FROM hall_seat_allocation WHERE exam_id = ? AND hall_number = ?")) {
                countPs.setString(1, examId);
                countPs.setString(2, hallNo);
                try (ResultSet countRs = countPs.executeQuery()) {
                    if (countRs.next() && countRs.getInt(1) >= capacity) {
                        JOptionPane.showMessageDialog(this, "Hall capacity reached (" + capacity + " seats). Please select another hall.");
                        con.rollback();
                        return;
                    }
                }
            }

            // 2. Check duplicate student in this exam
            try (PreparedStatement chkStu = con.prepareStatement("SELECT hall_number, seat_number FROM hall_seat_allocation WHERE exam_id = ? AND student_id = ?")) {
                chkStu.setString(1, examId);
                chkStu.setString(2, studentId);
                try (ResultSet rsChk = chkStu.executeQuery()) {
                    if (rsChk.next()) {
                        JOptionPane.showMessageDialog(this, "Student " + studentId + " is already allocated to " + rsChk.getString("hall_number") + " Seat " + rsChk.getString("seat_number") + " for this exam!");
                        con.rollback();
                        return;
                    }
                }
            }

            // 3. Check duplicate seat in this hall
            try (PreparedStatement seatPs = con.prepareStatement("SELECT COUNT(*) FROM hall_seat_allocation WHERE exam_id = ? AND hall_number = ? AND seat_number = ?")) {
                seatPs.setString(1, examId);
                seatPs.setString(2, hallNo);
                seatPs.setString(3, seatNo);
                try (ResultSet seatRs = seatPs.executeQuery()) {
                    if (seatRs.next() && seatRs.getInt(1) > 0) {
                        JOptionPane.showMessageDialog(this, "Seat " + seatNo + " in " + hallNo + " is already occupied for this exam!");
                        con.rollback();
                        return;
                    }
                }
            }

            // 4. Insert allocation
            String insSql = "INSERT INTO hall_seat_allocation (exam_id, student_id, hall_number, seat_number) VALUES (?, ?, ?, ?)";
            try (PreparedStatement insPs = con.prepareStatement(insSql)) {
                insPs.setString(1, examId);
                insPs.setString(2, studentId);
                insPs.setString(3, hallNo);
                insPs.setString(4, seatNo);
                insPs.executeUpdate();
                con.commit();
                JOptionPane.showMessageDialog(this, "Student " + studentId + " allocated to " + hallNo + ", Seat: " + seatNo + "!");
                clearForm();
                loadAllocations();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Allocation Error: " + ex.getMessage());
        }
    }

    private void deleteAllocation() {
        String idStr = idField.getText().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an allocation row from the table to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete allocation ID " + idStr + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        String sql = "DELETE FROM hall_seat_allocation WHERE allocation_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(idStr));
            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Allocation removed successfully!");
                clearForm();
                loadAllocations();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Delete failed: " + ex.getMessage());
        }
    }

    private void openHallManager() {
        JDialog dlg = new JDialog(this, "Manage Examination Halls", true);
        dlg.setSize(580, 460);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        DefaultTableModel hModel = new DefaultTableModel(new String[]{"Hall No", "Hall Name", "Capacity"}, 0);
        JTable hTable = new JTable(hModel);
        styleTable(hTable);

        Runnable loadH = () -> {
            hModel.setRowCount(0);
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement("SELECT * FROM hall ORDER BY hall_number");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    hModel.addRow(new Object[]{rs.getString("hall_number"), rs.getString("hall_name"), rs.getInt("capacity")});
                }
            } catch (SQLException ignored) {}
        };

        loadH.run();

        JPanel fPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        fPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));
        fPanel.setBackground(Color.WHITE);

        JTextField hNoF = new JTextField();
        JTextField hNameF = new JTextField();
        JTextField hCapF = new JTextField();

        hNoF.setFont(FONT_INPUT);
        hNameF.setFont(FONT_INPUT);
        hCapF.setFont(FONT_INPUT);

        fPanel.add(new JLabel("Hall Number:")); fPanel.add(hNoF);
        fPanel.add(new JLabel("Hall Name:")); fPanel.add(hNameF);
        fPanel.add(new JLabel("Capacity:")); fPanel.add(hCapF);

        JPanel btnP = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 8));
        btnP.setBackground(Color.WHITE);
        JButton addBtn = createButton("Add Hall", SUCCESS_GREEN, SUCCESS_HOVER);
        JButton delBtn = createButton("Delete Hall", DANGER_RED, DANGER_HOVER);
        btnP.add(delBtn);
        btnP.add(addBtn);

        addBtn.addActionListener(e -> {
            String no = hNoF.getText().trim();
            String nm = hNameF.getText().trim();
            String cp = hCapF.getText().trim();
            if (no.isEmpty() || nm.isEmpty() || cp.isEmpty()) return;

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement("INSERT INTO hall (hall_number, hall_name, capacity) VALUES (?, ?, ?)")) {
                ps.setString(1, no);
                ps.setString(2, nm);
                ps.setInt(3, Integer.parseInt(cp));
                ps.executeUpdate();
                loadH.run();
                loadHalls();
                hNoF.setText(""); hNameF.setText(""); hCapF.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dlg, "Error adding hall: " + ex.getMessage());
            }
        });

        delBtn.addActionListener(e -> {
            int row = hTable.getSelectedRow();
            if (row == -1) return;
            String no = hModel.getValueAt(row, 0).toString();
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement("DELETE FROM hall WHERE hall_number = ?")) {
                ps.setString(1, no);
                ps.executeUpdate();
                loadH.run();
                loadHalls();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dlg, "Cannot delete hall: " + ex.getMessage());
            }
        });

        JPanel topP = new JPanel(new BorderLayout());
        topP.add(fPanel, BorderLayout.CENTER);
        topP.add(btnP, BorderLayout.SOUTH);

        dlg.add(topP, BorderLayout.NORTH);
        dlg.add(new JScrollPane(hTable), BorderLayout.CENTER);
        dlg.setVisible(true);
    }

    private void clearForm() {
        idField.setText("");
        if (examBox.getItemCount() > 0) examBox.setSelectedIndex(0);
        studentBox.removeAllItems();
        studentBox.addItem("Select Registered Student");
        if (hallBox.getItemCount() > 0) hallBox.setSelectedIndex(0);
        seatField.setText("");
        table.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminHallSeatAllocation::new);
    }
}
