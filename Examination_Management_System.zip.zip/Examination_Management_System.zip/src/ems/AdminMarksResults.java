package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

/**
 * AdminMarksResults
 * Marks and Academic Results Management module.
 * Admin Access: VIEW-ONLY audit of Student ID, Roll Number, Student Name, Exam, Subject, Marks, Total Marks, Grade, Status.
 *               Includes rich search and filter options. Add/Update/Delete controls are strictly removed.
 * Faculty Access: Authorized entry, update, and deletion of student marks and evaluations.
 */
public class AdminMarksResults extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private String userRole = "Admin";
    private String userEmail = "";
    private boolean isViewOnly = true;

    // Table
    private JTable table;
    private DefaultTableModel model;

    // Search and Filter Controls (View-Only & Faculty)
    private JTextField searchField;
    private JComboBox<String> filterExamBox;
    private JComboBox<String> filterStatusBox;
    private JLabel recordCountLbl;

    // Faculty Entry Form Controls (Preserved strictly for Faculty role)
    private JTextField markIdField;
    private JComboBox<String> examBox;
    private JComboBox<String> subjectBox;
    private JComboBox<String> studentBox;
    private JTextField marksField;
    private JTextField maxMarksField;
    private JTextField remarksField;

    public AdminMarksResults() {
        this("Admin", "");
    }

    public AdminMarksResults(String role, String email) {
        this.userRole = (role != null && !role.trim().isEmpty()) ? role.trim() : "Admin";
        this.userEmail = (email != null) ? email.trim() : "";
        this.isViewOnly = userRole.equalsIgnoreCase("Admin");

        setTitle("Examination Management System - " + (isViewOnly ? "Student Marks & Results (View Only)" : "Faculty Marks Evaluation Portal"));
        setSize(1260, 780);
        setMinimumSize(new Dimension(1050, 680));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                isViewOnly ? "STUDENT MARKS & ACADEMIC RESULTS (VIEW ONLY)" : "FACULTY EXAMINATION MARKS EVALUATION",
                isViewOnly ? "Official academic standings, marks, grades and pass/fail results audit"
                           : "Authorized grade entry and marks evaluation portal for teaching faculty"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 12));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(12, 20, 15, 20));

        // 1. Search and Filter Bar
        JPanel searchBar = new JPanel(new BorderLayout());
        searchBar.setBackground(CARD_BG);
        searchBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 14, 10, 14)
        ));

        JPanel filterControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filterControls.setOpaque(false);

        JLabel searchLbl = new JLabel("Search (Student ID / Roll No / Name):");
        searchLbl.setFont(FONT_LABEL);
        filterControls.add(searchLbl);

        searchField = new JTextField(16);
        searchField.setFont(FONT_INPUT);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        filterControls.add(searchField);

        JLabel exLbl = new JLabel("  Exam:");
        exLbl.setFont(FONT_LABEL);
        filterControls.add(exLbl);

        filterExamBox = new JComboBox<>();
        filterExamBox.setFont(FONT_INPUT);
        loadFilterExams();
        filterExamBox.addActionListener(e -> loadMarksAndResults());
        filterControls.add(filterExamBox);

        JLabel stLbl = new JLabel("  Status:");
        stLbl.setFont(FONT_LABEL);
        filterControls.add(stLbl);

        filterStatusBox = new JComboBox<>(new String[]{"All Statuses", "Pass", "Fail"});
        filterStatusBox.setFont(FONT_INPUT);
        filterStatusBox.addActionListener(e -> loadMarksAndResults());
        filterControls.add(filterStatusBox);

        JButton searchBtn = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton refreshBtn = createButton("Refresh", SECONDARY_GRAY, SECONDARY_HOVER);
        filterControls.add(searchBtn);
        filterControls.add(refreshBtn);

        searchBar.add(filterControls, BorderLayout.WEST);

        JPanel rightBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightBar.setOpaque(false);
        recordCountLbl = new JLabel("Records: 0");
        recordCountLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        recordCountLbl.setForeground(PRIMARY_BLUE);
        rightBar.add(recordCountLbl);
        searchBar.add(rightBar, BorderLayout.EAST);

        contentPanel.add(searchBar, BorderLayout.NORTH);

        // 2. Table: Displays Student ID, Roll Number, Student Name, Exam, Subject, Marks, Total Marks, Grade, Result Status
        String[] columns = {
            "Student ID", "Roll Number", "Student Name", "Exam", "Subject", "Marks", "Total Marks", "%", "Grade", "Result Status"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(center); // Student ID
        table.getColumnModel().getColumn(1).setCellRenderer(center); // Roll Number
        table.getColumnModel().getColumn(5).setCellRenderer(center); // Marks
        table.getColumnModel().getColumn(6).setCellRenderer(center); // Total Marks
        table.getColumnModel().getColumn(7).setCellRenderer(center); // %
        table.getColumnModel().getColumn(8).setCellRenderer(center); // Grade
        table.getColumnModel().getColumn(9).setCellRenderer(center); // Status

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // 3. Faculty-Only Entry Card OR Admin View-Only Bottom Bar
        if (!isViewOnly) {
            // FACULTY MODE: Form Card for Marks Entry, Updates and Modifications
            JPanel formCard = new JPanel(new BorderLayout(0, 10));
            formCard.setBackground(CARD_BG);
            formCard.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_COLOR, 1),
                    new EmptyBorder(12, 18, 12, 18)
            ));

            JLabel formTitle = new JLabel("Authorized Faculty Marks Entry & Grade Evaluation");
            formTitle.setFont(FONT_HEADER);
            formTitle.setForeground(PRIMARY_BLUE);
            formCard.add(formTitle, BorderLayout.NORTH);

            JPanel formGrid = new JPanel(new GridLayout(2, 4, 12, 8));
            formGrid.setOpaque(false);

            markIdField = new JTextField();
            markIdField.setEditable(false);
            markIdField.setFont(FONT_INPUT);
            markIdField.setBackground(new Color(241, 245, 249));

            examBox = new JComboBox<>();
            examBox.setFont(FONT_INPUT);

            subjectBox = new JComboBox<>();
            subjectBox.setFont(FONT_INPUT);

            studentBox = new JComboBox<>();
            studentBox.setFont(FONT_INPUT);

            marksField = new JTextField();
            marksField.setFont(FONT_INPUT);

            maxMarksField = new JTextField("100");
            maxMarksField.setFont(FONT_INPUT);

            remarksField = new JTextField("Regular");
            remarksField.setFont(FONT_INPUT);

            addGridField(formGrid, "Mark ID (Auto)", markIdField);
            addGridField(formGrid, "Select Exam", examBox);
            addGridField(formGrid, "Select Subject", subjectBox);
            addGridField(formGrid, "Select Student (Roll No - Name)", studentBox);

            addGridField(formGrid, "Marks Obtained", marksField);
            addGridField(formGrid, "Max Marks", maxMarksField);
            addGridField(formGrid, "Remarks", remarksField);

            JPanel blank = new JPanel();
            blank.setOpaque(false);
            formGrid.add(blank);

            formCard.add(formGrid, BorderLayout.CENTER);

            // Faculty Action Buttons
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
            buttonPanel.setOpaque(false);

            JButton saveBtn = createButton("Save Marks & Results", SUCCESS_GREEN, SUCCESS_HOVER);
            JButton updateBtn = createButton("Update Marks", PRIMARY_BLUE, PRIMARY_HOVER);
            JButton deleteBtn = createButton("Delete Record", DANGER_RED, DANGER_HOVER);
            JButton clearBtn = createButton("Clear Form", SECONDARY_GRAY, SECONDARY_HOVER);
            JButton backBtn = createButton("Back", new Color(71, 85, 105), new Color(51, 65, 85));

            buttonPanel.add(backBtn);
            buttonPanel.add(clearBtn);
            buttonPanel.add(deleteBtn);
            buttonPanel.add(updateBtn);
            buttonPanel.add(saveBtn);
            formCard.add(buttonPanel, BorderLayout.SOUTH);

            contentPanel.add(formCard, BorderLayout.SOUTH);

            // Faculty Events
            saveBtn.addActionListener(e -> saveMarks(false));
            updateBtn.addActionListener(e -> saveMarks(true));
            deleteBtn.addActionListener(e -> deleteMarks());
            clearBtn.addActionListener(e -> clearForm());
            backBtn.addActionListener(e -> dispose());

            examBox.addActionListener(e -> {
                if (examBox.getSelectedIndex() > 0) syncExamSubjectsAndStudents();
            });

            table.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                    int row = table.getSelectedRow();
                    marksField.setText(model.getValueAt(row, 5).toString());
                    maxMarksField.setText(model.getValueAt(row, 6).toString());
                }
            });

            loadFormExams();
            loadFormSubjects();

        } else {
            // ADMIN MODE: Strictly View-Only!
            // No Add, Edit, Update, or Delete buttons or entry fields are present.
            JPanel adminBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
            adminBottom.setBackground(BG_LIGHT);

            JLabel viewOnlyNotice = new JLabel("🔒 Admin View-Only Mode: Grade entry and modification is strictly restricted to Faculty members.   ");
            viewOnlyNotice.setFont(new Font("Segoe UI", Font.ITALIC, 13));
            viewOnlyNotice.setForeground(TEXT_DARK);
            adminBottom.add(viewOnlyNotice);

            JButton backBtn = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));
            backBtn.addActionListener(e -> dispose());
            adminBottom.add(backBtn);

            contentPanel.add(adminBottom, BorderLayout.SOUTH);
        }

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);

        // General search & refresh listeners
        searchBtn.addActionListener(e -> searchMarks());
        searchField.addActionListener(e -> searchMarks());
        refreshBtn.addActionListener(e -> {
            searchField.setText("");
            filterExamBox.setSelectedIndex(0);
            filterStatusBox.setSelectedIndex(0);
            loadMarksAndResults();
        });

        loadMarksAndResults();
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(16, 25, 16, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);

        if (isViewOnly) {
            JLabel badge = new JLabel(" VIEW-ONLY AUDIT ");
            badge.setOpaque(true);
            badge.setBackground(new Color(224, 238, 255));
            badge.setForeground(PRIMARY_BLUE);
            badge.setFont(new Font("Segoe UI", Font.BOLD, 12));
            badge.setBorder(new EmptyBorder(6, 12, 6, 12));
            header.add(badge, BorderLayout.EAST);
        }

        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) { btn.setBackground(hover); }
            @Override
            public void mouseExited(MouseEvent e) { btn.setBackground(bg); }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));
    }

    private void addGridField(JPanel panel, String label, JComponent field) {
        JPanel fGroup = new JPanel(new BorderLayout(0, 4));
        fGroup.setOpaque(false);

        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        fGroup.add(lbl, BorderLayout.NORTH);
        fGroup.add(field, BorderLayout.CENTER);
        panel.add(fGroup);
    }

    private void loadFilterExams() {
        filterExamBox.removeAllItems();
        filterExamBox.addItem("All Exams");
        String sql = "SELECT exam_id, exam_name FROM exam ORDER BY exam_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                filterExamBox.addItem(rs.getString("exam_id") + " - " + rs.getString("exam_name"));
            }
        } catch (SQLException ignored) {}
    }

    private void loadFormExams() {
        if (examBox == null) return;
        examBox.removeAllItems();
        examBox.addItem("Select Exam");
        String sql = "SELECT exam_id, exam_name FROM exam ORDER BY exam_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                examBox.addItem(rs.getString("exam_id") + " - " + rs.getString("exam_name"));
            }
        } catch (SQLException ignored) {}
    }

    private void loadFormSubjects() {
        if (subjectBox == null) return;
        subjectBox.removeAllItems();
        subjectBox.addItem("Select Subject");
        String sql = "SELECT subject_id, subject_name FROM subject ORDER BY subject_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                subjectBox.addItem(rs.getString("subject_id") + " - " + rs.getString("subject_name"));
            }
        } catch (SQLException ignored) {}
    }

    private void syncExamSubjectsAndStudents() {
        if (examBox == null || examBox.getSelectedIndex() <= 0) return;
        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();

        // Sync subject mapped to this exam
        String sql = "SELECT subject_id FROM exam WHERE exam_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, examId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String subId = rs.getString("subject_id");
                    for (int i = 0; i < subjectBox.getItemCount(); i++) {
                        if (subjectBox.getItemAt(i).startsWith(subId)) {
                            subjectBox.setSelectedIndex(i);
                            break;
                        }
                    }
                }
            }
        } catch (SQLException ignored) {}

        // Load students registered for this exam with Roll Numbers
        studentBox.removeAllItems();
        studentBox.addItem("Select Student");
        String stuSql = "SELECT r.studentId, r.studentName, COALESCE(s.roll_number, 'N/A') AS roll_number "
                      + "FROM examregistration r "
                      + "LEFT JOIN student s ON r.studentId = s.student_id "
                      + "WHERE r.examId = ? ORDER BY s.roll_number ASC, r.studentName ASC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(stuSql)) {
            ps.setString(1, examId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    studentBox.addItem(rs.getString("studentId") + " - " + rs.getString("roll_number") + " - " + rs.getString("studentName"));
                }
            }
        } catch (SQLException ignored) {}
    }

    /**
     * Requirement 8: Load Student Marks and Results.
     * Displays Student ID, Roll Number, Student Name, Exam, Subject, Marks, Total Marks, Grade, Result Status.
     */
    private void loadMarksAndResults() {
        model.setRowCount(0);

        StringBuilder sql = new StringBuilder(
            "SELECT m.mark_id, m.student_id, COALESCE(s.roll_number, 'N/A') AS roll_number, "
            + "COALESCE(s.student_name, 'N/A') AS student_name, "
            + "CONCAT(m.exam_id, ' - ', COALESCE(e.exam_name, '')) AS exam_display, "
            + "CONCAT(m.subject_id, ' - ', COALESCE(sub.subject_name, '')) AS subject_display, "
            + "m.marks_obtained, m.max_marks, "
            + "ROUND((m.marks_obtained / m.max_marks) * 100, 1) AS percentage, "
            + "COALESCE(r.grade, CASE WHEN (m.marks_obtained/m.max_marks)*100 >= 90 THEN 'O' "
            + "                       WHEN (m.marks_obtained/m.max_marks)*100 >= 80 THEN 'A+' "
            + "                       WHEN (m.marks_obtained/m.max_marks)*100 >= 70 THEN 'A' "
            + "                       WHEN (m.marks_obtained/m.max_marks)*100 >= 60 THEN 'B' "
            + "                       WHEN (m.marks_obtained/m.max_marks)*100 >= 50 THEN 'C' ELSE 'F' END) AS grade, "
            + "COALESCE(r.status, CASE WHEN (m.marks_obtained/m.max_marks)*100 >= 50 THEN 'Pass' ELSE 'Fail' END) AS status "
            + "FROM marks m "
            + "LEFT JOIN student s ON m.student_id = s.student_id "
            + "LEFT JOIN exam e ON m.exam_id = e.exam_id "
            + "LEFT JOIN subject sub ON m.subject_id = sub.subject_id "
            + "LEFT JOIN results r ON (m.exam_id = r.exam_id AND m.student_id = r.student_id) "
            + "WHERE 1=1 "
        );

        String examSel = (filterExamBox.getSelectedItem() != null) ? filterExamBox.getSelectedItem().toString() : "";
        if (!examSel.isEmpty() && !examSel.equalsIgnoreCase("All Exams")) {
            sql.append(" AND m.exam_id = ? ");
        }

        String stSel = (filterStatusBox.getSelectedItem() != null) ? filterStatusBox.getSelectedItem().toString() : "";
        if (!stSel.isEmpty() && !stSel.equalsIgnoreCase("All Statuses")) {
            sql.append(" AND (r.status = ? OR (r.status IS NULL AND CASE WHEN (m.marks_obtained/m.max_marks)*100 >= 50 THEN 'Pass' ELSE 'Fail' END = ?)) ");
        }

        sql.append(" ORDER BY m.exam_id ASC, s.roll_number ASC, m.mark_id DESC");

        int count = 0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int pIdx = 1;
            if (!examSel.isEmpty() && !examSel.equalsIgnoreCase("All Exams")) {
                ps.setString(pIdx++, examSel.split(" - ")[0].trim());
            }
            if (!stSel.isEmpty() && !stSel.equalsIgnoreCase("All Statuses")) {
                ps.setString(pIdx++, stSel);
                ps.setString(pIdx++, stSel);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    count++;
                    double pct = rs.getDouble("percentage");
                    model.addRow(new Object[]{
                        rs.getString("student_id"),
                        rs.getString("roll_number"),
                        rs.getString("student_name"),
                        rs.getString("exam_display"),
                        rs.getString("subject_display"),
                        rs.getDouble("marks_obtained"),
                        rs.getDouble("max_marks"),
                        String.format("%.1f%%", pct),
                        rs.getString("grade"),
                        rs.getString("status")
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading marks: " + ex.getMessage());
        }

        recordCountLbl.setText("Total Records: " + count);
    }

    private void searchMarks() {
        String input = searchField.getText().trim();
        if (input.isEmpty()) {
            loadMarksAndResults();
            return;
        }

        model.setRowCount(0);
        String sql = "SELECT m.mark_id, m.student_id, COALESCE(s.roll_number, 'N/A') AS roll_number, "
                   + "COALESCE(s.student_name, 'N/A') AS student_name, "
                   + "CONCAT(m.exam_id, ' - ', COALESCE(e.exam_name, '')) AS exam_display, "
                   + "CONCAT(m.subject_id, ' - ', COALESCE(sub.subject_name, '')) AS subject_display, "
                   + "m.marks_obtained, m.max_marks, "
                   + "ROUND((m.marks_obtained / m.max_marks) * 100, 1) AS percentage, "
                   + "COALESCE(r.grade, 'C') AS grade, COALESCE(r.status, 'Pass') AS status "
                   + "FROM marks m "
                   + "LEFT JOIN student s ON m.student_id = s.student_id "
                   + "LEFT JOIN exam e ON m.exam_id = e.exam_id "
                   + "LEFT JOIN subject sub ON m.subject_id = sub.subject_id "
                   + "LEFT JOIN results r ON (m.exam_id = r.exam_id AND m.student_id = r.student_id) "
                   + "WHERE m.student_id LIKE ? OR s.roll_number LIKE ? OR s.student_name LIKE ? OR m.exam_id LIKE ? OR m.subject_id LIKE ? "
                   + "ORDER BY m.exam_id ASC, s.roll_number ASC, m.mark_id DESC";

        int matchCount = 0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String pat = "%" + input + "%";
            ps.setString(1, pat);
            ps.setString(2, pat);
            ps.setString(3, pat);
            ps.setString(4, pat);
            ps.setString(5, pat);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    matchCount++;
                    double pct = rs.getDouble("percentage");
                    model.addRow(new Object[]{
                        rs.getString("student_id"),
                        rs.getString("roll_number"),
                        rs.getString("student_name"),
                        rs.getString("exam_display"),
                        rs.getString("subject_display"),
                        rs.getDouble("marks_obtained"),
                        rs.getDouble("max_marks"),
                        String.format("%.1f%%", pct),
                        rs.getString("grade"),
                        rs.getString("status")
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage());
        }

        recordCountLbl.setText("Search Results: " + matchCount);
        if (matchCount == 0) {
            JOptionPane.showMessageDialog(this, "No records found matching: " + input);
        }
    }

    // =========================================================================
    // FACULTY OPERATIONS (PRESERVED EXCLUSIVELY FOR FACULTY ROLE)
    // =========================================================================
    private void saveMarks(boolean isUpdate) {
        if (isViewOnly) {
            JOptionPane.showMessageDialog(this, "Action Denied: Administrator has view-only access to Marks and Results.", "Access Denied", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (examBox.getSelectedIndex() <= 0 || subjectBox.getSelectedIndex() <= 0 || studentBox.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Please select Exam, Subject, and Student.");
            return;
        }

        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();
        String subjectId = subjectBox.getSelectedItem().toString().split(" - ")[0].trim();
        String studentId = studentBox.getSelectedItem().toString().split(" - ")[0].trim();

        double marksObtained;
        double maxMarks;

        try {
            marksObtained = Double.parseDouble(marksField.getText().trim());
            maxMarks = Double.parseDouble(maxMarksField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Marks and Max Marks must be valid numbers.");
            return;
        }

        if (marksObtained < 0 || marksObtained > maxMarks) {
            JOptionPane.showMessageDialog(this, "Marks obtained must be between 0 and " + maxMarks + ".");
            return;
        }

        String remarks = remarksField.getText().trim();

        // Calculate Grade and Pass/Fail (Pass criteria >= 50%)
        double percentage = (marksObtained / maxMarks) * 100.0;
        String grade;
        String status = (percentage >= 50.0) ? "Pass" : "Fail";

        if (percentage >= 90.0) grade = "O";
        else if (percentage >= 80.0) grade = "A+";
        else if (percentage >= 70.0) grade = "A";
        else if (percentage >= 60.0) grade = "B";
        else if (percentage >= 50.0) grade = "C";
        else grade = "F";

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                // Upsert marks
                String markSql = "INSERT INTO marks (exam_id, student_id, subject_id, marks_obtained, max_marks, remarks, entered_by) "
                               + "VALUES (?, ?, ?, ?, ?, ?, ?) "
                               + "ON DUPLICATE KEY UPDATE marks_obtained = VALUES(marks_obtained), max_marks = VALUES(max_marks), remarks = VALUES(remarks)";

                try (PreparedStatement ps = con.prepareStatement(markSql)) {
                    ps.setString(1, examId);
                    ps.setString(2, studentId);
                    ps.setString(3, subjectId);
                    ps.setDouble(4, marksObtained);
                    ps.setDouble(5, maxMarks);
                    ps.setString(6, remarks);
                    ps.setString(7, userRole + " (" + userEmail + ")");
                    ps.executeUpdate();
                }

                // Upsert results table
                String resSql = "INSERT INTO results (exam_id, student_id, total_marks, max_total_marks, percentage, grade, status) "
                              + "VALUES (?, ?, ?, ?, ?, ?, ?) "
                              + "ON DUPLICATE KEY UPDATE total_marks = VALUES(total_marks), max_total_marks = VALUES(max_total_marks), "
                              + "percentage = VALUES(percentage), grade = VALUES(grade), status = VALUES(status)";

                try (PreparedStatement ps = con.prepareStatement(resSql)) {
                    ps.setString(1, examId);
                    ps.setString(2, studentId);
                    ps.setDouble(3, marksObtained);
                    ps.setDouble(4, maxMarks);
                    ps.setDouble(5, percentage);
                    ps.setString(6, grade);
                    ps.setString(7, status);
                    ps.executeUpdate();
                }

                con.commit();
                JOptionPane.showMessageDialog(this,
                    "Marks & Results Recorded Successfully!\n"
                    + "Candidate ID: " + studentId + "\n"
                    + "Marks: " + marksObtained + " / " + maxMarks + "\n"
                    + "Percentage: " + String.format("%.1f", percentage) + "%\n"
                    + "Grade: " + grade + " (" + status + ")",
                    "Evaluation Completed", JOptionPane.INFORMATION_MESSAGE);

                clearForm();
                loadMarksAndResults();

            } catch (SQLException ex) {
                con.rollback();
                throw ex;
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error saving marks: " + ex.getMessage());
        }
    }

    private void deleteMarks() {
        if (isViewOnly) {
            JOptionPane.showMessageDialog(this, "Action Denied: Administrator has view-only access to Marks and Results.", "Access Denied", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String idStr = markIdField.getText().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a mark record from the table to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to delete Mark record ID " + idStr + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM marks WHERE mark_id = ?")) {
            ps.setInt(1, Integer.parseInt(idStr));
            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Mark record deleted successfully!");
                clearForm();
                loadMarksAndResults();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Delete error: " + ex.getMessage());
        }
    }

    private void clearForm() {
        if (markIdField != null) markIdField.setText("");
        if (examBox != null && examBox.getItemCount() > 0) examBox.setSelectedIndex(0);
        if (studentBox != null) {
            studentBox.removeAllItems();
            studentBox.addItem("Select Student");
        }
        if (marksField != null) marksField.setText("");
        if (maxMarksField != null) maxMarksField.setText("100");
        if (remarksField != null) remarksField.setText("Regular");
        table.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminMarksResults::new);
    }
}
