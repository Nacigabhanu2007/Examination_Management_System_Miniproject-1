package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminSettings extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTextField emailField;
    private JPasswordField currentPasswordField;
    private JPasswordField newPasswordField;
    private JPasswordField confirmPasswordField;

    public AdminSettings() {
        setTitle("Examination Management System - Admin Settings");
        setSize(560, 580);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "ADMIN SECURITY SETTINGS",
                "Update administrative account email and system access credentials"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Form Card
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(20, 25, 20, 25));

        JPanel formCard = new JPanel(new GridLayout(4, 1, 10, 14));
        formCard.setBackground(CARD_BG);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(20, 25, 20, 25)
        ));

        emailField = new JTextField();
        currentPasswordField = new JPasswordField();
        newPasswordField = new JPasswordField();
        confirmPasswordField = new JPasswordField();

        formCard.add(createFieldPanel("New Email Address", emailField));
        formCard.add(createFieldPanel("Current Password (Required)", currentPasswordField));
        formCard.add(createFieldPanel("New Password (Optional)", newPasswordField));
        formCard.add(createFieldPanel("Confirm New Password", confirmPasswordField));

        contentPanel.add(formCard, BorderLayout.CENTER);

        // Buttons
        JPanel buttonBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        buttonBar.setBackground(BG_LIGHT);

        JButton cancelBtn = createButton("Cancel", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton saveButton = createButton("Save Settings", PRIMARY_BLUE, PRIMARY_HOVER);

        buttonBar.add(cancelBtn);
        buttonBar.add(saveButton);
        contentPanel.add(buttonBar, BorderLayout.SOUTH);

        cancelBtn.addActionListener(e -> dispose());
        saveButton.addActionListener(e -> updateAdmin());

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        setContentPane(mainPanel);
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private JPanel createFieldPanel(String label, JComponent field) {
        JPanel fieldPanel = new JPanel(new BorderLayout(0, 5));
        fieldPanel.setOpaque(false);

        JLabel title = new JLabel(label);
        title.setFont(FONT_LABEL);
        title.setForeground(TEXT_DARK);

        field.setFont(FONT_INPUT);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(7, 10, 7, 10)
        ));

        fieldPanel.add(title, BorderLayout.NORTH);
        fieldPanel.add(field, BorderLayout.CENTER);
        return fieldPanel;
    }

    private void updateAdmin() {
        String email = emailField.getText().trim();
        String currentPassword = new String(currentPasswordField.getPassword());
        String newPassword = new String(newPasswordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        if (email.isEmpty() || currentPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the new email and current password.");
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            JOptionPane.showMessageDialog(this, "Enter a valid email address.");
            return;
        }

        if (!newPassword.isEmpty()) {
            if (newPassword.length() < 8
                    || !newPassword.matches(".*[A-Z].*")
                    || !newPassword.matches(".*[a-z].*")
                    || !newPassword.matches(".*\\d.*")
                    || !newPassword.matches(".*[^A-Za-z0-9].*")) {

                JOptionPane.showMessageDialog(this,
                        "New password must contain at least 8 characters,\n"
                        + "uppercase, lowercase, number and special character.");
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this, "New passwords do not match.");
                return;
            }

        } else if (!confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Leave both new password fields empty to keep your password.");
            return;
        }

        String currentHash = hashPassword(currentPassword);

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            try {
                int adminId;
                String existingHash;

                String checkSql = "SELECT user_id, password_hash FROM Users WHERE role = ?";

                try (PreparedStatement ps = con.prepareStatement(checkSql)) {
                    ps.setString(1, "Admin");

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException("Admin account was not found.");
                        }
                        adminId = rs.getInt("user_id");
                        existingHash = rs.getString("password_hash");
                    }
                }

                if (!currentHash.equals(existingHash)) {
                    con.rollback();
                    JOptionPane.showMessageDialog(this, "Current password is incorrect.");
                    return;
                }

                String updateSql;
                if (newPassword.isEmpty()) {
                    updateSql = "UPDATE Users SET email = ? WHERE user_id = ? AND role = ?";
                } else {
                    updateSql = "UPDATE Users SET email = ?, password_hash = ? WHERE user_id = ? AND role = ?";
                }

                try (PreparedStatement ps = con.prepareStatement(updateSql)) {
                    ps.setString(1, email);

                    if (newPassword.isEmpty()) {
                        ps.setInt(2, adminId);
                        ps.setString(3, "Admin");
                    } else {
                        ps.setString(2, hashPassword(newPassword));
                        ps.setInt(3, adminId);
                        ps.setString(4, "Admin");
                    }

                    ps.executeUpdate();
                }

                con.commit();
                JOptionPane.showMessageDialog(this,
                        "Admin settings updated successfully!\nUse your updated email and password next time.");
                dispose();

            } catch (SQLException e) {
                con.rollback();
                throw e;
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(this, "This email address is already in use.");
            } else {
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            }
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Password hashing failed.", e);
        }
    }
}
