package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.time.LocalDate;

public class AdminStaffAllocation extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTextField idField;
    private JComboBox<String> examBox;
    private JComboBox<String> facultyBox;
    private JTextField dateField;
    private JComboBox<String> sessionBox;
    private JComboBox<String> hallBox;
    private JComboBox<String> roleBox;

    private JTable table;
    private DefaultTableModel model;

    private boolean isUpdating = false;

    public AdminStaffAllocation() {
        setTitle("Examination Management System - Staff Allocation");
        setSize(1200, 760);
        setMinimumSize(new Dimension(1000, 660));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "STAFF ALLOCATION MANAGEMENT",
                "Assign faculty members to examination halls, invigilation sessions, and supervisory duties"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Table
        String[] columns = {
            "Alloc ID", "Exam ID", "Exam Name", "Faculty ID", "Faculty Name", "Duty Date", "Session", "Hall", "Duty Role"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(model);
        styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Form Card
        JPanel formCard = new JPanel(new BorderLayout(0, 12));
        formCard.setBackground(CARD_BG);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(15, 20, 15, 20)
        ));

        JLabel formTitle = new JLabel("Invigilation Duty Assignment Details");
        formTitle.setFont(FONT_HEADER);
        formTitle.setForeground(PRIMARY_BLUE);
        formCard.add(formTitle, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridLayout(2, 4, 12, 10));
        formGrid.setOpaque(false);

        idField = new JTextField();
        idField.setEditable(false);
        idField.setFont(FONT_INPUT);
        idField.setBackground(new Color(241, 245, 249));
        idField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        examBox = new JComboBox<>();
        examBox.setFont(FONT_INPUT);

        facultyBox = new JComboBox<>();
        facultyBox.setFont(FONT_INPUT);

        dateField = new JTextField(LocalDate.now().toString());
        dateField.setFont(FONT_INPUT);
        dateField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        sessionBox = new JComboBox<>(new String[]{
            "Morning (09:30 AM - 12:30 PM)",
            "Afternoon (01:30 PM - 04:30 PM)",
            "Evening (05:00 PM - 08:00 PM)"
        });
        sessionBox.setFont(FONT_INPUT);

        hallBox = new JComboBox<>();
        hallBox.setFont(FONT_INPUT);

        roleBox = new JComboBox<>(new String[]{
            "Hall Invigilator",
            "Chief Superintendent",
            "Squad Member",
            "Reliever",
            "Exam Coordinator"
        });
        roleBox.setFont(FONT_INPUT);

        addGridField(formGrid, "Allocation ID (Auto)", idField);
        addGridField(formGrid, "Select Exam", examBox);
        addGridField(formGrid, "Select Faculty", facultyBox);
        addGridField(formGrid, "Duty Date (YYYY-MM-DD)", dateField);

        addGridField(formGrid, "Session / Time", sessionBox);
        addGridField(formGrid, "Hall Number", hallBox);
        addGridField(formGrid, "Duty Role", roleBox);

        // Blank placeholder to keep 2x4 grid tidy
        JPanel blankPanel = new JPanel();
        blankPanel.setOpaque(false);
        formGrid.add(blankPanel);

        formCard.add(formGrid, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        buttonPanel.setOpaque(false);

        JButton saveButton = createButton("Save Allocation", SUCCESS_GREEN, SUCCESS_HOVER);
        JButton searchButton = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton updateButton = createButton("Update", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton deleteButton = createButton("Delete", DANGER_RED, DANGER_HOVER);
        JButton refreshButton = createButton("Refresh / Clear", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backButton = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        buttonPanel.add(backButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(saveButton);

        formCard.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.add(formCard, BorderLayout.SOUTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Actions
        saveButton.addActionListener(e -> saveAllocation());
        searchButton.addActionListener(e -> searchAllocation());
        refreshButton.addActionListener(e -> {
            clearForm();
            loadAllocations();
        });
        updateButton.addActionListener(e -> updateAllocation());
        deleteButton.addActionListener(e -> deleteAllocation());
        backButton.addActionListener(e -> dispose());

        examBox.addActionListener(e -> {
            if (!isUpdating && examBox.getSelectedIndex() > 0) {
                syncExamDate();
            }
        });

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                isUpdating = true;

                idField.setText(model.getValueAt(row, 0).toString());
                String examId = model.getValueAt(row, 1).toString();
                String facultyId = model.getValueAt(row, 3).toString();

                for (int i = 0; i < examBox.getItemCount(); i++) {
                    if (examBox.getItemAt(i).startsWith(examId)) {
                        examBox.setSelectedIndex(i);
                        break;
                    }
                }

                for (int i = 0; i < facultyBox.getItemCount(); i++) {
                    if (facultyBox.getItemAt(i).startsWith(facultyId + " - ")) {
                        facultyBox.setSelectedIndex(i);
                        break;
                    }
                }

                dateField.setText(model.getValueAt(row, 5).toString());
                sessionBox.setSelectedItem(model.getValueAt(row, 6).toString());

                String hall = model.getValueAt(row, 7).toString();
                for (int i = 0; i < hallBox.getItemCount(); i++) {
                    if (hallBox.getItemAt(i).startsWith(hall)) {
                        hallBox.setSelectedIndex(i);
                        break;
                    }
                }

                roleBox.setSelectedItem(model.getValueAt(row, 8).toString());
                isUpdating = false;
            }
        });

        loadExams();
        loadFaculty();
        loadHalls();
        loadAllocations();

        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void addGridField(JPanel panel, String label, JComponent field) {
        JPanel fGroup = new JPanel(new BorderLayout(0, 5));
        fGroup.setOpaque(false);

        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        fGroup.add(lbl, BorderLayout.NORTH);
        fGroup.add(field, BorderLayout.CENTER);
        panel.add(fGroup);
    }

    private void loadExams() {
        examBox.removeAllItems();
        examBox.addItem("Select Exam");
        String sql = "SELECT e.exam_id, e.exam_name, e.exam_date, e.subject_id, s.subject_name "
                   + "FROM exam e LEFT JOIN subject s ON e.subject_id = s.subject_id ORDER BY e.exam_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String sub = rs.getString("subject_id");
                String subText = (sub != null && !sub.isEmpty()) ? " [" + sub + "]" : "";
                examBox.addItem(rs.getString("exam_id") + " - " + rs.getString("exam_name") + subText);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading exams: " + ex.getMessage());
        }
    }

    private void loadFaculty() {
        facultyBox.removeAllItems();
        facultyBox.addItem("Select Faculty");
        String sql = "SELECT faculty_id, faculty_name, department FROM faculty ORDER BY faculty_name";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                facultyBox.addItem(rs.getInt("faculty_id") + " - " + rs.getString("faculty_name") + " (" + rs.getString("department") + ")");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading faculty: " + ex.getMessage());
        }
    }

    private void loadHalls() {
        hallBox.removeAllItems();
        hallBox.addItem("Select Hall");
        String sql = "SELECT hall_number, hall_name FROM hall ORDER BY hall_number";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                hallBox.addItem(rs.getString("hall_number") + " - " + rs.getString("hall_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading halls: " + ex.getMessage());
        }
    }

    private void syncExamDate() {
        String selected = (String) examBox.getSelectedItem();
        if (selected == null || selected.equals("Select Exam")) return;

        String examId = selected.split(" - ")[0].trim();
        String sql = "SELECT exam_date, start_time, end_time FROM exam WHERE exam_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, examId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Date d = rs.getDate("exam_date");
                    if (d != null) {
                        dateField.setText(d.toString());
                    }
                }
            }
        } catch (SQLException ex) {
            // ignore
        }
    }

    private void loadAllocations() {
        model.setRowCount(0);
        String sql = "SELECT sa.allocation_id, sa.exam_id, e.exam_name, sa.faculty_id, f.faculty_name, "
                   + "sa.duty_date, sa.session_time, sa.hall_number, sa.duty_role "
                   + "FROM staff_allocation sa "
                   + "JOIN exam e ON sa.exam_id = e.exam_id "
                   + "JOIN faculty f ON sa.faculty_id = f.faculty_id "
                   + "ORDER BY sa.duty_date DESC, sa.allocation_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("allocation_id"),
                    rs.getString("exam_id"),
                    rs.getString("exam_name"),
                    rs.getInt("faculty_id"),
                    rs.getString("faculty_name"),
                    rs.getDate("duty_date"),
                    rs.getString("session_time"),
                    rs.getString("hall_number"),
                    rs.getString("duty_role")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading staff allocations: " + ex.getMessage());
        }
    }

    private void saveAllocation() {
        if (examBox.getSelectedIndex() <= 0 || facultyBox.getSelectedIndex() <= 0 || hallBox.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Please select Exam, Faculty, and Hall.");
            return;
        }

        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();
        int facultyId = Integer.parseInt(facultyBox.getSelectedItem().toString().split(" - ")[0].trim());
        String dutyDate = dateField.getText().trim();
        String sessionTime = sessionBox.getSelectedItem().toString();
        String hall = hallBox.getSelectedItem().toString().split(" - ")[0].trim();
        String role = roleBox.getSelectedItem().toString();

        if (dutyDate.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Duty date is required.");
            return;
        }

        // Duplicate conflict check
        String checkSql = "SELECT COUNT(*) FROM staff_allocation WHERE faculty_id = ? AND duty_date = ? AND session_time = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement checkPs = con.prepareStatement(checkSql)) {

            checkPs.setInt(1, facultyId);
            checkPs.setDate(2, Date.valueOf(dutyDate));
            checkPs.setString(3, sessionTime);

            try (ResultSet checkRs = checkPs.executeQuery()) {
                if (checkRs.next() && checkRs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this,
                        "Conflict detected! This faculty member is already assigned to a duty on " + dutyDate + " during " + sessionTime + ".",
                        "Allocation Conflict", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }

            String insertSql = "INSERT INTO staff_allocation "
                             + "(exam_id, faculty_id, duty_date, session_time, hall_number, duty_role) "
                             + "VALUES (?, ?, ?, ?, ?, ?)";

            try (PreparedStatement ps = con.prepareStatement(insertSql)) {
                ps.setString(1, examId);
                ps.setInt(2, facultyId);
                ps.setDate(3, Date.valueOf(dutyDate));
                ps.setString(4, sessionTime);
                ps.setString(5, hall);
                ps.setString(6, role);

                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Staff allocated successfully!");
                clearForm();
                loadAllocations();
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Invalid date format. Use YYYY-MM-DD.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private void searchAllocation() {
        String input = JOptionPane.showInputDialog(this, "Enter Faculty ID, Name, or Exam ID to search:");
        if (input == null || input.trim().isEmpty()) return;

        model.setRowCount(0);
        String sql = "SELECT sa.allocation_id, sa.exam_id, e.exam_name, sa.faculty_id, f.faculty_name, "
                   + "sa.duty_date, sa.session_time, sa.hall_number, sa.duty_role "
                   + "FROM staff_allocation sa "
                   + "JOIN exam e ON sa.exam_id = e.exam_id "
                   + "JOIN faculty f ON sa.faculty_id = f.faculty_id "
                   + "WHERE sa.exam_id LIKE ? OR f.faculty_name LIKE ? OR CAST(sa.faculty_id AS CHAR) = ? "
                   + "ORDER BY sa.duty_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            String pat = "%" + input.trim() + "%";
            ps.setString(1, pat);
            ps.setString(2, pat);
            ps.setString(3, input.trim());

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("allocation_id"),
                        rs.getString("exam_id"),
                        rs.getString("exam_name"),
                        rs.getInt("faculty_id"),
                        rs.getString("faculty_name"),
                        rs.getDate("duty_date"),
                        rs.getString("session_time"),
                        rs.getString("hall_number"),
                        rs.getString("duty_role")
                    });
                }
            }

            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No allocations found matching: " + input);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Search error: " + ex.getMessage());
        }
    }

    private void updateAllocation() {
        String idStr = idField.getText().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an allocation from the table first.");
            return;
        }

        int allocId = Integer.parseInt(idStr);
        String examId = examBox.getSelectedItem().toString().split(" - ")[0].trim();
        int facultyId = Integer.parseInt(facultyBox.getSelectedItem().toString().split(" - ")[0].trim());
        String dutyDate = dateField.getText().trim();
        String sessionTime = sessionBox.getSelectedItem().toString();
        String hall = hallBox.getSelectedItem().toString().split(" - ")[0].trim();
        String role = roleBox.getSelectedItem().toString();

        String updateSql = "UPDATE staff_allocation SET exam_id = ?, faculty_id = ?, duty_date = ?, "
                         + "session_time = ?, hall_number = ?, duty_role = ? WHERE allocation_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(updateSql)) {

            ps.setString(1, examId);
            ps.setInt(2, facultyId);
            ps.setDate(3, Date.valueOf(dutyDate));
            ps.setString(4, sessionTime);
            ps.setString(5, hall);
            ps.setString(6, role);
            ps.setInt(7, allocId);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Staff allocation updated successfully!");
                clearForm();
                loadAllocations();
            } else {
                JOptionPane.showMessageDialog(this, "Allocation record not found.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Update error: " + ex.getMessage());
        }
    }

    private void deleteAllocation() {
        String idStr = idField.getText().trim();
        if (idStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an allocation from the table to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to remove allocation ID " + idStr + "?",
            "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) return;

        String sql = "DELETE FROM staff_allocation WHERE allocation_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, Integer.parseInt(idStr));
            int rows = ps.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Allocation removed successfully!");
                clearForm();
                loadAllocations();
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Delete failed: " + ex.getMessage());
        }
    }

    private void clearForm() {
        idField.setText("");
        examBox.setSelectedIndex(0);
        facultyBox.setSelectedIndex(0);
        hallBox.setSelectedIndex(0);
        sessionBox.setSelectedIndex(0);
        roleBox.setSelectedIndex(0);
        dateField.setText(LocalDate.now().toString());
        table.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminStaffAllocation::new);
    }
}
