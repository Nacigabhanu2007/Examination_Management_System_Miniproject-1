package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * AdminStudentManagement
 * Administrator interface for student records.
 * Supports Academic Year Tabs (1st, 2nd, 3rd, 4th Year), Department-wise sorting,
 * Ascending Roll Number ordering, View/Search, Add Student dialog, Update & Delete.
 */
public class AdminStudentManagement extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTable studentTable;
    private DefaultTableModel model;

    private JTextField searchField;
    private JComboBox<String> deptFilterBox;
    private JLabel statusFilterLbl;

    // Year selection: 0 = All, 1 = 1st Year, 2 = 2nd Year, 3 = 3rd Year, 4 = 4th Year
    private int selectedYearFilter = 0;
    private JButton btnYearAll;
    private JButton btnYear1;
    private JButton btnYear2;
    private JButton btnYear3;
    private JButton btnYear4;

    // Edit fields
    private JTextField idField;
    private JTextField rollNumberField;
    private JTextField nameField;
    private JComboBox<String> departmentBox;
    private JTextField yearField;
    private JTextField semesterField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField registerNumberField;

    private String selectedStudentId = null;

    public AdminStudentManagement() {
        setTitle("Examination Management System - Student Management");
        setSize(1260, 820);
        setMinimumSize(new Dimension(1050, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "STUDENT ENROLLMENT & ACADEMIC MANAGEMENT",
                "Year-wise & department-wise student registry with automatic alphabetical roll numbers"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 12));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(12, 20, 15, 20));

        // TOP CONTROLS: Year Tabs + Search & Filters
        JPanel topContainer = new JPanel();
        topContainer.setLayout(new BoxLayout(topContainer, BoxLayout.Y_AXIS));
        topContainer.setOpaque(false);

        // 1. Academic Year Tabs Panel
        JPanel yearTabsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        yearTabsPanel.setBackground(CARD_BG);
        yearTabsPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(6, 12, 6, 12)
        ));

        JLabel tabTitle = new JLabel("Academic Year Filter: ");
        tabTitle.setFont(FONT_LABEL);
        tabTitle.setForeground(NAVY);
        yearTabsPanel.add(tabTitle);

        btnYearAll = createTabButton("All Students", 0);
        btnYear1 = createTabButton("First Year (1st Yr)", 1);
        btnYear2 = createTabButton("Second Year (2nd Yr)", 2);
        btnYear3 = createTabButton("Third Year (3rd Yr)", 3);
        btnYear4 = createTabButton("Fourth Year (4th Yr)", 4);

        yearTabsPanel.add(btnYearAll);
        yearTabsPanel.add(btnYear1);
        yearTabsPanel.add(btnYear2);
        yearTabsPanel.add(btnYear3);
        yearTabsPanel.add(btnYear4);

        // Department quick filter
        JLabel deptFilterLbl = new JLabel("   Department:");
        deptFilterLbl.setFont(FONT_LABEL);
        deptFilterLbl.setForeground(NAVY);
        yearTabsPanel.add(deptFilterLbl);

        deptFilterBox = new JComboBox<>();
        deptFilterBox.setFont(FONT_INPUT);
        loadFilterDepartments();
        deptFilterBox.addActionListener(e -> loadStudents());
        yearTabsPanel.add(deptFilterBox);

        topContainer.add(yearTabsPanel);
        topContainer.add(Box.createVerticalStrut(8));

        // 2. Search and Action Bar
        JPanel searchBar = new JPanel(new BorderLayout());
        searchBar.setBackground(CARD_BG);
        searchBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(8, 14, 8, 14)
        ));

        JPanel searchGroup = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchGroup.setOpaque(false);

        JLabel searchLbl = new JLabel("Search (ID / Roll No / Name / Email):");
        searchLbl.setFont(FONT_LABEL);
        searchGroup.add(searchLbl);

        searchField = new JTextField(18);
        searchField.setFont(FONT_INPUT);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        searchGroup.add(searchField);

        JButton searchButton = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton refreshButton = createButton("Refresh", SECONDARY_GRAY, SECONDARY_HOVER);
        searchGroup.add(searchButton);
        searchGroup.add(refreshButton);

        statusFilterLbl = new JLabel("All Enrolled Students");
        statusFilterLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        statusFilterLbl.setForeground(PRIMARY_BLUE);
        searchGroup.add(Box.createHorizontalStrut(10));
        searchGroup.add(statusFilterLbl);

        JPanel actionGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionGroup.setOpaque(false);
        JButton addStudentBtn = createButton("+ Add Student", SUCCESS_GREEN, SUCCESS_HOVER);
        addStudentBtn.setPreferredSize(new Dimension(145, 34));
        actionGroup.add(addStudentBtn);

        searchBar.add(searchGroup, BorderLayout.WEST);
        searchBar.add(actionGroup, BorderLayout.EAST);
        topContainer.add(searchBar);

        contentPanel.add(topContainer, BorderLayout.NORTH);

        // Table
        String[] columns = {
                "Student ID", "Roll Number", "Full Name", "Department", "Year", "Semester",
                "Email Address", "Phone", "Degree", "Register No"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        studentTable = new JTable(model);
        styleTable(studentTable);
        studentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(studentTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Form Edit Card
        JPanel editCard = new JPanel(new BorderLayout(0, 10));
        editCard.setBackground(CARD_BG);
        editCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(12, 18, 12, 18)
        ));

        JLabel editTitle = new JLabel("Student Profile Details & Management");
        editTitle.setFont(FONT_HEADER);
        editTitle.setForeground(PRIMARY_BLUE);
        editCard.add(editTitle, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridLayout(2, 5, 10, 8));
        formGrid.setOpaque(false);

        idField = createFormField(false);
        rollNumberField = createFormField(false);
        rollNumberField.setToolTipText("Roll Number is automatically generated department-wise and year-wise in alphabetical order.");
        nameField = createFormField(true);

        departmentBox = new JComboBox<>();
        departmentBox.setFont(FONT_INPUT);
        loadFormDepartments();

        yearField = createFormField(true);
        semesterField = createFormField(true);
        emailField = createFormField(true);
        phoneField = createFormField(true);
        registerNumberField = createFormField(true);

        addGridField(formGrid, "Student ID (Permanent Key)", idField);
        addGridField(formGrid, "Roll Number (Auto-Generated)", rollNumberField);
        addGridField(formGrid, "Full Name", nameField);
        addGridField(formGrid, "Department", departmentBox);
        addGridField(formGrid, "Year (1 - 4)", yearField);
        addGridField(formGrid, "Semester", semesterField);
        addGridField(formGrid, "Email Address", emailField);
        addGridField(formGrid, "Phone Number", phoneField);
        addGridField(formGrid, "Register Number", registerNumberField);

        // Placeholder for grid layout
        JPanel blank = new JPanel();
        blank.setOpaque(false);
        formGrid.add(blank);

        editCard.add(formGrid, BorderLayout.CENTER);

        // Buttons
        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        btnBar.setOpaque(false);

        JButton updateBtn = createButton("Update Student", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton deleteBtn = createButton("Delete Student", DANGER_RED, DANGER_HOVER);
        JButton clearBtn = createButton("Clear Selection", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backBtn = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        btnBar.add(backBtn);
        btnBar.add(clearBtn);
        btnBar.add(deleteBtn);
        btnBar.add(updateBtn);
        editCard.add(btnBar, BorderLayout.SOUTH);

        contentPanel.add(editCard, BorderLayout.SOUTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Events
        updateTabButtonStyles();
        loadStudents();

        searchButton.addActionListener(e -> searchStudents());
        searchField.addActionListener(e -> searchStudents());
        refreshButton.addActionListener(e -> {
            searchField.setText("");
            selectedYearFilter = 0;
            if (deptFilterBox.getItemCount() > 0) deptFilterBox.setSelectedIndex(0);
            updateTabButtonStyles();
            clearForm();
            loadStudents();
        });

        addStudentBtn.addActionListener(e -> openAddStudentDialog());

        studentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = studentTable.getSelectedRow();
                if (row >= 0) {
                    selectedStudentId = String.valueOf(model.getValueAt(row, 0));
                    idField.setText(selectedStudentId);
                    rollNumberField.setText(String.valueOf(model.getValueAt(row, 1)));
                    nameField.setText(String.valueOf(model.getValueAt(row, 2)));

                    String dept = String.valueOf(model.getValueAt(row, 3));
                    for (int i = 0; i < departmentBox.getItemCount(); i++) {
                        if (departmentBox.getItemAt(i).equalsIgnoreCase(dept)
                                || departmentBox.getItemAt(i).contains(dept)) {
                            departmentBox.setSelectedIndex(i);
                            break;
                        }
                    }

                    yearField.setText(String.valueOf(model.getValueAt(row, 4)));
                    semesterField.setText(String.valueOf(model.getValueAt(row, 5)));
                    emailField.setText(String.valueOf(model.getValueAt(row, 6)));
                    phoneField.setText(String.valueOf(model.getValueAt(row, 7)));
                    registerNumberField.setText(String.valueOf(model.getValueAt(row, 9)));
                }
            }
        });

        updateBtn.addActionListener(e -> updateStudent());
        deleteBtn.addActionListener(e -> deleteStudent());
        clearBtn.addActionListener(e -> clearForm());
        backBtn.addActionListener(e -> dispose());

        add(mainPanel);
        setVisible(true);
    }

    private JTextField createFormField(boolean editable) {
        JTextField tf = new JTextField();
        tf.setFont(FONT_INPUT);
        tf.setEditable(editable);
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        if (!editable) {
            tf.setBackground(new Color(241, 245, 249));
            tf.setForeground(TEXT_MUTED);
        }
        return tf;
    }

    private JButton createTabButton(String text, int yearVal) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> {
            selectedYearFilter = yearVal;
            updateTabButtonStyles();
            loadStudents();
        });
        return btn;
    }

    private void updateTabButtonStyles() {
        styleOneTab(btnYearAll, selectedYearFilter == 0);
        styleOneTab(btnYear1, selectedYearFilter == 1);
        styleOneTab(btnYear2, selectedYearFilter == 2);
        styleOneTab(btnYear3, selectedYearFilter == 3);
        styleOneTab(btnYear4, selectedYearFilter == 4);

        switch (selectedYearFilter) {
            case 1: statusFilterLbl.setText("Filtered: First Year (1st Yr)"); break;
            case 2: statusFilterLbl.setText("Filtered: Second Year (2nd Yr)"); break;
            case 3: statusFilterLbl.setText("Filtered: Third Year (3rd Yr)"); break;
            case 4: statusFilterLbl.setText("Filtered: Fourth Year (4th Yr)"); break;
            default: statusFilterLbl.setText("All Academic Years"); break;
        }
    }

    private void styleOneTab(JButton btn, boolean isSelected) {
        if (isSelected) {
            btn.setBackground(PRIMARY_BLUE);
            btn.setForeground(Color.WHITE);
        } else {
            btn.setBackground(new Color(241, 245, 249));
            btn.setForeground(TEXT_DARK);
        }
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(16, 25, 16, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(135, 34));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(FONT_INPUT);
        table.setSelectionBackground(new Color(224, 238, 255));
        table.setSelectionForeground(TEXT_DARK);
        table.setGridColor(new Color(241, 245, 249));
        table.setShowVerticalLines(false);

        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(new Color(237, 242, 250));
        th.setForeground(NAVY);
        th.setReorderingAllowed(false);
        th.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        table.getColumnModel().getColumn(0).setCellRenderer(centerRenderer); // Student ID
        table.getColumnModel().getColumn(1).setCellRenderer(centerRenderer); // Roll Number
        table.getColumnModel().getColumn(4).setCellRenderer(centerRenderer); // Year
    }

    private void addGridField(JPanel panel, String labelText, Component comp) {
        JPanel grp = new JPanel(new BorderLayout(0, 3));
        grp.setOpaque(false);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);
        grp.add(lbl, BorderLayout.NORTH);
        grp.add(comp, BorderLayout.CENTER);
        panel.add(grp);
    }

    private void loadFilterDepartments() {
        deptFilterBox.removeAllItems();
        deptFilterBox.addItem("All Departments");
        loadDeptNames(deptFilterBox);
    }

    private void loadFormDepartments() {
        departmentBox.removeAllItems();
        departmentBox.addItem("Select Department");
        loadDeptNames(departmentBox);
    }

    private void loadDeptNames(JComboBox<String> target) {
        String sql = "SELECT department_name FROM department ORDER BY department_name ASC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                target.addItem(rs.getString("department_name"));
            }
        } catch (SQLException ignored) {}
        if (target.getItemCount() <= 1) {
            target.addItem("Computer Science and Engineering");
            target.addItem("Information Technology");
            target.addItem("Electronic and Communication Engineering");
            target.addItem("Electrical and Electronic Engineering");
            target.addItem("Mechanical Engineering");
            target.addItem("Civil Engineering");
        }
    }

    /**
     * Load students from actual MySQL records.
     * Filtered by academic year (if selected) and department (if selected).
     * Arranged department-wise and in ascending Roll Number order.
     */
    private void loadStudents() {
        model.setRowCount(0);

        StringBuilder sql = new StringBuilder(
                "SELECT student_id, roll_number, student_name, department, year, semester, "
                + "email, phone, degree, register_number, admission_year FROM student WHERE 1=1 "
        );

        if (selectedYearFilter > 0) {
            int admYear = RollNumberManager.resolveAdmissionYear(selectedYearFilter, 0);
            sql.append(" AND (year = ").append(selectedYearFilter)
               .append(" OR admission_year = ").append(admYear).append(") ");
        }

        String deptSel = (deptFilterBox.getSelectedItem() != null) ? deptFilterBox.getSelectedItem().toString() : "";
        if (!deptSel.isEmpty() && !deptSel.equalsIgnoreCase("All Departments")) {
            sql.append(" AND department = ? ");
        }

        // Within each year, show students department-wise, ordered by ascending Roll Number
        sql.append(" ORDER BY year ASC, department ASC, roll_number ASC, student_name ASC");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            if (!deptSel.isEmpty() && !deptSel.equalsIgnoreCase("All Departments")) {
                ps.setString(1, deptSel);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getString("student_id"),
                            rs.getString("roll_number"),
                            rs.getString("student_name"),
                            rs.getString("department"),
                            rs.getInt("year"),
                            rs.getString("semester"),
                            rs.getString("email"),
                            rs.getString("phone"),
                            rs.getString("degree"),
                            rs.getString("register_number")
                    });
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load students: " + e.getMessage());
        }
    }

    private void searchStudents() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            loadStudents();
            return;
        }

        model.setRowCount(0);
        String sql = "SELECT student_id, roll_number, student_name, department, year, semester, "
                + "email, phone, degree, register_number FROM student "
                + "WHERE student_id LIKE ? OR roll_number LIKE ? OR student_name LIKE ? OR department LIKE ? OR email LIKE ? "
                + "ORDER BY year ASC, department ASC, roll_number ASC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String pattern = "%" + keyword + "%";
            ps.setString(1, pattern);
            ps.setString(2, pattern);
            ps.setString(3, pattern);
            ps.setString(4, pattern);
            ps.setString(5, pattern);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                            rs.getString("student_id"),
                            rs.getString("roll_number"),
                            rs.getString("student_name"),
                            rs.getString("department"),
                            rs.getInt("year"),
                            rs.getString("semester"),
                            rs.getString("email"),
                            rs.getString("phone"),
                            rs.getString("degree"),
                            rs.getString("register_number")
                    });
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Search error: " + e.getMessage());
        }
    }

    /**
     * Clean Add Student modal dialog for Admin.
     * Avoids opening the initial login/create-account page unnecessarily.
     * Automatically assigns alphabetical roll numbers safely into MySQL.
     */
    private void openAddStudentDialog() {
        JDialog dlg = new JDialog(this, "Add New Student Record", true);
        dlg.setSize(620, 680);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel header = createHeader("ADD STUDENT RECORD", "Enter student enrollment details to assign automatic Roll Number");
        dlg.add(header, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(0, 2, 14, 10));
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));

        JTextField nameF = new JTextField();
        JComboBox<String> deptF = new JComboBox<>();
        loadDeptNames(deptF);

        JComboBox<String> yearF = new JComboBox<>(new String[]{"1st Year", "2nd Year", "3rd Year", "4th Year"});
        JComboBox<String> admYearF = new JComboBox<>(new String[]{"2026", "2025", "2024", "2023"});
        JComboBox<String> semF = new JComboBox<>(new String[]{
                "Semester 1", "Semester 2", "Semester 3", "Semester 4",
                "Semester 5", "Semester 6", "Semester 7", "Semester 8"
        });
        JComboBox<String> degF = new JComboBox<>(new String[]{"B.E", "B.Tech", "M.E", "M.Tech"});
        JTextField emailF = new JTextField();
        JTextField phoneF = new JTextField();
        JTextField dobF = new JTextField("2005-01-15");
        JComboBox<String> genderF = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        JComboBox<String> bloodF = new JComboBox<>(new String[]{"O+", "A+", "B+", "AB+", "O-", "A-", "B-", "AB-"});
        JTextField rollPreviewF = new JTextField("Auto-generated (Alphabetical)");
        rollPreviewF.setEditable(false);
        rollPreviewF.setBackground(new Color(241, 245, 249));

        yearF.addActionListener(e -> {
            int idx = yearF.getSelectedIndex();
            if (idx >= 0 && idx < admYearF.getItemCount()) admYearF.setSelectedIndex(idx);
        });

        admYearF.addActionListener(e -> {
            int idx = admYearF.getSelectedIndex();
            if (idx >= 0 && idx < yearF.getItemCount()) yearF.setSelectedIndex(idx);
        });

        form.add(new JLabel("Full Name *:")); form.add(nameF);
        form.add(new JLabel("Department *:")); form.add(deptF);
        form.add(new JLabel("Current Year *:")); form.add(yearF);
        form.add(new JLabel("Admission Year *:")); form.add(admYearF);
        form.add(new JLabel("Semester *:")); form.add(semF);
        form.add(new JLabel("Degree:")); form.add(degF);
        form.add(new JLabel("Email Address *:")); form.add(emailF);
        form.add(new JLabel("Phone Number *:")); form.add(phoneF);
        form.add(new JLabel("Date of Birth (YYYY-MM-DD):")); form.add(dobF);
        form.add(new JLabel("Gender:")); form.add(genderF);
        form.add(new JLabel("Blood Group:")); form.add(bloodF);
        form.add(new JLabel("Roll Number (Auto):")); form.add(rollPreviewF);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        btnPanel.setBackground(Color.WHITE);
        JButton cancelBtn = createButton("Cancel", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton saveBtn = createButton("Save & Register", SUCCESS_GREEN, SUCCESS_HOVER);
        saveBtn.setPreferredSize(new Dimension(150, 36));

        btnPanel.add(cancelBtn);
        btnPanel.add(saveBtn);

        cancelBtn.addActionListener(e -> dlg.dispose());
        saveBtn.addActionListener(e -> {
            String name = nameF.getText().trim();
            String dept = (String) deptF.getSelectedItem();
            String cy = (String) yearF.getSelectedItem();
            String ay = (String) admYearF.getSelectedItem();
            String sem = (String) semF.getSelectedItem();
            String deg = (String) degF.getSelectedItem();
            String email = emailF.getText().trim();
            String phone = phoneF.getText().trim();
            String dob = dobF.getText().trim();
            String gender = (String) genderF.getSelectedItem();
            String blood = (String) bloodF.getSelectedItem();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                JOptionPane.showMessageDialog(dlg, "Name, Email, and Phone are mandatory fields.");
                return;
            }

            int yrNum = Character.getNumericValue(cy.charAt(0));
            int admYearVal = Integer.parseInt(ay);

            // Generate next student_id
            String stuId = generateNextStudentId(dept);
            String regNo = "REG" + stuId;
            String initialRoll = RollNumberManager.previewNextRollNumber(dept, admYearVal, name);

            try (Connection con = DBConnection.getConnection()) {
                con.setAutoCommit(false);

                // Check duplicate email in users
                try (PreparedStatement chk = con.prepareStatement("SELECT user_id FROM users WHERE email = ?")) {
                    chk.setString(1, email);
                    try (ResultSet rsChk = chk.executeQuery()) {
                        if (rsChk.next()) {
                            JOptionPane.showMessageDialog(dlg, "An account with email " + email + " already exists.");
                            con.rollback();
                            return;
                        }
                    }
                }

                String insStu = "INSERT INTO student (student_id, student_name, department, year, email, phone, "
                              + "roll_number, degree, admission_year, semester, register_number, dob, gender, blood_group) "
                              + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = con.prepareStatement(insStu)) {
                    ps.setString(1, stuId);
                    ps.setString(2, name);
                    ps.setString(3, dept);
                    ps.setInt(4, yrNum);
                    ps.setString(5, email);
                    ps.setString(6, phone);
                    ps.setString(7, initialRoll);
                    ps.setString(8, deg);
                    ps.setInt(9, admYearVal);
                    ps.setString(10, sem);
                    ps.setString(11, regNo);
                    ps.setString(12, dob);
                    ps.setString(13, gender);
                    ps.setString(14, blood);
                    ps.executeUpdate();
                }

                // Create user account with default password: Student@123
                String insUser = "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, 'Student')";
                try (PreparedStatement psUser = con.prepareStatement(insUser)) {
                    psUser.setString(1, stuId.toLowerCase());
                    psUser.setString(2, email);
                    psUser.setString(3, hashPassword("Student@123"));
                    psUser.executeUpdate();
                }

                // Reassign roll numbers alphabetically for this department & admission year
                RollNumberManager.reassignRollNumbers(con, dept, admYearVal);

                String finalRoll = initialRoll;
                try (PreparedStatement psRoll = con.prepareStatement("SELECT roll_number FROM student WHERE student_id = ?")) {
                    psRoll.setString(1, stuId);
                    try (ResultSet rsRoll = psRoll.executeQuery()) {
                        if (rsRoll.next()) finalRoll = rsRoll.getString("roll_number");
                    }
                }

                con.commit();
                JOptionPane.showMessageDialog(dlg, "Student Created Successfully!\n\n"
                        + "Student ID: " + stuId + "\n"
                        + "Assigned Roll Number: " + finalRoll + "\n"
                        + "Default Password: Student@123");

                dlg.dispose();
                loadStudents();

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dlg, "Failed to create student: " + ex.getMessage());
            }
        });

        dlg.add(new JScrollPane(form), BorderLayout.CENTER);
        dlg.add(btnPanel, BorderLayout.SOUTH);
        dlg.setVisible(true);
    }

    private String generateNextStudentId(String dept) {
        String prefix = "MSCS";
        if (dept != null) {
            String d = dept.toLowerCase();
            if (d.contains("info") || d.contains("it")) prefix = "MSIT";
            else if (d.contains("electronic") || d.contains("ece")) prefix = "MSECE";
            else if (d.contains("electrical") || d.contains("eee")) prefix = "MSEEE";
            else if (d.contains("mech")) prefix = "MSMECH";
            else if (d.contains("civil")) prefix = "MSCIV";
            else if (d.contains("bio")) prefix = "MSBIO";
        }

        int maxNum = 0;
        String sql = "SELECT student_id FROM student WHERE student_id LIKE ? ORDER BY student_id DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, prefix + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("student_id");
                    if (id != null && id.startsWith(prefix)) {
                        try {
                            int n = Integer.parseInt(id.substring(prefix.length()));
                            if (n > maxNum) maxNum = n;
                        } catch (Exception ignored) {}
                    }
                }
            }
        } catch (SQLException ignored) {}
        return prefix + String.format("%03d", maxNum + 1);
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : hash) {
                result.append(String.format("%02x", b));
            }
            return result.toString();
        } catch (Exception e) {
            return password;
        }
    }

    private void updateStudent() {
        if (selectedStudentId == null || selectedStudentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a student from the table first.");
            return;
        }

        String name = nameField.getText().trim();
        String dept = (String) departmentBox.getSelectedItem();
        String yrStr = yearField.getText().trim();
        String sem = semesterField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String reg = registerNumberField.getText().trim();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name, Email, and Phone are required.");
            return;
        }

        int year = 1;
        try {
            year = Integer.parseInt(yrStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Year must be a number between 1 and 4.");
            return;
        }

        String sql = "UPDATE student SET student_name = ?, department = ?, year = ?, semester = ?, "
                + "email = ?, phone = ?, register_number = ? WHERE student_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, dept);
            ps.setInt(3, year);
            ps.setString(4, sem);
            ps.setString(5, email);
            ps.setString(6, phone);
            ps.setString(7, reg);
            ps.setString(8, selectedStudentId);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                // Safely update alphabetical roll numbers if name or department changed
                try {
                    int admYr = RollNumberManager.resolveAdmissionYear(year, 0);
                    RollNumberManager.reassignRollNumbers(con, dept, admYr);
                } catch (Exception ignored) {}

                JOptionPane.showMessageDialog(this, "Student updated successfully!");
                loadStudents();
                clearForm();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Update failed: " + e.getMessage());
        }
    }

    private void deleteStudent() {
        if (selectedStudentId == null || selectedStudentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a student from the table to delete.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete Student: " + selectedStudentId + "?\nThis will also remove their user account and registrations.",
                "Confirm Student Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice != JOptionPane.YES_OPTION) return;

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                // Delete child references
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM marks WHERE student_id = ?")) {
                    ps.setString(1, selectedStudentId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM results WHERE student_id = ?")) {
                    ps.setString(1, selectedStudentId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM hall_seat_allocation WHERE student_id = ?")) {
                    ps.setString(1, selectedStudentId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM examregistration WHERE studentId = ?")) {
                    ps.setString(1, selectedStudentId);
                    ps.executeUpdate();
                }

                // Delete from users table if email matches
                String curEmail = emailField.getText().trim();
                if (!curEmail.isEmpty()) {
                    try (PreparedStatement ps = con.prepareStatement("DELETE FROM users WHERE email = ?")) {
                        ps.setString(1, curEmail);
                        ps.executeUpdate();
                    }
                }

                // Delete from student
                try (PreparedStatement ps = con.prepareStatement("DELETE FROM student WHERE student_id = ?")) {
                    ps.setString(1, selectedStudentId);
                    ps.executeUpdate();
                }

                con.commit();
                JOptionPane.showMessageDialog(this, "Student deleted successfully!");
                loadStudents();
                clearForm();

            } catch (SQLException ex) {
                con.rollback();
                JOptionPane.showMessageDialog(this, "Deletion failed: " + ex.getMessage());
            } finally {
                con.setAutoCommit(true);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }
    }

    private void clearForm() {
        selectedStudentId = null;
        idField.setText("");
        rollNumberField.setText("");
        nameField.setText("");
        if (departmentBox.getItemCount() > 0) departmentBox.setSelectedIndex(0);
        yearField.setText("");
        semesterField.setText("");
        emailField.setText("");
        phoneField.setText("");
        registerNumberField.setText("");
        studentTable.clearSelection();
    }
}
