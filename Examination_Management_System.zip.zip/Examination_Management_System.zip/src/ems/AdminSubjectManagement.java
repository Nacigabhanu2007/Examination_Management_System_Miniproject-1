package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.time.Year;

public class AdminSubjectManagement extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTextField idField, nameField;
    private JComboBox<String> departmentBox;
    private JComboBox<Integer> semesterBox;
    private JComboBox<Double> creditsBox;

    private JTable table;
    private DefaultTableModel model;

    private boolean loadingRecord = false;

    public AdminSubjectManagement() {
        setTitle("Examination Management System - Subject Management");
        setSize(1150, 740);
        setMinimumSize(new Dimension(950, 640));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "SUBJECT MANAGEMENT",
                "Maintain curriculum subjects, course codes, department mappings, and credit distributions"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Table
        String[] columns = {
            "Subject ID", "Subject Name", "Department ID", "Semester", "Credits"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        styleTable(table);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Form Card
        JPanel formCard = new JPanel(new BorderLayout(0, 12));
        formCard.setBackground(CARD_BG);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(15, 20, 15, 20)
        ));

        JLabel formTitle = new JLabel("Subject Details & Configuration");
        formTitle.setFont(FONT_HEADER);
        formTitle.setForeground(PRIMARY_BLUE);
        formCard.add(formTitle, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridLayout(1, 5, 12, 10));
        formGrid.setOpaque(false);

        idField = new JTextField();
        idField.setEditable(false);
        idField.setFont(FONT_INPUT);
        idField.setBackground(new Color(241, 245, 249));
        idField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        nameField = new JTextField();
        nameField.setFont(FONT_INPUT);
        nameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        departmentBox = new JComboBox<>();
        departmentBox.setFont(FONT_INPUT);

        semesterBox = new JComboBox<>();
        semesterBox.setFont(FONT_INPUT);
        for (int i = 1; i <= 8; i++) {
            semesterBox.addItem(i);
        }

        creditsBox = new JComboBox<>(new Double[]{1.0, 1.5, 2.0, 2.5, 3.0, 4.0});
        creditsBox.setFont(FONT_INPUT);

        addGridField(formGrid, "Subject ID (Auto)", idField);
        addGridField(formGrid, "Subject Name", nameField);
        addGridField(formGrid, "Department ID", departmentBox);
        addGridField(formGrid, "Semester", semesterBox);
        addGridField(formGrid, "Credits", creditsBox);

        formCard.add(formGrid, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        buttonPanel.setOpaque(false);

        JButton saveButton = createButton("Save Subject", SUCCESS_GREEN, SUCCESS_HOVER);
        JButton searchButton = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton updateButton = createButton("Update", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton deleteButton = createButton("Delete", DANGER_RED, DANGER_HOVER);
        JButton refreshButton = createButton("Refresh / Clear", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backButton = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        buttonPanel.add(backButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(searchButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(saveButton);

        formCard.add(buttonPanel, BorderLayout.SOUTH);
        contentPanel.add(formCard, BorderLayout.SOUTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel);

        // Events
        loadDepartments();
        loadSubjects();

        departmentBox.addActionListener(e -> {
            if (!loadingRecord) {
                generateSubjectId();
            }
        });

        semesterBox.addActionListener(e -> {
            if (!loadingRecord) {
                generateSubjectId();
            }
        });

        saveButton.addActionListener(e -> saveSubject());
        searchButton.addActionListener(e -> searchSubject());
        refreshButton.addActionListener(e -> {
            loadSubjects();
            clearFields();
        });
        updateButton.addActionListener(e -> updateSubject());
        deleteButton.addActionListener(e -> deleteSubject());
        backButton.addActionListener(e -> dispose());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                loadingRecord = true;

                idField.setText(model.getValueAt(row, 0).toString());
                nameField.setText(model.getValueAt(row, 1).toString());
                departmentBox.setSelectedItem(model.getValueAt(row, 2).toString());
                semesterBox.setSelectedItem(Integer.parseInt(model.getValueAt(row, 3).toString()));
                creditsBox.setSelectedItem(Double.parseDouble(model.getValueAt(row, 4).toString()));

                loadingRecord = false;
            }
        });

        generateSubjectId();
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void addGridField(JPanel panel, String label, JComponent field) {
        JPanel fGroup = new JPanel(new BorderLayout(0, 5));
        fGroup.setOpaque(false);

        JLabel lbl = new JLabel(label);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        fGroup.add(lbl, BorderLayout.NORTH);
        fGroup.add(field, BorderLayout.CENTER);
        panel.add(fGroup);
    }

    // LOAD DEPARTMENTS
    private void loadDepartments() {
        departmentBox.removeAllItems();

        String sql = "SELECT department_id FROM Department ORDER BY department_id";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                departmentBox.addItem(rs.getString("department_id"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Department loading error:\n" + e.getMessage());
        }
    }

    // AUTO-GENERATE SUBJECT ID
    private void generateSubjectId() {
        if (departmentBox.getSelectedItem() == null || semesterBox.getSelectedItem() == null) {
            idField.setText("");
            return;
        }

        String year = String.valueOf(Year.now().getValue()).substring(2);

        String department = departmentBox.getSelectedItem().toString().trim().toUpperCase();
        if (department.length() > 2) {
            department = department.substring(0, 2);
        }

        int semester = (Integer) semesterBox.getSelectedItem();
        String prefix = year + department + semester;

        int nextNumber = 1;
        String sql = "SELECT subject_id FROM Subject WHERE subject_id LIKE ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, prefix + "%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String existingId = rs.getString("subject_id");
                    if (existingId != null && existingId.matches(java.util.regex.Pattern.quote(prefix) + "\\d{2}")) {
                        int number = Integer.parseInt(existingId.substring(prefix.length()));
                        if (number >= nextNumber) {
                            nextNumber = number + 1;
                        }
                    }
                }
            }

            if (nextNumber > 99) {
                idField.setText("");
                JOptionPane.showMessageDialog(this, "Subject number limit reached.");
                return;
            }

            idField.setText(prefix + String.format("%02d", nextNumber));

        } catch (SQLException e) {
            idField.setText("");
            JOptionPane.showMessageDialog(this, "Subject ID generation error:\n" + e.getMessage());
        }
    }

    // SAVE SUBJECT
    private void saveSubject() {
        String name = nameField.getText().trim();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Subject Name.");
            return;
        }

        if (departmentBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Please add departments before saving subjects.");
            return;
        }

        String id = idField.getText().trim();
        if (id.isEmpty()) {
            generateSubjectId();
            id = idField.getText().trim();
        }

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Subject ID could not be generated.");
            return;
        }

        String department = departmentBox.getSelectedItem().toString();
        int semester = (Integer) semesterBox.getSelectedItem();
        double credits = (Double) creditsBox.getSelectedItem();

        String sql = "INSERT INTO Subject (subject_id, subject_name, department_id, semester, credits) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, department);
            ps.setInt(4, semester);
            ps.setDouble(5, credits);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Subject saved successfully!\nSubject ID: " + id);
            loadSubjects();
            clearFields();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Save failed:\n" + e.getMessage());
        }
    }

    // LOAD SUBJECTS
    private void loadSubjects() {
        model.setRowCount(0);

        String sql = "SELECT subject_id, subject_name, department_id, semester, credits FROM Subject ORDER BY subject_id";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("subject_id"),
                    rs.getString("subject_name"),
                    rs.getString("department_id"),
                    rs.getObject("semester"),
                    rs.getObject("credits")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Subject loading error:\n" + e.getMessage());
        }
    }

    // SEARCH SUBJECT
    private void searchSubject() {
        String id = JOptionPane.showInputDialog(this, "Enter Subject ID to Search:");

        if (id == null || id.trim().isEmpty()) {
            return;
        }

        id = id.trim();
        String sql = "SELECT * FROM Subject WHERE subject_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    idField.setText(rs.getString("subject_id"));
                    nameField.setText(rs.getString("subject_name"));
                    departmentBox.setSelectedItem(rs.getString("department_id"));
                    semesterBox.setSelectedItem(rs.getInt("semester"));
                    creditsBox.setSelectedItem(rs.getDouble("credits"));
                } else {
                    JOptionPane.showMessageDialog(this, "Subject ID not found: " + id);
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Search Error: " + e.getMessage());
        }
    }

    // UPDATE SUBJECT
    private void updateSubject() {
        String newId = idField.getText().trim();
        String name = nameField.getText().trim();

        Object deptObject = departmentBox.getSelectedItem();
        Object semObject = semesterBox.getSelectedItem();
        Object creditsObject = creditsBox.getSelectedItem();

        if (newId.isEmpty() || name.isEmpty() || deptObject == null || semObject == null || creditsObject == null) {
            JOptionPane.showMessageDialog(this, "Please fill all subject details.");
            return;
        }

        int semester = (Integer) semObject;
        double credits = (Double) creditsObject;
        String department = deptObject.toString();

        int selectedRow = table.getSelectedRow();
        String oldId;

        if (selectedRow != -1) {
            oldId = model.getValueAt(table.convertRowIndexToModel(selectedRow), 0).toString();
        } else {
            JOptionPane.showMessageDialog(this, "Please select the subject from the table first.");
            return;
        }

        String sql = "UPDATE Subject SET subject_id = ?, subject_name = ?, department_id = ?, semester = ?, credits = ? WHERE subject_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newId);
            ps.setString(2, name);
            ps.setString(3, department);
            ps.setInt(4, semester);
            ps.setDouble(5, credits);
            ps.setString(6, oldId);

            int result = ps.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this,
                        "Subject updated successfully!\nOld ID: " + oldId + "\nNew ID: " + newId);

                clearFields();
                loadSubjects();
                generateSubjectId();
            } else {
                JOptionPane.showMessageDialog(this, "Subject not found.");
            }

        } catch (SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(this, "This Subject ID already exists, or the Department ID is invalid.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Update failed: " + e.getMessage());
        }
    }

    private void deleteSubject() {
        String id = idField.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a subject from the table first.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete Subject " + id + "?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM Subject WHERE subject_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            int result = ps.executeUpdate();

            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Subject deleted successfully!");
                clearFields();
                loadSubjects();
                generateSubjectId();
            } else {
                JOptionPane.showMessageDialog(this, "Subject not found.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Delete failed:\n" + ex.getMessage()
                + "\nCheck whether this subject is referenced by an Exam.");
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        departmentBox.setSelectedIndex(-1);
        semesterBox.setSelectedIndex(-1);
        creditsBox.setSelectedIndex(-1);
        table.clearSelection();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminSubjectManagement::new);
    }
}
