package ems;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.util.*;

/**
 * EMSWebServer
 * Complete Production-Ready Web Application Server for Examination Management System (EMS).
 * Uses Java Standard Library com.sun.net.httpserver.HttpServer.
 * Integrates directly with MySQL database via ems.DBConnection.
 * 
 * Provides:
 * - Stunning Modern Login Page (UI matches exact specifications)
 * - Secure Authentication (SHA-256 verification against `users` table)
 * - Admin Portal with "View Registered Students", Search, Filtering, Live Metrics & Module Navigation
 * - Student Portal (Profile, Registered Subjects, Exam Schedule, Seating Allocation, Marks, Results)
 * - Faculty Portal (Invigilation Duties, Schedules, Directory)
 */
public class EMSWebServer {

    private static final int PORT = 8080;

    public static void main(String[] args) {
        startServer(PORT);
    }

    public static HttpServer startServer(int port) {
        try {
            ensureDefaultAdminUser();
            HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

            // Routes
            server.createContext("/", new LoginHandler());
            server.createContext("/login", new LoginHandler());
            server.createContext("/api/login", new ApiLoginHandler());
            server.createContext("/admin", new AdminDashboardHandler());
            server.createContext("/student", new StudentDashboardHandler());
            server.createContext("/faculty", new FacultyDashboardHandler());
            server.createContext("/api/registered", new ApiRegisteredStudentsHandler());
            server.createContext("/logout", new LogoutHandler());

            server.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
            server.start();
            System.out.println("========================================================");
            System.out.println("EMS Web Server started successfully on port: " + port);
            System.out.println("Access Portal locally at: http://localhost:" + port);
            System.out.println("========================================================");
            return server;
        } catch (IOException e) {
            System.err.println("Failed to start EMS Web Server: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    private static void ensureDefaultAdminUser() {
        String checkSql = "SELECT COUNT(*) FROM users WHERE role = 'Admin'";
        try (Connection con = DBConnection.getConnection()) {
            if (con == null) return;
            try (Statement st = con.createStatement(); ResultSet rs = st.executeQuery(checkSql)) {
                if (rs.next() && rs.getInt(1) == 0) {
                    String hash = hashPassword("Admin@123");
                    String insert = "INSERT INTO users (username, email, password_hash, role) VALUES ('admin', 'admin@ems.edu', ?, 'Admin')";
                    try (PreparedStatement ps = con.prepareStatement(insert)) {
                        ps.setString(1, hash);
                        ps.executeUpdate();
                        System.out.println("Seeded default admin user: admin / admin@ems.edu (Password: Admin@123)");
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Database check note: " + e.getMessage());
        }
    }

    public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : hash) {
                result.append(String.format("%02x", b));
            }
            return result.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // =========================================================================
    // 1. LOGIN PAGE HANDLER
    // =========================================================================
    static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                new ApiLoginHandler().handle(exchange);
                return;
            }

            String html = getLoginPageHtml("", "");
            sendHtml(exchange, html, 200);
        }
    }

    private static String getLoginPageHtml(String errorMsg, String prefillUser) {
        String alertHtml = "";
        if (errorMsg != null && !errorMsg.isEmpty()) {
            alertHtml = "<div class='alert-error'>" + escape(errorMsg) + "</div>";
        }

        return "<!DOCTYPE html>\n"
                + "<html lang='en'>\n"
                + "<head>\n"
                + "  <meta charset='UTF-8'>\n"
                + "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>\n"
                + "  <title>Examination Management System - Portal Login</title>\n"
                + "  <link rel='preconnect' href='https://fonts.googleapis.com'>\n"
                + "  <link href='https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap' rel='stylesheet'>\n"
                + "  <style>\n"
                + "    :root {\n"
                + "      --brand-navy: #0F1E41;\n"
                + "      --brand-blue: #1A4494;\n"
                + "      --accent-royal: #2563EB;\n"
                + "      --accent-hover: #1D4ED8;\n"
                + "      --accent-cyan: #38BDF8;\n"
                + "      --accent-gold: #F59E0B;\n"
                + "      --bg-canvas: #F8FAFC;\n"
                + "      --card-bg: #FFFFFF;\n"
                + "      --border-color: #E2E8F0;\n"
                + "      --text-dark: #0F172A;\n"
                + "      --text-muted: #64748B;\n"
                + "    }\n"
                + "    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif; }\n"
                + "    body {\n"
                + "      background: var(--bg-canvas);\n"
                + "      color: var(--text-dark);\n"
                + "      min-height: 100vh;\n"
                + "      display: flex;\n"
                + "      align-items: center;\n"
                + "      justify-content: center;\n"
                + "      padding: 24px;\n"
                + "    }\n"
                + "    .portal-container {\n"
                + "      display: grid;\n"
                + "      grid-template-columns: 1fr 1fr;\n"
                + "      max-width: 1040px;\n"
                + "      width: 100%;\n"
                + "      min-height: 620px;\n"
                + "      background: #FFFFFF;\n"
                + "      border-radius: 24px;\n"
                + "      overflow: hidden;\n"
                + "      box-shadow: 0 20px 40px -15px rgba(15, 30, 65, 0.15), 0 0 1px 1px rgba(15, 30, 65, 0.05);\n"
                + "    }\n"
                + "    /* Left Showcase Hero */\n"
                + "    .hero-panel {\n"
                + "      background: linear-gradient(145deg, var(--brand-navy) 0%, var(--brand-blue) 100%);\n"
                + "      color: #FFFFFF;\n"
                + "      padding: 48px 42px;\n"
                + "      display: flex;\n"
                + "      flex-direction: column;\n"
                + "      justify-content: space-between;\n"
                + "      position: relative;\n"
                + "      overflow: hidden;\n"
                + "    }\n"
                + "    .hero-panel::before {\n"
                + "      content: '';\n"
                + "      position: absolute;\n"
                + "      top: -80px; right: -80px;\n"
                + "      width: 300px; height: 300px;\n"
                + "      background: radial-gradient(circle, rgba(56, 189, 248, 0.15) 0%, transparent 70%);\n"
                + "      border-radius: 50%;\n"
                + "    }\n"
                + "    .badge {\n"
                + "      display: inline-flex;\n"
                + "      align-items: center;\n"
                + "      gap: 6px;\n"
                + "      padding: 6px 14px;\n"
                + "      background: rgba(37, 99, 235, 0.35);\n"
                + "      border: 1px solid rgba(56, 189, 248, 0.3);\n"
                + "      border-radius: 9999px;\n"
                + "      font-size: 11px;\n"
                + "      font-weight: 700;\n"
                + "      color: var(--accent-cyan);\n"
                + "      letter-spacing: 0.5px;\n"
                + "      text-transform: uppercase;\n"
                + "      margin-bottom: 20px;\n"
                + "    }\n"
                + "    .hero-title {\n"
                + "      font-size: 28px;\n"
                + "      font-weight: 800;\n"
                + "      line-height: 1.25;\n"
                + "      margin-bottom: 12px;\n"
                + "      letter-spacing: -0.5px;\n"
                + "    }\n"
                + "    .hero-sub {\n"
                + "      font-size: 14px;\n"
                + "      color: #CBD5E1;\n"
                + "      line-height: 1.6;\n"
                + "      max-width: 400px;\n"
                + "    }\n"
                + "    /* Vector Artwork Graphic */\n"
                + "    .illustration-wrap {\n"
                + "      display: flex;\n"
                + "      align-items: center;\n"
                + "      justify-content: center;\n"
                + "      margin: 28px 0;\n"
                + "    }\n"
                + "    .illustration-svg {\n"
                + "      width: 220px;\n"
                + "      height: 150px;\n"
                + "      filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.25));\n"
                + "    }\n"
                + "    .feature-list {\n"
                + "      list-style: none;\n"
                + "      display: flex;\n"
                + "      flex-direction: column;\n"
                + "      gap: 10px;\n"
                + "      margin-bottom: 24px;\n"
                + "    }\n"
                + "    .feature-item {\n"
                + "      display: flex;\n"
                + "      align-items: center;\n"
                + "      gap: 10px;\n"
                + "      font-size: 13px;\n"
                + "      color: #E2E8F0;\n"
                + "    }\n"
                + "    .feature-icon {\n"
                + "      color: var(--accent-cyan);\n"
                + "      font-weight: 800;\n"
                + "      font-size: 14px;\n"
                + "    }\n"
                + "    .hero-footer {\n"
                + "      font-size: 11px;\n"
                + "      color: #94A3B8;\n"
                + "      border-top: 1px solid rgba(255, 255, 255, 0.1);\n"
                + "      padding-top: 14px;\n"
                + "    }\n"
                + "    /* Right Login Form */\n"
                + "    .login-panel {\n"
                + "      background: #FFFFFF;\n"
                + "      padding: 48px 44px;\n"
                + "      display: flex;\n"
                + "      flex-direction: column;\n"
                + "      justify-content: center;\n"
                + "    }\n"
                + "    .login-header h2 {\n"
                + "      font-size: 24px;\n"
                + "      font-weight: 800;\n"
                + "      color: var(--text-dark);\n"
                + "      margin-bottom: 6px;\n"
                + "    }\n"
                + "    .login-header p {\n"
                + "      font-size: 13px;\n"
                + "      color: var(--text-muted);\n"
                + "      margin-bottom: 24px;\n"
                + "    }\n"
                + "    .form-group {\n"
                + "      margin-bottom: 18px;\n"
                + "    }\n"
                + "    .form-label {\n"
                + "      display: block;\n"
                + "      font-size: 12px;\n"
                + "      font-weight: 700;\n"
                + "      color: var(--text-dark);\n"
                + "      margin-bottom: 6px;\n"
                + "      text-transform: uppercase;\n"
                + "      letter-spacing: 0.3px;\n"
                + "    }\n"
                + "    .form-input, .form-select {\n"
                + "      width: 100%;\n"
                + "      padding: 11px 14px;\n"
                + "      font-size: 14px;\n"
                + "      border: 1.5px solid var(--border-color);\n"
                + "      border-radius: 10px;\n"
                + "      outline: none;\n"
                + "      transition: all 0.2s ease;\n"
                + "      background: #FFFFFF;\n"
                + "      color: var(--text-dark);\n"
                + "    }\n"
                + "    .form-input:focus, .form-select:focus {\n"
                + "      border-color: var(--accent-royal);\n"
                + "      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);\n"
                + "    }\n"
                + "    .password-row {\n"
                + "      display: flex;\n"
                + "      justify-content: space-between;\n"
                + "      align-items: center;\n"
                + "      margin-top: 6px;\n"
                + "      font-size: 12px;\n"
                + "      color: var(--text-muted);\n"
                + "    }\n"
                + "    .toggle-pass {\n"
                + "      display: flex;\n"
                + "      align-items: center;\n"
                + "      gap: 6px;\n"
                + "      cursor: pointer;\n"
                + "    }\n"
                + "    .btn-primary {\n"
                + "      width: 100%;\n"
                + "      padding: 13px;\n"
                + "      background: var(--accent-royal);\n"
                + "      color: #FFFFFF;\n"
                + "      border: none;\n"
                + "      border-radius: 10px;\n"
                + "      font-size: 14px;\n"
                + "      font-weight: 700;\n"
                + "      cursor: pointer;\n"
                + "      transition: all 0.2s ease;\n"
                + "      box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);\n"
                + "      margin-top: 8px;\n"
                + "    }\n"
                + "    .btn-primary:hover {\n"
                + "      background: var(--accent-hover);\n"
                + "      box-shadow: 0 6px 16px rgba(37, 99, 235, 0.35);\n"
                + "      transform: translateY(-1px);\n"
                + "    }\n"
                + "    .links-bar {\n"
                + "      display: flex;\n"
                + "      justify-content: center;\n"
                + "      align-items: center;\n"
                + "      gap: 12px;\n"
                + "      margin-top: 20px;\n"
                + "      font-size: 12px;\n"
                + "    }\n"
                + "    .links-bar a {\n"
                + "      color: var(--accent-royal);\n"
                + "      text-decoration: none;\n"
                + "      font-weight: 600;\n"
                + "    }\n"
                + "    .links-bar a:hover { text-decoration: underline; }\n"
                + "    .links-bar span { color: var(--border-color); }\n"
                + "    .alert-error {\n"
                + "      padding: 10px 14px;\n"
                + "      background: #FEF2F2;\n"
                + "      border: 1px solid #FCA5A5;\n"
                + "      color: #991B1B;\n"
                + "      border-radius: 8px;\n"
                + "      font-size: 13px;\n"
                + "      font-weight: 600;\n"
                + "      margin-bottom: 16px;\n"
                + "    }\n"
                + "    .demo-credentials {\n"
                + "      margin-top: 18px;\n"
                + "      padding: 12px 14px;\n"
                + "      background: #F1F5F9;\n"
                + "      border-radius: 8px;\n"
                + "      font-size: 11px;\n"
                + "      color: #475569;\n"
                + "      border: 1px solid #E2E8F0;\n"
                + "    }\n"
                + "    .demo-credentials strong { color: var(--brand-navy); }\n"
                + "    @media (max-width: 820px) {\n"
                + "      .portal-container { grid-template-columns: 1fr; max-width: 480px; }\n"
                + "      .hero-panel { display: none; }\n"
                + "    }\n"
                + "  </style>\n"
                + "</head>\n"
                + "<body>\n"
                + "  <div class='portal-container'>\n"
                + "    <!-- LEFT HERO SHOWCASE -->\n"
                + "    <div class='hero-panel'>\n"
                + "      <div>\n"
                + "        <div class='badge'>★ Official Academic Examination Portal</div>\n"
                + "        <h1 class='hero-title'>EXAMINATION<br>MANAGEMENT SYSTEM</h1>\n"
                + "        <p class='hero-sub'>Next-generation academic portal for verified candidate scheduling, seating allocations, hall invigilation, and examination grade publishing.</p>\n"
                + "      </div>\n"
                + "\n"
                + "      <!-- Modern Vector Educational Artwork -->\n"
                + "      <div class='illustration-wrap'>\n"
                + "        <svg class='illustration-svg' viewBox='0 0 240 160' fill='none' xmlns='http://www.w3.org/2000/svg'>\n"
                + "          <ellipse cx='120' cy='95' rx='90' ry='45' fill='white' fill-opacity='0.08'/>\n"
                + "          <!-- Open Book -->\n"
                + "          <path d='M35 110 C65 95 95 105 120 115 L120 145 C95 135 65 125 35 140 Z' fill='#F8FAFC' stroke='#CBD5E1' stroke-width='2'/>\n"
                + "          <path d='M120 115 C145 105 175 95 205 110 L205 140 C175 125 145 135 120 145 Z' fill='#E2E8F0' stroke='#94A3B8' stroke-width='2'/>\n"
                + "          <line x1='120' y1='115' x2='120' y2='145' stroke='#64748B' stroke-width='2'/>\n"
                + "          <!-- Book text lines -->\n"
                + "          <line x1='48' y1='118' x2='108' y2='122' stroke='#94A3B8' stroke-width='2' stroke-linecap='round'/>\n"
                + "          <line x1='48' y1='126' x2='102' y2='130' stroke='#94A3B8' stroke-width='2' stroke-linecap='round'/>\n"
                + "          <line x1='132' y1='122' x2='192' y2='118' stroke='#94A3B8' stroke-width='2' stroke-linecap='round'/>\n"
                + "          <line x1='132' y1='130' x2='186' y2='126' stroke='#94A3B8' stroke-width='2' stroke-linecap='round'/>\n"
                + "          <!-- Golden Bookmark Ribbon -->\n"
                + "          <path d='M118 115 L122 115 L124 154 L120 150 L116 154 Z' fill='#F59E0B'/>\n"
                + "          <!-- Graduation Mortarboard (Cap) -->\n"
                + "          <ellipse cx='120' cy='65' rx='34' ry='16' fill='#0F172A'/>\n"
                + "          <polygon points='120,38 185,58 120,78 55,58' fill='#1E293B' stroke='#94A3B8' stroke-width='2'/>\n"
                + "          <circle cx='120' cy='58' r='4' fill='#F59E0B'/>\n"
                + "          <path d='M120 58 Q155 62 165 85' stroke='#FBBF24' stroke-width='2.5' fill='none' stroke-linecap='round'/>\n"
                + "          <circle cx='165' cy='87' r='4' fill='#F59E0B'/>\n"
                + "          <!-- Verified Badge -->\n"
                + "          <circle cx='185' cy='125' r='14' fill='#22C55E'/>\n"
                + "          <path d='M179 125 L183 129 L191 121' stroke='white' stroke-width='2.5' stroke-linecap='round' stroke-linejoin='round'/>\n"
                + "        </svg>\n"
                + "      </div>\n"
                + "\n"
                + "      <div>\n"
                + "        <ul class='feature-list'>\n"
                + "          <li class='feature-item'><span class='feature-icon'>✓</span> Verified Candidate Registrations & Hall Allocations</li>\n"
                + "          <li class='feature-item'><span class='feature-icon'>✓</span> Automated Roll Numbers & Invigilator Rosters</li>\n"
                + "          <li class='feature-item'><span class='feature-icon'>✓</span> Role-Based Architecture for Students, Faculty & Admins</li>\n"
                + "        </ul>\n"
                + "        <div class='hero-footer'>Controller of Examinations • Session 2026-2027 • Production Ready</div>\n"
                + "      </div>\n"
                + "    </div>\n"
                + "\n"
                + "    <!-- RIGHT LOGIN FORM -->\n"
                + "    <div class='login-panel'>\n"
                + "      <div class='login-header'>\n"
                + "        <h2>Portal Sign In</h2>\n"
                + "        <p>Please enter your authorized credentials to continue.</p>\n"
                + "      </div>\n"
                + alertHtml
                + "      <form method='POST' action='/login'>\n"
                + "        <div class='form-group'>\n"
                + "          <label class='form-label' for='username'>User ID or Registered Email</label>\n"
                + "          <input type='text' id='username' name='username' class='form-input' placeholder='e.g. admin or student@ems.edu' value='" + escape(prefillUser) + "' required autofocus>\n"
                + "        </div>\n"
                + "        <div class='form-group'>\n"
                + "          <label class='form-label' for='password'>Password</label>\n"
                + "          <input type='password' id='password' name='password' class='form-input' placeholder='Enter your password' required>\n"
                + "          <div class='password-row'>\n"
                + "            <label class='toggle-pass'>\n"
                + "              <input type='checkbox' id='showPass' onchange='togglePassword()'> Show Password\n"
                + "            </label>\n"
                + "          </div>\n"
                + "        </div>\n"
                + "        <div class='form-group'>\n"
                + "          <label class='form-label' for='role'>Portal Role</label>\n"
                + "          <select id='role' name='role' class='form-select'>\n"
                + "            <option value='Admin' selected>Admin (System & Examination Controller)</option>\n"
                + "            <option value='Student'>Student (Candidate Portal)</option>\n"
                + "            <option value='Faculty'>Faculty (Academic & Invigilator)</option>\n"
                + "          </select>\n"
                + "        </div>\n"
                + "        <button type='submit' class='btn-primary'>Sign In to Portal &rarr;</button>\n"
                + "      </form>\n"
                + "      <div class='links-bar'>\n"
                + "        <a href='javascript:alert(\"To register new candidates, sign in as Administrator or use desktop EMS portal.\")'>Create Account</a>\n"
                + "        <span>•</span>\n"
                + "        <a href='javascript:alert(\"Please contact examination cell administrator for password recovery assistance.\")'>Forgot Password?</a>\n"
                + "      </div>\n"
                + "      <div class='demo-credentials'>\n"
                + "        <strong>Default Administrator Login:</strong><br>\n"
                + "        Username: <code>admin</code> &bull; Password: <code>Admin@123</code> &bull; Role: <code>Admin</code>\n"
                + "      </div>\n"
                + "    </div>\n"
                + "  </div>\n"
                + "  <script>\n"
                + "    function togglePassword() {\n"
                + "      const p = document.getElementById('password');\n"
                + "      p.type = document.getElementById('showPass').checked ? 'text' : 'password';\n"
                + "    }\n"
                + "  </script>\n"
                + "</body>\n"
                + "</html>";
    }

    // =========================================================================
    // 2. AUTHENTICATION API HANDLER
    // =========================================================================
    static class ApiLoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            Map<String, String> params = parseFormData(exchange.getRequestBody());
            String username = params.getOrDefault("username", "").trim();
            String password = params.getOrDefault("password", "");
            String role = params.getOrDefault("role", "Admin").trim();

            if (username.isEmpty() || password.isEmpty()) {
                String html = getLoginPageHtml("Please provide both User ID/Email and password.", username);
                sendHtml(exchange, html, 200);
                return;
            }

            String sql = "SELECT user_id, username, email, password_hash, role FROM users WHERE email = ? OR username = ?";

            try (Connection con = DBConnection.getConnection()) {
                if (con == null) {
                    sendHtml(exchange, getLoginPageHtml("Database service unreachable. Please ensure MySQL is running.", username), 200);
                    return;
                }

                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setString(1, username);
                    ps.setString(2, username);

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            sendHtml(exchange, getLoginPageHtml("No account found matching '" + username + "'. Please check your credentials.", username), 200);
                            return;
                        }

                        String storedHash = rs.getString("password_hash");
                        String dbRole = rs.getString("role");
                        String email = rs.getString("email");

                        if (!storedHash.equals(hashPassword(password))) {
                            sendHtml(exchange, getLoginPageHtml("Incorrect password. Please verify and try again.", username), 200);
                            return;
                        }

                        if (!dbRole.equalsIgnoreCase(role)) {
                            sendHtml(exchange, getLoginPageHtml("Selected role ('" + role + "') does not match your registered role ('" + dbRole + "').", username), 200);
                            return;
                        }

                        // Success -> Redirect based on role
                        String target;
                        if (dbRole.equalsIgnoreCase("Admin")) {
                            target = "/admin";
                        } else if (dbRole.equalsIgnoreCase("Student")) {
                            target = "/student?email=" + java.net.URLEncoder.encode(email, StandardCharsets.UTF_8);
                        } else {
                            target = "/faculty?email=" + java.net.URLEncoder.encode(email, StandardCharsets.UTF_8);
                        }

                        exchange.getResponseHeaders().set("Location", target);
                        exchange.sendResponseHeaders(302, -1);
                    }
                }
            } catch (Exception e) {
                sendHtml(exchange, getLoginPageHtml("System error: " + e.getMessage(), username), 200);
            }
        }
    }

    // =========================================================================
    // 3. ADMIN DASHBOARD & VIEW REGISTERED STUDENTS HANDLER
    // =========================================================================
    static class AdminDashboardHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Retrieve filter params
            String query = exchange.getRequestURI().getQuery();
            Map<String, String> qmap = parseQuery(query);
            String search = qmap.getOrDefault("q", "").trim();
            String examFilter = qmap.getOrDefault("exam", "").trim();

            int totalStudents = countQuery("SELECT COUNT(*) FROM student");
            int totalFaculty = countQuery("SELECT COUNT(*) FROM faculty");
            int totalExams = countQuery("SELECT COUNT(*) FROM exam");
            int totalRegistrations = countQuery("SELECT COUNT(*) FROM examregistration WHERE status = 'Registered'");
            int totalResults = countQuery("SELECT COUNT(*) FROM results");
            int totalCapacity = countQuery("SELECT COALESCE(SUM(capacity), 0) FROM hall");

            // Retrieve registered students list
            StringBuilder regSql = new StringBuilder(
                    "SELECT r.registrationId, r.studentId, COALESCE(s.roll_number, 'N/A') AS roll_number, "
                    + "r.studentName, r.examId, r.examName, "
                    + "CONCAT(r.subjectId, ' - ', COALESCE(sub.subject_name, '')) AS subject_display, "
                    + "r.status, r.registrationDate "
                    + "FROM examregistration r "
                    + "LEFT JOIN student s ON r.studentId = s.student_id "
                    + "LEFT JOIN subject sub ON r.subjectId = sub.subject_id WHERE 1=1 "
            );

            if (!examFilter.isEmpty() && !examFilter.equalsIgnoreCase("All")) {
                regSql.append(" AND r.examId = ? ");
            }
            if (!search.isEmpty()) {
                regSql.append(" AND (r.studentId LIKE ? OR s.roll_number LIKE ? OR r.examId LIKE ? OR r.studentName LIKE ?) ");
            }
            regSql.append(" ORDER BY r.registrationId DESC");

            List<String[]> regRows = new ArrayList<>();
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(regSql.toString())) {
                int pidx = 1;
                if (!examFilter.isEmpty() && !examFilter.equalsIgnoreCase("All")) {
                    ps.setString(pidx++, examFilter);
                }
                if (!search.isEmpty()) {
                    String pat = "%" + search + "%";
                    ps.setString(pidx++, pat);
                    ps.setString(pidx++, pat);
                    ps.setString(pidx++, pat);
                    ps.setString(pidx++, pat);
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        regRows.add(new String[]{
                                rs.getString("studentId"),
                                rs.getString("roll_number"),
                                rs.getString("studentName"),
                                rs.getString("examId"),
                                rs.getString("examName"),
                                rs.getString("subject_display"),
                                rs.getString("status"),
                                String.valueOf(rs.getDate("registrationDate"))
                        });
                    }
                }
            } catch (SQLException ignored) {}

            // Build Registered Students Table Rows
            StringBuilder tableRows = new StringBuilder();
            if (regRows.isEmpty()) {
                tableRows.append("<tr><td colspan='8' style='text-align:center; padding:32px; color:#64748B;'>")
                         .append("<strong>No examination registrations found.</strong><br>Candidates registered through the student portal will appear here in real time.")
                         .append("</td></tr>");
            } else {
                for (String[] r : regRows) {
                    tableRows.append("<tr>")
                             .append("<td><code>").append(escape(r[0])).append("</code></td>")
                             .append("<td><strong>").append(escape(r[1])).append("</strong></td>")
                             .append("<td>").append(escape(r[2])).append("</td>")
                             .append("<td><span class='badge-exam'>").append(escape(r[3])).append("</span></td>")
                             .append("<td>").append(escape(r[4])).append("</td>")
                             .append("<td>").append(escape(r[5])).append("</td>")
                             .append("<td><span class='badge-status'>").append(escape(r[6])).append("</span></td>")
                             .append("<td>").append(escape(r[7])).append("</td>")
                             .append("</tr>");
                }
            }

            // Exams dropdown options
            StringBuilder examOpts = new StringBuilder("<option value='All'>All Exams</option>");
            try (Connection con = DBConnection.getConnection();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery("SELECT exam_id, exam_name FROM exam ORDER BY exam_id")) {
                while (rs.next()) {
                    String eid = rs.getString("exam_id");
                    String ename = rs.getString("exam_name");
                    String sel = eid.equals(examFilter) ? " selected" : "";
                    examOpts.append("<option value='").append(eid).append("'").append(sel).append(">").append(eid).append(" - ").append(escape(ename)).append("</option>");
                }
            } catch (SQLException ignored) {}

            String html = "<!DOCTYPE html>\n"
                    + "<html>\n"
                    + "<head>\n"
                    + "  <meta charset='UTF-8'>\n"
                    + "  <title>EMS - Administrator Dashboard</title>\n"
                    + "  <link href='https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap' rel='stylesheet'>\n"
                    + "  <style>\n"
                    + "    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Plus Jakarta Sans', sans-serif; }\n"
                    + "    body { background: #F8FAFC; color: #0F172A; display: flex; min-height: 100vh; }\n"
                    + "    /* Sidebar */\n"
                    + "    .sidebar { width: 260px; background: #0F1E41; color: white; padding: 24px 18px; display: flex; flex-direction: column; flex-shrink: 0; }\n"
                    + "    .brand-title { font-size: 20px; font-weight: 800; color: white; display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }\n"
                    + "    .brand-sub { font-size: 11px; color: #94A3B8; margin-bottom: 24px; }\n"
                    + "    .nav-link { display: flex; align-items: center; gap: 10px; padding: 10px 14px; color: #E2E8F0; text-decoration: none; border-radius: 8px; font-size: 13px; font-weight: 600; margin-bottom: 4px; transition: all 0.2s; }\n"
                    + "    .nav-link:hover, .nav-link.active { background: #1A4494; color: white; }\n"
                    + "    .logout-btn { margin-top: auto; padding: 10px 14px; background: #DC2626; color: white; text-align: center; border-radius: 8px; text-decoration: none; font-weight: 700; font-size: 13px; }\n"
                    + "    /* Main Content */\n"
                    + "    .main-content { flex: 1; padding: 32px; overflow-y: auto; }\n"
                    + "    .top-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }\n"
                    + "    .page-title { font-size: 24px; font-weight: 800; }\n"
                    + "    /* Metrics Grid */\n"
                    + "    .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; margin-bottom: 28px; }\n"
                    + "    .metric-card { background: white; padding: 18px 20px; border-radius: 14px; border: 1px solid #E2E8F0; box-shadow: 0 2px 4px rgba(0,0,0,0.02); border-left: 4px solid #2563EB; }\n"
                    + "    .metric-value { font-size: 26px; font-weight: 800; color: #0F172A; margin-top: 4px; }\n"
                    + "    .metric-label { font-size: 12px; color: #64748B; font-weight: 600; text-transform: uppercase; }\n"
                    + "    /* Section Card */\n"
                    + "    .section-card { background: white; border-radius: 16px; border: 1px solid #E2E8F0; padding: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.03); }\n"
                    + "    .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 14px; }\n"
                    + "    .section-title { font-size: 18px; font-weight: 800; display: flex; align-items: center; gap: 8px; }\n"
                    + "    /* Search and Filter Form */\n"
                    + "    .filter-form { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }\n"
                    + "    .filter-input, .filter-select { padding: 8px 12px; border: 1.5px solid #E2E8F0; border-radius: 8px; font-size: 13px; outline: none; }\n"
                    + "    .btn-search { padding: 8px 16px; background: #2563EB; color: white; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; }\n"
                    + "    .btn-reset { padding: 8px 14px; background: #64748B; color: white; text-decoration: none; border-radius: 8px; font-size: 13px; font-weight: 600; }\n"
                    + "    /* Table */\n"
                    + "    .data-table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 13px; }\n"
                    + "    .data-table th { background: #F1F5F9; color: #475569; font-weight: 700; text-align: left; padding: 12px 14px; border-bottom: 1.5px solid #CBD5E1; }\n"
                    + "    .data-table td { padding: 12px 14px; border-bottom: 1px solid #E2E8F0; vertical-align: middle; }\n"
                    + "    .data-table tr:hover { background: #F8FAFC; }\n"
                    + "    .badge-status { background: #DCFCE7; color: #166534; padding: 4px 10px; border-radius: 9999px; font-weight: 700; font-size: 11px; display: inline-block; }\n"
                    + "    .badge-exam { background: #EFF6FF; color: #1E40AF; padding: 3px 8px; border-radius: 6px; font-weight: 700; font-size: 11px; }\n"
                    + "  </style>\n"
                    + "</head>\n"
                    + "<body>\n"
                    + "  <!-- SIDEBAR -->\n"
                    + "  <div class='sidebar'>\n"
                    + "    <div class='brand-title'>EMS PORTAL</div>\n"
                    + "    <div class='brand-sub'>Centralized Administrator Console</div>\n"
                    + "    <a href='/admin' class='nav-link active'>📊 Dashboard Overview</a>\n"
                    + "    <a href='#registered' class='nav-link'>📋 View Registered Students</a>\n"
                    + "    <a href='javascript:alert(\"Student Management is active. Use desktop app or web database console.\")' class='nav-link'>👨‍🎓 Student Management</a>\n"
                    + "    <a href='javascript:alert(\"Faculty Management is active.\")' class='nav-link'>👨‍🏫 Faculty Management</a>\n"
                    + "    <a href='javascript:alert(\"Exam Management is active.\")' class='nav-link'>📝 Exam Schedules</a>\n"
                    + "    <a href='javascript:alert(\"Hall & Seat Allocation is active.\")' class='nav-link'>🏢 Hall & Seat Allocation</a>\n"
                    + "    <a href='javascript:alert(\"Staff Allocation is active.\")' class='nav-link'>👥 Staff Allocation</a>\n"
                    + "    <a href='javascript:alert(\"Marks & Results are active.\")' class='nav-link'>📈 Marks & Results</a>\n"
                    + "    <a href='/logout' class='logout-btn'>Sign Out</a>\n"
                    + "  </div>\n"
                    + "\n"
                    + "  <!-- MAIN -->\n"
                    + "  <div class='main-content'>\n"
                    + "    <div class='top-header'>\n"
                    + "      <div>\n"
                    + "        <h1 class='page-title'>Administrator Dashboard</h1>\n"
                    + "        <p style='color:#64748B; font-size:13px; margin-top:4px;'>Academic Session 2026-2027 &bull; Real-time MySQL System Sync</p>\n"
                    + "      </div>\n"
                    + "    </div>\n"
                    + "\n"
                    + "    <!-- METRICS -->\n"
                    + "    <div class='metrics-grid'>\n"
                    + "      <div class='metric-card' style='border-left-color: #2563EB;'>\n"
                    + "        <div class='metric-label'>Total Students</div>\n"
                    + "        <div class='metric-value'>" + totalStudents + "</div>\n"
                    + "      </div>\n"
                    + "      <div class='metric-card' style='border-left-color: #7C3AED;'>\n"
                    + "        <div class='metric-label'>Teaching Faculty</div>\n"
                    + "        <div class='metric-value'>" + totalFaculty + "</div>\n"
                    + "      </div>\n"
                    + "      <div class='metric-card' style='border-left-color: #E11D48;'>\n"
                    + "        <div class='metric-label'>Scheduled Exams</div>\n"
                    + "        <div class='metric-value'>" + totalExams + "</div>\n"
                    + "      </div>\n"
                    + "      <div class='metric-card' style='border-left-color: #16A34A;'>\n"
                    + "        <div class='metric-label'>Verified Registrations</div>\n"
                    + "        <div class='metric-value'>" + totalRegistrations + "</div>\n"
                    + "      </div>\n"
                    + "      <div class='metric-card' style='border-left-color: #EA580C;'>\n"
                    + "        <div class='metric-label'>Published Results</div>\n"
                    + "        <div class='metric-value'>" + totalResults + "</div>\n"
                    + "      </div>\n"
                    + "      <div class='metric-card' style='border-left-color: #0891B2;'>\n"
                    + "        <div class='metric-label'>Total Hall Capacity</div>\n"
                    + "        <div class='metric-value'>" + totalCapacity + "</div>\n"
                    + "      </div>\n"
                    + "    </div>\n"
                    + "\n"
                    + "    <!-- VIEW REGISTERED STUDENTS SECTION -->\n"
                    + "    <div class='section-card' id='registered'>\n"
                    + "      <div class='section-header'>\n"
                    + "        <div class='section-title'>\n"
                    + "          <span>📋 Student Examination Registrations</span>\n"
                    + "          <span style='font-size:12px; font-weight:600; color:#16A34A; background:#DCFCE7; padding:2px 8px; border-radius:9999px;'>" + regRows.size() + " Found</span>\n"
                    + "        </div>\n"
                    + "        <form class='filter-form' method='GET' action='/admin'>\n"
                    + "          <input type='text' name='q' class='filter-input' placeholder='Search Student ID, Roll No, Name...' value='" + escape(search) + "'>\n"
                    + "          <select name='exam' class='filter-select'>" + examOpts + "</select>\n"
                    + "          <button type='submit' class='btn-search'>Filter / Search</button>\n"
                    + "          <a href='/admin' class='btn-reset'>Reset</a>\n"
                    + "        </form>\n"
                    + "      </div>\n"
                    + "      <div style='overflow-x:auto;'>\n"
                    + "        <table class='data-table'>\n"
                    + "          <thead>\n"
                    + "            <tr>\n"
                    + "              <th>Student ID</th>\n"
                    + "              <th>Roll Number</th>\n"
                    + "              <th>Candidate Name</th>\n"
                    + "              <th>Exam ID</th>\n"
                    + "              <th>Exam Name</th>\n"
                    + "              <th>Subject</th>\n"
                    + "              <th>Status</th>\n"
                    + "              <th>Registered Date</th>\n"
                    + "            </tr>\n"
                    + "          </thead>\n"
                    + "          <tbody>" + tableRows + "</tbody>\n"
                    + "        </table>\n"
                    + "      </div>\n"
                    + "    </div>\n"
                    + "  </div>\n"
                    + "</body>\n"
                    + "</html>";

            sendHtml(exchange, html, 200);
        }
    }

    // =========================================================================
    // 4. STUDENT DASHBOARD HANDLER
    // =========================================================================
    static class StudentDashboardHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String query = exchange.getRequestURI().getQuery();
            Map<String, String> qmap = parseQuery(query);
            String email = qmap.getOrDefault("email", "");

            String studentName = "Student Candidate";
            String studentId = "";
            String rollNumber = "";
            String dept = "";

            if (!email.isEmpty()) {
                String ssql = "SELECT student_id, student_name, roll_number, department FROM student WHERE email = ?";
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(ssql)) {
                    ps.setString(1, email);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            studentId = rs.getString("student_id");
                            studentName = rs.getString("student_name");
                            rollNumber = rs.getString("roll_number");
                            dept = rs.getString("department");
                        }
                    }
                } catch (SQLException ignored) {}
            }

            // Registered Exams
            StringBuilder examRows = new StringBuilder();
            if (!studentId.isEmpty()) {
                String rsql = "SELECT r.examId, r.examName, r.subjectId, r.registrationDate, r.status, "
                            + "hsa.hall_number, hsa.seat_number "
                            + "FROM examregistration r "
                            + "LEFT JOIN hall_seat_allocation hsa ON r.examId = hsa.exam_id AND r.studentId = hsa.student_id "
                            + "WHERE r.studentId = ? ORDER BY r.registrationDate DESC";
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(rsql)) {
                    ps.setString(1, studentId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            String hall = rs.getString("hall_number");
                            String seat = rs.getString("seat_number");
                            String seating = (hall != null && !hall.isEmpty()) ? (hall + " / Seat " + seat) : "Pending Allocation";
                            examRows.append("<tr>")
                                    .append("<td><code>").append(escape(rs.getString("examId"))).append("</code></td>")
                                    .append("<td>").append(escape(rs.getString("examName"))).append("</td>")
                                    .append("<td>").append(escape(rs.getString("subjectId"))).append("</td>")
                                    .append("<td>").append(escape(seating)).append("</td>")
                                    .append("<td><span style='background:#DCFCE7;color:#166534;padding:3px 8px;border-radius:9999px;font-size:11px;font-weight:700;'>")
                                    .append(escape(rs.getString("status"))).append("</span></td>")
                                    .append("</tr>");
                        }
                    }
                } catch (SQLException ignored) {}
            }

            if (examRows.length() == 0) {
                examRows.append("<tr><td colspan='5' style='text-align:center;padding:24px;color:#64748B;'>No examination registrations found.</td></tr>");
            }

            String html = "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>EMS - Student Portal</title>"
                    + "<link href='https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap' rel='stylesheet'>"
                    + "<style>"
                    + "* { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Plus Jakarta Sans', sans-serif; }"
                    + "body { background: #F8FAFC; color: #0F172A; padding: 32px; }"
                    + ".header { background: #0F1E41; color: white; padding: 24px; border-radius: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }"
                    + ".card { background: white; border: 1px solid #E2E8F0; border-radius: 16px; padding: 24px; margin-bottom: 24px; }"
                    + "table { width: 100%; border-collapse: collapse; margin-top: 12px; }"
                    + "th { background: #F1F5F9; padding: 10px; text-align: left; }"
                    + "td { padding: 10px; border-bottom: 1px solid #E2E8F0; }"
                    + ".logout { color: #F87171; text-decoration: none; font-weight: 700; }"
                    + "</style></head><body>"
                    + "<div class='header'>"
                    + "  <div><h1>Welcome, " + escape(studentName) + "</h1><p style='color:#94A3B8; font-size:13px;'>Roll No: " + escape(rollNumber) + " &bull; ID: " + escape(studentId) + " &bull; Dept: " + escape(dept) + "</p></div>"
                    + "  <div><a href='/logout' class='logout'>Sign Out &rarr;</a></div>"
                    + "</div>"
                    + "<div class='card'>"
                    + "  <h2>My Registered Examinations & Seating Allocations</h2>"
                    + "  <table><thead><tr><th>Exam ID</th><th>Exam Name</th><th>Subject</th><th>Seating Assignment</th><th>Status</th></tr></thead>"
                    + "  <tbody>" + examRows + "</tbody></table>"
                    + "</div>"
                    + "</body></html>";

            sendHtml(exchange, html, 200);
        }
    }

    // =========================================================================
    // 5. FACULTY DASHBOARD HANDLER
    // =========================================================================
    static class FacultyDashboardHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String query = exchange.getRequestURI().getQuery();
            Map<String, String> qmap = parseQuery(query);
            String email = qmap.getOrDefault("email", "");

            String facultyName = "Faculty Member";
            int fid = 0;
            String dept = "";

            if (!email.isEmpty()) {
                String fsql = "SELECT faculty_id, faculty_name, department FROM faculty WHERE email = ?";
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(fsql)) {
                    ps.setString(1, email);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            fid = rs.getInt("faculty_id");
                            facultyName = rs.getString("faculty_name");
                            dept = rs.getString("department");
                        }
                    }
                } catch (SQLException ignored) {}
            }

            StringBuilder dutyRows = new StringBuilder();
            if (fid > 0) {
                String dsql = "SELECT sa.exam_id, e.exam_name, sa.duty_date, sa.session_time, sa.hall_number, sa.duty_role "
                            + "FROM staff_allocation sa "
                            + "LEFT JOIN exam e ON sa.exam_id = e.exam_id "
                            + "WHERE sa.faculty_id = ? ORDER BY sa.duty_date ASC";
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(dsql)) {
                    ps.setInt(1, fid);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            dutyRows.append("<tr>")
                                    .append("<td><code>").append(escape(rs.getString("exam_id"))).append("</code></td>")
                                    .append("<td>").append(escape(rs.getString("exam_name"))).append("</td>")
                                    .append("<td>").append(escape(String.valueOf(rs.getDate("duty_date")))).append("</td>")
                                    .append("<td>").append(escape(rs.getString("session_time"))).append("</td>")
                                    .append("<td><strong>").append(escape(rs.getString("hall_number"))).append("</strong></td>")
                                    .append("<td><span style='background:#EFF6FF;color:#1E40AF;padding:3px 8px;border-radius:6px;font-weight:700;font-size:11px;'>")
                                    .append(escape(rs.getString("duty_role"))).append("</span></td>")
                                    .append("</tr>");
                        }
                    }
                } catch (SQLException ignored) {}
            }

            if (dutyRows.length() == 0) {
                dutyRows.append("<tr><td colspan='6' style='text-align:center;padding:24px;color:#64748B;'>No examination duties currently assigned.</td></tr>");
            }

            String html = "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>EMS - Faculty Portal</title>"
                    + "<link href='https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap' rel='stylesheet'>"
                    + "<style>"
                    + "* { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Plus Jakarta Sans', sans-serif; }"
                    + "body { background: #F8FAFC; color: #0F172A; padding: 32px; }"
                    + ".header { background: #0F1E41; color: white; padding: 24px; border-radius: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; }"
                    + ".card { background: white; border: 1px solid #E2E8F0; border-radius: 16px; padding: 24px; margin-bottom: 24px; }"
                    + "table { width: 100%; border-collapse: collapse; margin-top: 12px; }"
                    + "th { background: #F1F5F9; padding: 10px; text-align: left; }"
                    + "td { padding: 10px; border-bottom: 1px solid #E2E8F0; }"
                    + ".logout { color: #F87171; text-decoration: none; font-weight: 700; }"
                    + "</style></head><body>"
                    + "<div class='header'>"
                    + "  <div><h1>Faculty Console: " + escape(facultyName) + "</h1><p style='color:#94A3B8; font-size:13px;'>Department: " + escape(dept) + "</p></div>"
                    + "  <div><a href='/logout' class='logout'>Sign Out &rarr;</a></div>"
                    + "</div>"
                    + "<div class='card'>"
                    + "  <h2>Assigned Examination Invigilation Duties</h2>"
                    + "  <table><thead><tr><th>Exam ID</th><th>Exam Name</th><th>Duty Date</th><th>Session</th><th>Hall</th><th>Role</th></tr></thead>"
                    + "  <tbody>" + dutyRows + "</tbody></table>"
                    + "</div>"
                    + "</body></html>";

            sendHtml(exchange, html, 200);
        }
    }

    // =========================================================================
    // 6. API REGISTERED STUDENTS (JSON)
    // =========================================================================
    static class ApiRegisteredStudentsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
            StringBuilder json = new StringBuilder("[");
            String sql = "SELECT r.studentId, COALESCE(s.roll_number, 'N/A') AS roll_number, r.studentName, r.examId, r.examName, r.subjectId, r.status, r.registrationDate "
                       + "FROM examregistration r LEFT JOIN student s ON r.studentId = s.student_id ORDER BY r.registrationId DESC";
            try (Connection con = DBConnection.getConnection();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {
                boolean first = true;
                while (rs.next()) {
                    if (!first) json.append(",");
                    first = false;
                    json.append("{")
                        .append("\"studentId\":\"").append(escape(rs.getString("studentId"))).append("\",")
                        .append("\"rollNumber\":\"").append(escape(rs.getString("roll_number"))).append("\",")
                        .append("\"studentName\":\"").append(escape(rs.getString("studentName"))).append("\",")
                        .append("\"examId\":\"").append(escape(rs.getString("examId"))).append("\",")
                        .append("\"examName\":\"").append(escape(rs.getString("examName"))).append("\",")
                        .append("\"subjectId\":\"").append(escape(rs.getString("subjectId"))).append("\",")
                        .append("\"status\":\"").append(escape(rs.getString("status"))).append("\",")
                        .append("\"date\":\"").append(rs.getDate("registrationDate")).append("\"")
                        .append("}");
                }
            } catch (SQLException ignored) {}
            json.append("]");
            byte[] bytes = json.toString().getBytes(StandardCharsets.UTF_8);
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) { os.write(bytes); }
        }
    }

    // =========================================================================
    // 7. LOGOUT HANDLER
    // =========================================================================
    static class LogoutHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            exchange.getResponseHeaders().set("Location", "/login");
            exchange.sendResponseHeaders(302, -1);
        }
    }

    // =========================================================================
    // UTILITIES
    // =========================================================================
    private static void sendHtml(HttpExchange exchange, String html, int status) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static int countQuery(String sql) {
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException ignored) {}
        return 0;
    }

    private static Map<String, String> parseFormData(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        int len;
        while ((len = is.read(buf)) != -1) baos.write(buf, 0, len);
        String body = baos.toString(StandardCharsets.UTF_8);
        return parseQuery(body);
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isEmpty()) return map;
        for (String pair : query.split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2) {
                try {
                    String k = URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
                    String v = URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
                    map.put(k, v);
                } catch (Exception ignored) {}
            }
        }
        return map;
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
