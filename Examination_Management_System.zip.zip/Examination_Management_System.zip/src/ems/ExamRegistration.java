package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * ExamRegistration
 * Admin View: Displays all students registered for exams from MySQL,
 *             with Roll Number, Student ID, Name, Exam ID, Exam Name, Subject, Status.
 *             Provides search/filter by Student ID, Roll Number, and Exam ID,
 *             plus a "View Registered Details" button for the selected student.
 * Student View: Form for logged-in students to register for exams.
 */
public class ExamRegistration extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private String studentEmail = "";
    private boolean isAdmin = true;

    // Admin UI Components
    private JTable adminTable;
    private DefaultTableModel adminModel;
    private JTextField adminSearchField;
    private JComboBox<String> searchCategoryBox;
    private JComboBox<String> examFilterBox;
    private JLabel adminStatusLabel;

    // Student UI Components
    private JTextField registrationIdField;
    private JTextField studentIdField;
    private JTextField rollNumberField;
    private JTextField studentNameField;
    private JTextField registrationDateField;
    private JTextField statusField;
    private JComboBox<String> departmentBox;
    private JComboBox<String> yearBox;
    private JComboBox<String> examIdBox;
    private JComboBox<String> examNameBox;
    private JComboBox<String> subjectIdBox;
    private boolean loadingData = false;

    public ExamRegistration() {
        this("Admin");
    }

    public ExamRegistration(String studentEmailOrRole) {
        this.studentEmail = (studentEmailOrRole != null) ? studentEmailOrRole.trim() : "";
        this.isAdmin = studentEmail.isEmpty() || studentEmail.equalsIgnoreCase("Admin");

        if (isAdmin) {
            initAdminRegistrationView();
        } else {
            initStudentRegistrationForm();
        }
    }

    // =========================================================================
    // 1. ADMIN VIEW: REGISTERED STUDENTS LIST & AUDIT (REQUIREMENT 1)
    // =========================================================================
    private void initAdminRegistrationView() {
        setTitle("Examination Management System - Admin Exam Registrations");
        setSize(1220, 760);
        setMinimumSize(new Dimension(1000, 660));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "STUDENT EXAMINATION REGISTRATIONS",
                "Verified examination candidates, registered subjects, and registration status from MySQL"
        );
        main.add(header, BorderLayout.NORTH);

        JPanel content = new JPanel(new BorderLayout(15, 12));
        content.setBackground(BG_LIGHT);
        content.setBorder(new EmptyBorder(14, 20, 16, 20));

        // Top Search and Filter Bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(CARD_BG);
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 14, 10, 14)
        ));

        JPanel searchGroup = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchGroup.setOpaque(false);

        JLabel searchLbl = new JLabel("Search / Filter:");
        searchLbl.setFont(FONT_LABEL);
        searchGroup.add(searchLbl);

        searchCategoryBox = new JComboBox<>(new String[]{
                "All Fields", "Student ID", "Roll Number", "Exam ID"
        });
        searchCategoryBox.setFont(FONT_INPUT);
        searchGroup.add(searchCategoryBox);

        adminSearchField = new JTextField(18);
        adminSearchField.setFont(FONT_INPUT);
        adminSearchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        searchGroup.add(adminSearchField);

        JLabel examLbl = new JLabel("  Exam:");
        examLbl.setFont(FONT_LABEL);
        searchGroup.add(examLbl);

        examFilterBox = new JComboBox<>();
        examFilterBox.setFont(FONT_INPUT);
        loadAdminExamsFilter();
        examFilterBox.addActionListener(e -> loadAdminRegistrations());
        searchGroup.add(examFilterBox);

        JButton searchBtn = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton refreshBtn = createButton("Refresh", SECONDARY_GRAY, SECONDARY_HOVER);
        searchGroup.add(searchBtn);
        searchGroup.add(refreshBtn);

        JPanel actionGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionGroup.setOpaque(false);

        JButton viewDetailsBtn = createButton("View Registered Details", SUCCESS_GREEN, SUCCESS_HOVER);
        viewDetailsBtn.setPreferredSize(new Dimension(190, 34));
        actionGroup.add(viewDetailsBtn);

        topBar.add(searchGroup, BorderLayout.WEST);
        topBar.add(actionGroup, BorderLayout.EAST);
        content.add(topBar, BorderLayout.NORTH);

        // Registered Students Table
        String[] columns = {
                "Student ID", "Roll Number", "Student Name", "Exam ID", "Exam Name", "Subject", "Registration Status", "Date"
        };

        adminModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        adminTable = new JTable(adminModel);
        styleTable(adminTable);
        adminTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        adminTable.getColumnModel().getColumn(0).setCellRenderer(center); // Student ID
        adminTable.getColumnModel().getColumn(1).setCellRenderer(center); // Roll Number
        adminTable.getColumnModel().getColumn(3).setCellRenderer(center); // Exam ID
        adminTable.getColumnModel().getColumn(6).setCellRenderer(center); // Status

        JScrollPane scrollPane = new JScrollPane(adminTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        content.add(scrollPane, BorderLayout.CENTER);

        // Bottom Bar
        JPanel bottomBar = new JPanel(new BorderLayout());
        bottomBar.setBackground(BG_LIGHT);
        bottomBar.setBorder(new EmptyBorder(8, 12, 8, 12));

        adminStatusLabel = new JLabel("Loading registrations...");
        adminStatusLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        adminStatusLabel.setForeground(NAVY);
        bottomBar.add(adminStatusLabel, BorderLayout.WEST);

        JPanel rightBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightBottom.setOpaque(false);
        JButton backBtn = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));
        backBtn.addActionListener(e -> dispose());
        rightBottom.add(backBtn);
        bottomBar.add(rightBottom, BorderLayout.EAST);

        content.add(bottomBar, BorderLayout.SOUTH);

        main.add(content, BorderLayout.CENTER);
        setContentPane(main);

        // Listeners
        searchBtn.addActionListener(e -> searchAdminRegistrations());
        adminSearchField.addActionListener(e -> searchAdminRegistrations());
        refreshBtn.addActionListener(e -> {
            adminSearchField.setText("");
            searchCategoryBox.setSelectedIndex(0);
            if (examFilterBox.getItemCount() > 0) examFilterBox.setSelectedIndex(0);
            loadAdminRegistrations();
        });

        viewDetailsBtn.addActionListener(e -> openStudentRegistrationDetails());

        loadAdminRegistrations();
        setVisible(true);
    }

    private void loadAdminExamsFilter() {
        examFilterBox.removeAllItems();
        examFilterBox.addItem("All Exams");
        String sql = "SELECT exam_id, exam_name FROM exam ORDER BY exam_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                examFilterBox.addItem(rs.getString("exam_id") + " - " + rs.getString("exam_name"));
            }
        } catch (SQLException ignored) {}
    }

    private void loadAdminRegistrations() {
        adminModel.setRowCount(0);

        StringBuilder sql = new StringBuilder(
                "SELECT r.registrationId, r.studentId, COALESCE(s.roll_number, 'N/A') AS roll_number, "
                + "r.studentName, r.examId, r.examName, "
                + "CONCAT(r.subjectId, ' - ', COALESCE(sub.subject_name, '')) AS subject_display, "
                + "r.status, r.registrationDate "
                + "FROM examregistration r "
                + "LEFT JOIN student s ON r.studentId = s.student_id "
                + "LEFT JOIN subject sub ON r.subjectId = sub.subject_id WHERE 1=1 "
        );

        String examSel = (examFilterBox.getSelectedItem() != null) ? examFilterBox.getSelectedItem().toString() : "";
        String examId = "";
        if (!examSel.isEmpty() && !examSel.equalsIgnoreCase("All Exams")) {
            examId = examSel.split(" - ")[0].trim();
            sql.append(" AND r.examId = ? ");
        }

        sql.append(" ORDER BY r.registrationId DESC");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            if (!examId.isEmpty()) {
                ps.setString(1, examId);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    adminModel.addRow(new Object[]{
                            rs.getString("studentId"),
                            rs.getString("roll_number"),
                            rs.getString("studentName"),
                            rs.getString("examId"),
                            rs.getString("examName"),
                            rs.getString("subject_display"),
                            rs.getString("status"),
                            rs.getDate("registrationDate")
                    });
                }
            }

            if (adminStatusLabel != null) {
                if (adminModel.getRowCount() == 0) {
                    adminStatusLabel.setText("No registrations currently available in the database.");
                    adminStatusLabel.setForeground(new Color(185, 28, 28));
                } else {
                    adminStatusLabel.setText("Total Registered Candidates: " + adminModel.getRowCount());
                    adminStatusLabel.setForeground(new Color(22, 101, 52));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load registrations: " + e.getMessage());
        }
    }

    private void searchAdminRegistrations() {
        String keyword = adminSearchField.getText().trim();
        String category = (searchCategoryBox.getSelectedItem() != null) ? searchCategoryBox.getSelectedItem().toString() : "All Fields";

        if (keyword.isEmpty()) {
            loadAdminRegistrations();
            return;
        }

        adminModel.setRowCount(0);
        StringBuilder sql = new StringBuilder(
                "SELECT r.registrationId, r.studentId, COALESCE(s.roll_number, 'N/A') AS roll_number, "
                + "r.studentName, r.examId, r.examName, "
                + "CONCAT(r.subjectId, ' - ', COALESCE(sub.subject_name, '')) AS subject_display, "
                + "r.status, r.registrationDate "
                + "FROM examregistration r "
                + "LEFT JOIN student s ON r.studentId = s.student_id "
                + "LEFT JOIN subject sub ON r.subjectId = sub.subject_id WHERE "
        );

        switch (category) {
            case "Student ID":
                sql.append(" r.studentId LIKE ? ");
                break;
            case "Roll Number":
                sql.append(" s.roll_number LIKE ? ");
                break;
            case "Exam ID":
                sql.append(" r.examId LIKE ? ");
                break;
            default:
                sql.append(" (r.studentId LIKE ? OR s.roll_number LIKE ? OR r.examId LIKE ? OR r.studentName LIKE ?) ");
                break;
        }

        sql.append(" ORDER BY r.registrationId DESC");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            String pat = "%" + keyword + "%";
            if (category.equals("Student ID") || category.equals("Roll Number") || category.equals("Exam ID")) {
                ps.setString(1, pat);
            } else {
                ps.setString(1, pat);
                ps.setString(2, pat);
                ps.setString(3, pat);
                ps.setString(4, pat);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    adminModel.addRow(new Object[]{
                            rs.getString("studentId"),
                            rs.getString("roll_number"),
                            rs.getString("studentName"),
                            rs.getString("examId"),
                            rs.getString("examName"),
                            rs.getString("subject_display"),
                            rs.getString("status"),
                            rs.getDate("registrationDate")
                    });
                }
            }

            if (adminStatusLabel != null) {
                if (adminModel.getRowCount() == 0) {
                    adminStatusLabel.setText("No registrations found matching '" + keyword + "'.");
                    adminStatusLabel.setForeground(new Color(185, 28, 28));
                    JOptionPane.showMessageDialog(this, "No exam registrations found matching: " + keyword);
                } else {
                    adminStatusLabel.setText("Found " + adminModel.getRowCount() + " registrations matching '" + keyword + "'.");
                    adminStatusLabel.setForeground(new Color(22, 101, 52));
                }
            } else if (adminModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No exam registrations found matching: " + keyword);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Search error: " + e.getMessage());
        }
    }

    /**
     * "View Registered Details" button action:
     * Displays all exams registered by the selected student.
     */
    private void openStudentRegistrationDetails() {
        int row = adminTable.getSelectedRow();
        String studentId = "";

        if (row >= 0) {
            studentId = adminModel.getValueAt(row, 0).toString().trim();
        } else {
            studentId = JOptionPane.showInputDialog(this, "Enter Student ID or Roll Number to view all registered exams:");
            if (studentId == null || studentId.trim().isEmpty()) return;
            studentId = studentId.trim();

            // Resolve studentId if roll number entered
            String resolved = resolveStudentId(studentId);
            if (resolved != null) studentId = resolved;
        }

        // Fetch student demographic details
        String studentName = "";
        String rollNumber = "";
        String dept = "";
        String yr = "";
        String email = "";

        String stuSql = "SELECT student_id, roll_number, student_name, department, year, email FROM student WHERE student_id = ? OR roll_number = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(stuSql)) {
            ps.setString(1, studentId);
            ps.setString(2, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    studentId = rs.getString("student_id");
                    rollNumber = rs.getString("roll_number");
                    studentName = rs.getString("student_name");
                    dept = rs.getString("department");
                    yr = rs.getString("year") + " Year";
                    email = rs.getString("email");
                }
            }
        } catch (SQLException ignored) {}

        JDialog dlg = new JDialog(this, "Registered Examination Details - " + studentName, true);
        dlg.setSize(860, 520);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel header = createHeader("STUDENT REGISTERED EXAMINATIONS", "Complete list of examination sessions enrolled by " + studentName);
        dlg.add(header, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(BG_LIGHT);
        centerPanel.setBorder(new EmptyBorder(12, 16, 12, 16));

        // Info Card
        JPanel infoCard = new JPanel(new GridLayout(2, 3, 10, 6));
        infoCard.setBackground(CARD_BG);
        infoCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 14, 10, 14)
        ));

        infoCard.add(new JLabel("Student ID: " + studentId));
        infoCard.add(new JLabel("Roll Number: " + (rollNumber != null ? rollNumber : "N/A")));
        infoCard.add(new JLabel("Student Name: " + studentName));
        infoCard.add(new JLabel("Department: " + dept));
        infoCard.add(new JLabel("Academic Year: " + yr));
        infoCard.add(new JLabel("Email: " + email));

        centerPanel.add(infoCard, BorderLayout.NORTH);

        // Exams Table
        String[] detailCols = {"Reg ID", "Exam ID", "Exam Name", "Subject ID", "Subject Name", "Registration Date", "Status"};
        DefaultTableModel detailModel = new DefaultTableModel(detailCols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable detailTable = new JTable(detailModel);
        styleTable(detailTable);

        String detailSql = "SELECT r.registrationId, r.examId, r.examName, r.subjectId, "
                         + "COALESCE(sub.subject_name, '') AS sub_name, r.registrationDate, r.status "
                         + "FROM examregistration r "
                         + "LEFT JOIN subject sub ON r.subjectId = sub.subject_id "
                         + "WHERE r.studentId = ? ORDER BY r.registrationDate ASC, r.examId ASC";

        int regCount = 0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(detailSql)) {
            ps.setString(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    regCount++;
                    detailModel.addRow(new Object[]{
                            rs.getInt("registrationId"),
                            rs.getString("examId"),
                            rs.getString("examName"),
                            rs.getString("subjectId"),
                            rs.getString("sub_name"),
                            rs.getDate("registrationDate"),
                            rs.getString("status")
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dlg, "Error retrieving exam records: " + ex.getMessage());
        }

        if (regCount == 0) {
            JOptionPane.showMessageDialog(this,
                    "No examination registrations found for Student: " + (studentName.isEmpty() ? studentId : studentName + " (" + studentId + ")"),
                    "No Registrations", JOptionPane.INFORMATION_MESSAGE);
            dlg.dispose();
            return;
        }

        centerPanel.add(new JScrollPane(detailTable), BorderLayout.CENTER);
        dlg.add(centerPanel, BorderLayout.CENTER);

        JPanel btm = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        btm.setBackground(BG_LIGHT);
        JLabel countLbl = new JLabel("Total Registered Exams: " + regCount + "   ");
        countLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        countLbl.setForeground(NAVY);
        btm.add(countLbl);

        JButton closeBtn = createButton("Close", PRIMARY_BLUE, PRIMARY_HOVER);
        closeBtn.addActionListener(e -> dlg.dispose());
        btm.add(closeBtn);
        dlg.add(btm, BorderLayout.SOUTH);

        dlg.setVisible(true);
    }

    private String resolveStudentId(String input) {
        String sql = "SELECT student_id FROM student WHERE roll_number = ? OR student_id = ? LIMIT 1";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, input);
            ps.setString(2, input);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getString("student_id");
            }
        } catch (SQLException ignored) {}
        return null;
    }

    // =========================================================================
    // 2. STUDENT VIEW: REGISTRATION FORM FOR STUDENT PORTAL
    // =========================================================================
    private void initStudentRegistrationForm() {
        setTitle("Examination Management System - Student Exam Registration");
        setSize(1080, 720);
        setMinimumSize(new Dimension(920, 640));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "STUDENT EXAM REGISTRATION PORTAL",
                "Enroll for upcoming semester end examinations and course evaluations"
        );
        main.add(header, BorderLayout.NORTH);

        // FORM CARD
        JPanel centerWrapper = new JPanel(new BorderLayout());
        centerWrapper.setBackground(BG_LIGHT);
        centerWrapper.setBorder(new EmptyBorder(20, 25, 20, 25));

        JPanel card = new JPanel(new GridLayout(1, 2, 24, 0));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(20, 25, 20, 25)
        ));

        JPanel left = new JPanel(new GridLayout(6, 1, 0, 10));
        JPanel right = new JPanel(new GridLayout(6, 1, 0, 10));
        left.setOpaque(false);
        right.setOpaque(false);

        registrationIdField = new JTextField("Auto-generated (6 digits)");
        registrationIdField.setEditable(false);
        registrationIdField.setFont(FONT_INPUT);
        registrationIdField.setBackground(new Color(241, 245, 249));

        studentIdField = new JTextField();
        studentIdField.setFont(FONT_INPUT);

        rollNumberField = new JTextField();
        rollNumberField.setFont(FONT_INPUT);
        rollNumberField.setEditable(false);
        rollNumberField.setBackground(new Color(241, 245, 249));

        studentNameField = new JTextField();
        studentNameField.setFont(FONT_INPUT);

        departmentBox = new JComboBox<>();
        departmentBox.setFont(FONT_INPUT);

        yearBox = new JComboBox<>(new String[]{
                "Select Year", "1st Year", "2nd Year", "3rd Year", "4th Year"
        });
        yearBox.setFont(FONT_INPUT);

        examIdBox = new JComboBox<>();
        examIdBox.setFont(FONT_INPUT);

        examNameBox = new JComboBox<>();
        examNameBox.setFont(FONT_INPUT);

        subjectIdBox = new JComboBox<>();
        subjectIdBox.setFont(FONT_INPUT);

        registrationDateField = new JTextField(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        registrationDateField.setEditable(false);
        registrationDateField.setFont(FONT_INPUT);
        registrationDateField.setBackground(new Color(241, 245, 249));

        statusField = new JTextField("Registered");
        statusField.setEditable(false);
        statusField.setFont(FONT_INPUT);
        statusField.setBackground(new Color(240, 253, 244));
        statusField.setForeground(SUCCESS_GREEN);

        addFormField(left, "Registration ID", registrationIdField);
        addFormField(left, "Student ID", studentIdField);
        addFormField(left, "Roll Number", rollNumberField);
        addFormField(left, "Student Name", studentNameField);
        addFormField(left, "Department", departmentBox);
        addFormField(left, "Year of Study", yearBox);

        addFormField(right, "Select Exam ID", examIdBox);
        addFormField(right, "Exam Name", examNameBox);
        addFormField(right, "Subject ID", subjectIdBox);
        addFormField(right, "Registration Date", registrationDateField);
        addFormField(right, "Registration Status", statusField);

        // Placeholder for symmetry
        JPanel blank = new JPanel();
        blank.setOpaque(false);
        right.add(blank);

        card.add(left);
        card.add(right);
        centerWrapper.add(card, BorderLayout.CENTER);
        main.add(centerWrapper, BorderLayout.CENTER);

        // BUTTONS
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 16));
        buttons.setBackground(BG_LIGHT);

        JButton backButton = createButton("Back", new Color(71, 85, 105), new Color(51, 65, 85));
        JButton clearButton = createButton("Clear Form", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton viewButton = createButton("View My Registrations", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton registerButton = createButton("Confirm Registration", SUCCESS_GREEN, SUCCESS_HOVER);

        buttons.add(backButton);
        buttons.add(clearButton);
        buttons.add(viewButton);
        buttons.add(registerButton);

        main.add(buttons, BorderLayout.SOUTH);
        setContentPane(main);

        // LISTENERS
        registerButton.addActionListener(e -> registerExam());
        viewButton.addActionListener(e -> openStudentRegistrationDetails());
        clearButton.addActionListener(e -> clearForm());
        backButton.addActionListener(e -> dispose());

        examIdBox.addActionListener(e -> {
            if (!loadingData && examIdBox.getSelectedIndex() > 0) {
                syncExamDetails();
            }
        });

        // Load Initial Data
        loadDepartments();
        loadExams();
        loadStudentInfo();
        generateRegistrationIdPreview();

        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(16, 25, 16, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));
    }

    private void addFormField(JPanel panel, String labelText, JComponent field) {
        JPanel fGroup = new JPanel(new BorderLayout(0, 3));
        fGroup.setOpaque(false);

        JLabel label = new JLabel(labelText);
        label.setFont(FONT_LABEL);
        label.setForeground(TEXT_DARK);

        fGroup.add(label, BorderLayout.NORTH);
        fGroup.add(field, BorderLayout.CENTER);
        panel.add(fGroup);
    }

    private void loadDepartments() {
        departmentBox.removeAllItems();
        departmentBox.addItem("Select Department");

        String sql = "SELECT department_id, department_name FROM department ORDER BY department_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                departmentBox.addItem(rs.getString("department_id") + " - " + rs.getString("department_name"));
            }
        } catch (SQLException ignored) {}
    }

    private void loadExams() {
        loadingData = true;
        examIdBox.removeAllItems();
        examNameBox.removeAllItems();
        subjectIdBox.removeAllItems();

        examIdBox.addItem("Select Exam ID");
        examNameBox.addItem("Select Exam Name");
        subjectIdBox.addItem("Select Subject ID");

        String sql = "SELECT exam_id, exam_name, subject_id FROM exam ORDER BY exam_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                examIdBox.addItem(rs.getString("exam_id"));
                examNameBox.addItem(rs.getString("exam_name"));
                subjectIdBox.addItem(rs.getString("subject_id"));
            }
        } catch (SQLException ignored) {} finally {
            loadingData = false;
        }
    }

    private void syncExamDetails() {
        int idx = examIdBox.getSelectedIndex();
        if (idx > 0 && idx < examNameBox.getItemCount() && idx < subjectIdBox.getItemCount()) {
            examNameBox.setSelectedIndex(idx);
            subjectIdBox.setSelectedIndex(idx);
        }
    }

    private void loadStudentInfo() {
        if (studentEmail == null || studentEmail.trim().isEmpty()) {
            return;
        }

        String sql = "SELECT student_id, roll_number, student_name, department, year FROM student WHERE email = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, studentEmail.trim());

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    studentIdField.setText(rs.getString("student_id"));
                    rollNumberField.setText(rs.getString("roll_number"));
                    studentNameField.setText(rs.getString("student_name"));

                    studentIdField.setEditable(false);
                    studentNameField.setEditable(false);

                    String dept = rs.getString("department");
                    if (dept != null) {
                        for (int i = 0; i < departmentBox.getItemCount(); i++) {
                            if (departmentBox.getItemAt(i).contains(dept) || dept.contains(departmentBox.getItemAt(i))) {
                                departmentBox.setSelectedIndex(i);
                                break;
                            }
                        }
                    }

                    int yr = rs.getInt("year");
                    if (yr >= 1 && yr <= 4) {
                        yearBox.setSelectedIndex(yr);
                    }
                }
            }
        } catch (SQLException ignored) {}
    }

    private void generateRegistrationIdPreview() {
        String sql = "SELECT COALESCE(MAX(registrationId), 100000) + 1 FROM examregistration";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                int nextId = rs.getInt(1);
                if (nextId < 100001) nextId = 100001;
                registrationIdField.setText(String.valueOf(nextId));
            }
        } catch (SQLException ex) {
            registrationIdField.setText("Auto-assigned");
        }
    }

    private void registerExam() {
        String studentId = studentIdField.getText().trim();
        String studentName = studentNameField.getText().trim();

        if (studentId.isEmpty() || studentName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Student ID and Student Name are required.");
            return;
        }

        if (examIdBox.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Please select an Examination ID.");
            return;
        }

        String department = (departmentBox.getSelectedItem() != null) ? departmentBox.getSelectedItem().toString().split(" - ")[0].trim() : "";
        String year = (yearBox.getSelectedItem() != null) ? yearBox.getSelectedItem().toString() : "";
        String examId = examIdBox.getSelectedItem().toString();
        String examName = examNameBox.getSelectedItem().toString();
        String subjectId = subjectIdBox.getSelectedItem().toString();
        String regDate = registrationDateField.getText().trim();
        String status = statusField.getText().trim();

        // Check duplicate registration
        String checkSql = "SELECT COUNT(*) FROM examregistration WHERE studentId = ? AND examId = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement checkPs = con.prepareStatement(checkSql)) {

            checkPs.setString(1, studentId);
            checkPs.setString(2, examId);

            try (ResultSet checkRs = checkPs.executeQuery()) {
                if (checkRs.next() && checkRs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this,
                            "Student (" + studentId + ") is already registered for Exam: " + examId + "!",
                            "Duplicate Registration", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }

            // Insert registration
            String insertSql = "INSERT INTO examregistration "
                    + "(studentId, studentName, department, year, examId, examName, subjectId, registrationDate, status) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (PreparedStatement ps = con.prepareStatement(insertSql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, studentId);
                ps.setString(2, studentName);
                ps.setString(3, department);
                ps.setString(4, year);
                ps.setString(5, examId);
                ps.setString(6, examName);
                ps.setString(7, subjectId);
                ps.setDate(8, Date.valueOf(regDate));
                ps.setString(9, status);

                int rows = ps.executeUpdate();
                if (rows > 0) {
                    int assignedId = 0;
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (keys.next()) assignedId = keys.getInt(1);
                    }

                    JOptionPane.showMessageDialog(this,
                            "Registration Successful!\n"
                            + "Registration ID: " + (assignedId > 0 ? assignedId : registrationIdField.getText()) + "\n"
                            + "Exam: " + examName + " (" + examId + ")\n"
                            + "Student: " + studentName + " (" + studentId + ")",
                            "Registration Confirmed", JOptionPane.INFORMATION_MESSAGE);

                    generateRegistrationIdPreview();
                } else {
                    JOptionPane.showMessageDialog(this, "Registration failed.");
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error during registration: " + ex.getMessage());
        }
    }

    private void clearForm() {
        if (studentEmail.isEmpty()) {
            studentIdField.setText("");
            rollNumberField.setText("");
            studentNameField.setText("");
            departmentBox.setSelectedIndex(0);
            yearBox.setSelectedIndex(0);
        }
        examIdBox.setSelectedIndex(0);
        examNameBox.setSelectedIndex(0);
        subjectIdBox.setSelectedIndex(0);
        generateRegistrationIdPreview();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ExamRegistration::new);
    }
}
