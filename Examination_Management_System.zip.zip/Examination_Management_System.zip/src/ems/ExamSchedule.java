package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ExamSchedule extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTable table;
    private DefaultTableModel model;
    private JLabel messageLabel;
    private JTextField searchField;

    public ExamSchedule() {
        setTitle("Examination Management System - Examination Timetable");
        setSize(1050, 620);
        setMinimumSize(new Dimension(880, 500));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "EXAMINATION TIMETABLE & SCHEDULE",
                "View scheduled examinations, timings, subject codes, and test durations"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Search Bar Card
        JPanel searchBar = new JPanel(new BorderLayout());
        searchBar.setBackground(CARD_BG);
        searchBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 15, 10, 15)
        ));

        JPanel searchGroup = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        searchGroup.setOpaque(false);

        JLabel searchLbl = new JLabel("Search Exam / Subject ID:");
        searchLbl.setFont(FONT_LABEL);
        searchLbl.setForeground(TEXT_DARK);

        searchField = new JTextField(18);
        searchField.setFont(FONT_INPUT);
        searchField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        JButton searchBtn = createButton("Search", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton refreshBtn = createButton("Refresh", SECONDARY_GRAY, SECONDARY_HOVER);

        searchGroup.add(searchLbl);
        searchGroup.add(searchField);
        searchGroup.add(searchBtn);
        searchGroup.add(refreshBtn);
        searchBar.add(searchGroup, BorderLayout.WEST);

        contentPanel.add(searchBar, BorderLayout.NORTH);

        // Table
        String[] columns = {
            "Exam ID", "Subject ID", "Exam Name", "Date", "Start Time", "End Time", "Total Marks", "Type"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));

        messageLabel = new JLabel("", JLabel.CENTER);
        messageLabel.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        messageLabel.setForeground(new Color(185, 28, 28));
        messageLabel.setBorder(new EmptyBorder(6, 0, 6, 0));

        JPanel centerPanel = new JPanel(new BorderLayout(0, 5));
        centerPanel.setOpaque(false);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(messageLabel, BorderLayout.SOUTH);

        contentPanel.add(centerPanel, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        bottomPanel.setBackground(BG_LIGHT);

        JButton backButton = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));
        bottomPanel.add(backButton);
        contentPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);

        // Listeners
        backButton.addActionListener(e -> dispose());
        searchBtn.addActionListener(e -> loadExams(searchField.getText().trim()));
        searchField.addActionListener(e -> loadExams(searchField.getText().trim()));
        refreshBtn.addActionListener(e -> {
            searchField.setText("");
            loadExams("");
        });

        loadExams("");
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void loadExams(String keyword) {
        model.setRowCount(0);
        messageLabel.setText("");

        String sql;
        boolean hasFilter = keyword != null && !keyword.trim().isEmpty();

        if (hasFilter) {
            sql = "SELECT exam_id, subject_id, exam_name, exam_date, start_time, end_time, total_marks, exam_type "
                + "FROM exam WHERE exam_id LIKE ? OR subject_id LIKE ? OR exam_name LIKE ? "
                + "ORDER BY exam_date, start_time";
        } else {
            sql = "SELECT exam_id, subject_id, exam_name, exam_date, start_time, end_time, total_marks, exam_type "
                + "FROM exam ORDER BY exam_date, start_time";
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (hasFilter) {
                String pattern = "%" + keyword.trim() + "%";
                ps.setString(1, pattern);
                ps.setString(2, pattern);
                ps.setString(3, pattern);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("exam_id"),
                        rs.getString("subject_id"),
                        rs.getString("exam_name"),
                        rs.getDate("exam_date"),
                        rs.getTime("start_time"),
                        rs.getTime("end_time"),
                        rs.getObject("total_marks"),
                        rs.getString("exam_type")
                    });
                }
            }

            if (model.getRowCount() == 0) {
                messageLabel.setText("No Exam Schedules Available.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading exam schedule: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ExamSchedule::new);
    }
}
