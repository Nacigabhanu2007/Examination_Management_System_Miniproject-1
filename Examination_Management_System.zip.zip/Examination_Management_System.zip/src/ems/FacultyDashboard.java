package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Modern, Professional Faculty Dashboard
 * Personalized portal for the logged-in faculty member.
 * Completely self-contained with no external UI dependencies.
 */
public class FacultyDashboard extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);

    private String facultyEmail = "";
    private String facultyName = "Faculty Member";
    private int facultyId = -1;
    private String department = "";
    private String designation = "";

    private JLabel dutiesCountLbl;
    private JLabel studentsCountLbl;
    private JLabel marksCountLbl;

    private DefaultTableModel assignedDutiesModel;
    private JTable assignedDutiesTable;

    public FacultyDashboard() {
        this("");
    }

    public FacultyDashboard(String facultyEmail) {
        this.facultyEmail = (facultyEmail != null) ? facultyEmail.trim() : "";
        fetchFacultyInfo();

        setTitle("Examination Management System - Faculty Portal");
        setSize(1200, 780);
        setMinimumSize(new Dimension(1000, 680));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // LEFT SIDEBAR
        JPanel sidebar = new JPanel();
        sidebar.setBackground(NAVY);
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(new EmptyBorder(25, 16, 25, 16));

        JLabel logo = new JLabel(" EMS PORTAL");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel(" Faculty & Academic Portal");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(new Color(190, 205, 235));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(25));

        // Navigation Sidebar Buttons
        addSidebarButton(sidebar, "Dashboard", () -> refreshDashboard());
        addSidebarButton(sidebar, "Faculty Profile", () -> new FacultyProfile(facultyEmail).setVisible(true));
        addSidebarButton(sidebar, "Assigned Duties", () -> showAssignedDuties());
        addSidebarButton(sidebar, "Staff Allocation View", () -> showAssignedDuties());
        addSidebarButton(sidebar, "Exam Schedules", () -> new ExamSchedule().setVisible(true));
        addSidebarButton(sidebar, "Enter & Manage Marks", () -> new AdminMarksResults("Faculty", facultyEmail).setVisible(true));
        addSidebarButton(sidebar, "Student Directory", () -> showStudentDetails());
        addSidebarButton(sidebar, "View Curriculum Subjects", () -> new Subjects(facultyEmail).setVisible(true));

        sidebar.add(Box.createVerticalGlue());

        JButton logoutButton = createDangerButton("Logout");
        logoutButton.setPreferredSize(new Dimension(218, 38));
        logoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        logoutButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        logoutButton.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to log out of your faculty session?",
                    "Confirm Logout",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (choice == JOptionPane.YES_OPTION) {
                dispose();
                new Login().setVisible(true);
            }
        });

        sidebar.add(logoutButton);
        mainPanel.add(sidebar, BorderLayout.WEST);

        // RIGHT CONTENT PANEL
        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setBackground(BG_LIGHT);
        content.setBorder(new EmptyBorder(25, 30, 25, 30));

        // TOP HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel headingPanel = new JPanel();
        headingPanel.setOpaque(false);
        headingPanel.setLayout(new BoxLayout(headingPanel, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("Faculty Dashboard");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 28));
        heading.setForeground(NAVY);

        JLabel welcome = new JLabel("Welcome, " + facultyName + "! (" + (designation.isEmpty() ? "Faculty" : designation) + " • " + department + ")");
        welcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        welcome.setForeground(TEXT_MUTED);

        headingPanel.add(heading);
        headingPanel.add(Box.createVerticalStrut(6));
        headingPanel.add(welcome);

        JLabel roleBadge = new JLabel(" FACULTY ");
        roleBadge.setOpaque(true);
        roleBadge.setBackground(new Color(224, 238, 255));
        roleBadge.setForeground(PRIMARY_BLUE);
        roleBadge.setFont(new Font("Segoe UI", Font.BOLD, 13));
        roleBadge.setBorder(new EmptyBorder(8, 14, 8, 14));

        header.add(headingPanel, BorderLayout.WEST);
        header.add(roleBadge, BorderLayout.EAST);
        content.add(header, BorderLayout.NORTH);

        // BODY CONTAINER
        JPanel bodyContainer = new JPanel();
        bodyContainer.setLayout(new BoxLayout(bodyContainer, BoxLayout.Y_AXIS));
        bodyContainer.setOpaque(false);

        // SUMMARY METRICS CARDS
        JPanel summaryPanel = new JPanel(new GridLayout(1, 3, 18, 0));
        summaryPanel.setOpaque(false);

        dutiesCountLbl = new JLabel("0", SwingConstants.LEFT);
        studentsCountLbl = new JLabel("0", SwingConstants.LEFT);
        marksCountLbl = new JLabel("0", SwingConstants.LEFT);

        summaryPanel.add(createSummaryCard("ASSIGNED DUTIES", dutiesCountLbl, "Invigilation Duties", new Color(30, 64, 124)));
        summaryPanel.add(createSummaryCard("TOTAL STUDENTS", studentsCountLbl, "Enrolled Candidates", new Color(13, 148, 136)));
        summaryPanel.add(createSummaryCard("EVALUATED MARKS", marksCountLbl, "Submitted Grade Entries", new Color(217, 119, 6)));

        bodyContainer.add(summaryPanel);
        bodyContainer.add(Box.createVerticalStrut(20));

        // ASSIGNED CLASSES & DUTIES LIVE TABLE CARD
        JPanel dutiesCard = new JPanel(new BorderLayout(0, 10));
        dutiesCard.setBackground(CARD_BG);
        dutiesCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(16, 20, 16, 20)
        ));

        JPanel dutiesCardHeader = new JPanel(new BorderLayout());
        dutiesCardHeader.setOpaque(false);

        JPanel dutiesTitlePanel = new JPanel();
        dutiesTitlePanel.setOpaque(false);
        dutiesTitlePanel.setLayout(new BoxLayout(dutiesTitlePanel, BoxLayout.Y_AXIS));

        JLabel dutiesTitle = new JLabel("My Assigned Classes & Examination Duties");
        dutiesTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        dutiesTitle.setForeground(NAVY);

        JLabel dutiesSub = new JLabel("Live classes and supervisory duties assigned to " + facultyName);
        dutiesSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        dutiesSub.setForeground(TEXT_MUTED);

        dutiesTitlePanel.add(dutiesTitle);
        dutiesTitlePanel.add(Box.createVerticalStrut(2));
        dutiesTitlePanel.add(dutiesSub);

        JPanel btnGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnGroup.setOpaque(false);

        JButton viewAllBtn = new JButton("Detailed View");
        viewAllBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        viewAllBtn.setForeground(PRIMARY_BLUE);
        viewAllBtn.setBackground(new Color(239, 246, 255));
        viewAllBtn.setFocusPainted(false);
        viewAllBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(191, 219, 254), 1),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        viewAllBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        viewAllBtn.addActionListener(e -> showAssignedDuties());

        JButton refreshDutiesBtn = new JButton("Refresh");
        refreshDutiesBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshDutiesBtn.setForeground(Color.WHITE);
        refreshDutiesBtn.setBackground(PRIMARY_BLUE);
        refreshDutiesBtn.setFocusPainted(false);
        refreshDutiesBtn.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        refreshDutiesBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        refreshDutiesBtn.addActionListener(e -> refreshDashboard());

        btnGroup.add(viewAllBtn);
        btnGroup.add(refreshDutiesBtn);

        dutiesCardHeader.add(dutiesTitlePanel, BorderLayout.WEST);
        dutiesCardHeader.add(btnGroup, BorderLayout.EAST);
        dutiesCard.add(dutiesCardHeader, BorderLayout.NORTH);

        String[] dutyCols = {"Alloc ID", "Class Code", "Class / Subject Name", "Exam ID", "Exam Name", "Duty Date", "Session", "Hall", "Role"};
        assignedDutiesModel = new DefaultTableModel(dutyCols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        assignedDutiesTable = new JTable(assignedDutiesModel);
        styleTable(assignedDutiesTable);

        JScrollPane tableScroll = new JScrollPane(assignedDutiesTable);
        tableScroll.setPreferredSize(new Dimension(0, 160));
        tableScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        dutiesCard.add(tableScroll, BorderLayout.CENTER);

        bodyContainer.add(dutiesCard);
        bodyContainer.add(Box.createVerticalStrut(20));

        // QUICK ACCESS MODULES
        JPanel centerPanel = new JPanel(new BorderLayout(0, 12));
        centerPanel.setOpaque(false);

        JLabel quickTitle = new JLabel("Faculty Academic Modules");
        quickTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        quickTitle.setForeground(TEXT_DARK);

        JLabel quickSubtitle = new JLabel("Manage assigned exam duties, student evaluations, marks records, and college directories.");
        quickSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        quickSubtitle.setForeground(TEXT_MUTED);

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(quickTitle);
        titlePanel.add(Box.createVerticalStrut(4));
        titlePanel.add(quickSubtitle);

        JPanel buttonGrid = new JPanel(new GridLayout(2, 3, 16, 16));
        buttonGrid.setOpaque(false);

        addModuleCard(buttonGrid, "My Faculty Profile", "View and update your academic credentials and contact record.", () -> new FacultyProfile(facultyEmail).setVisible(true), new Color(30, 64, 124));
        addModuleCard(buttonGrid, "Assigned Duties", "Check your scheduled exam dates, invigilation halls and times.", () -> showAssignedDuties(), new Color(109, 40, 217));
        addModuleCard(buttonGrid, "Enter & Update Marks", "Input and evaluate marks for examination candidates.", () -> new AdminMarksResults("Faculty", facultyEmail).setVisible(true), new Color(13, 148, 136));
        addModuleCard(buttonGrid, "Exam Timetables", "Monitor all published examination sessions and subjects.", () -> new ExamSchedule().setVisible(true), new Color(217, 119, 6));
        addModuleCard(buttonGrid, "Student Directory", "Search student profiles, branches and roll numbers.", () -> showStudentDetails(), new Color(225, 29, 72));
        addModuleCard(buttonGrid, "Curriculum Subjects", "Browse syllabus subjects and department mappings.", () -> new Subjects(facultyEmail).setVisible(true), new Color(2, 132, 199));

        centerPanel.add(titlePanel, BorderLayout.NORTH);
        centerPanel.add(buttonGrid, BorderLayout.CENTER);
        bodyContainer.add(centerPanel);

        JScrollPane scrollPane = new JScrollPane(bodyContainer);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        content.add(scrollPane, BorderLayout.CENTER);

        // FOOTER
        JLabel footer = new JLabel("College Examination Management System • Java SE 21 & MySQL • Faculty Portal", SwingConstants.CENTER);
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        footer.setForeground(TEXT_MUTED);
        content.add(footer, BorderLayout.SOUTH);

        mainPanel.add(content, BorderLayout.CENTER);

        setContentPane(mainPanel);
        refreshDashboard();
        setVisible(true);
    }

    private void addSidebarButton(JPanel sidebar, String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(new Color(226, 232, 240));
        button.setBackground(new Color(30, 48, 86));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(218, 38));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(new EmptyBorder(8, 14, 8, 14));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(PRIMARY_BLUE);
                button.setForeground(Color.WHITE);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(30, 48, 86));
                button.setForeground(new Color(226, 232, 240));
            }
        });

        button.addActionListener(e -> action.run());
        sidebar.add(button);
        sidebar.add(Box.createVerticalStrut(5));
    }

    private JButton createDangerButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(DANGER_RED);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(DANGER_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(DANGER_RED);
            }
        });
        return btn;
    }

    private JPanel createSummaryCard(String title, JLabel countLbl, String description, Color accent) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_COLOR, 1),
                        new EmptyBorder(14, 16, 14, 16)
                )
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLabel.setForeground(TEXT_MUTED);

        countLbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
        countLbl.setForeground(accent);

        JLabel descLabel = new JLabel(description);
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(TEXT_MUTED);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(countLbl);
        card.add(Box.createVerticalStrut(4));
        card.add(descLabel);

        return card;
    }

    private void addModuleCard(JPanel grid, String title, String description, Runnable action, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(color);

        JLabel descLabel = new JLabel("<html>" + description + "</html>");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(TEXT_MUTED);

        JButton openBtn = new JButton("Open Service");
        openBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        openBtn.setForeground(Color.WHITE);
        openBtn.setBackground(PRIMARY_BLUE);
        openBtn.setFocusPainted(false);
        openBtn.setBorderPainted(false);
        openBtn.setOpaque(true);
        openBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        openBtn.setPreferredSize(new Dimension(120, 32));

        openBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                openBtn.setBackground(PRIMARY_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                openBtn.setBackground(PRIMARY_BLUE);
            }
        });

        openBtn.addActionListener(e -> action.run());

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(descLabel, BorderLayout.CENTER);
        card.add(openBtn, BorderLayout.SOUTH);

        grid.add(card);
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setSelectionBackground(new Color(224, 238, 255));
        table.setSelectionForeground(TEXT_DARK);
        table.setGridColor(new Color(241, 245, 249));
        table.setShowVerticalLines(false);

        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(new Color(237, 242, 250));
        th.setForeground(NAVY);
        th.setReorderingAllowed(false);
        th.setPreferredSize(new Dimension(0, 34));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void fetchFacultyInfo() {
        if (facultyEmail.isEmpty()) {
            String q = "SELECT email, faculty_name, faculty_id, department, designation FROM faculty LIMIT 1";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(q);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    facultyEmail = rs.getString("email");
                    facultyName = rs.getString("faculty_name");
                    facultyId = rs.getInt("faculty_id");
                    department = rs.getString("department");
                    designation = rs.getString("designation");
                }
            } catch (SQLException ignored) {}
            return;
        }

        String sql = "SELECT faculty_name, faculty_id, department, designation FROM faculty WHERE email = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, facultyEmail);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    facultyName = rs.getString("faculty_name");
                    facultyId = rs.getInt("faculty_id");
                    department = rs.getString("department");
                    designation = rs.getString("designation");
                }
            }
        } catch (SQLException ignored) {}
    }

    public void refreshDashboard() {
        loadFacultyMetrics();
        loadAssignedClasses();
    }

    private void loadAssignedClasses() {
        new Thread(() -> {
            java.util.List<Object[]> rows = new java.util.ArrayList<>();
            boolean hasEmail = !facultyEmail.isEmpty();

            String sql;
            if (hasEmail) {
                sql = "SELECT sa.allocation_id, COALESCE(e.subject_id, 'N/A') AS class_code, "
                    + "COALESCE(sub.subject_name, e.exam_name) AS class_name, "
                    + "sa.exam_id, e.exam_name, sa.duty_date, sa.session_time, sa.hall_number, sa.duty_role "
                    + "FROM staff_allocation sa "
                    + "JOIN exam e ON sa.exam_id = e.exam_id "
                    + "LEFT JOIN subject sub ON e.subject_id = sub.subject_id "
                    + "JOIN faculty f ON sa.faculty_id = f.faculty_id "
                    + "WHERE f.email = ? "
                    + "ORDER BY sa.duty_date, sa.session_time";
            } else {
                sql = "SELECT sa.allocation_id, COALESCE(e.subject_id, 'N/A') AS class_code, "
                    + "COALESCE(sub.subject_name, e.exam_name) AS class_name, "
                    + "sa.exam_id, e.exam_name, sa.duty_date, sa.session_time, sa.hall_number, sa.duty_role "
                    + "FROM staff_allocation sa "
                    + "JOIN exam e ON sa.exam_id = e.exam_id "
                    + "LEFT JOIN subject sub ON e.subject_id = sub.subject_id "
                    + "ORDER BY sa.duty_date, sa.session_time";
            }

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                if (hasEmail) {
                    ps.setString(1, facultyEmail);
                }

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        rows.add(new Object[]{
                            rs.getInt(1),
                            rs.getString(2),
                            rs.getString(3),
                            rs.getString(4),
                            rs.getString(5),
                            rs.getDate(6),
                            rs.getString(7),
                            rs.getString(8),
                            rs.getString(9)
                        });
                    }
                }
            } catch (SQLException ignored) {}

            SwingUtilities.invokeLater(() -> {
                assignedDutiesModel.setRowCount(0);
                for (Object[] row : rows) {
                    assignedDutiesModel.addRow(row);
                }
            });
        }).start();
    }

    private void loadFacultyMetrics() {
        new Thread(() -> {
            int duties = 0;
            int students = 0;
            int marks = 0;

            try (Connection con = DBConnection.getConnection()) {
                if (con != null) {
                    // Duties count
                    String s1 = "SELECT COUNT(*) FROM staff_allocation WHERE faculty_id = ?";
                    try (PreparedStatement ps = con.prepareStatement(s1)) {
                        ps.setInt(1, facultyId);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) duties = rs.getInt(1);
                        }
                    }

                    // Total students count
                    String s2 = "SELECT COUNT(*) FROM student";
                    try (PreparedStatement ps = con.prepareStatement(s2);
                         ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) students = rs.getInt(1);
                    }

                    // Total marks count
                    String s3 = "SELECT COUNT(*) FROM marks";
                    try (PreparedStatement ps = con.prepareStatement(s3);
                         ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) marks = rs.getInt(1);
                    }
                }
            } catch (SQLException ignored) {}

            final int fDuties = duties;
            final int fStudents = students;
            final int fMarks = marks;
            SwingUtilities.invokeLater(() -> {
                dutiesCountLbl.setText(String.valueOf(fDuties));
                studentsCountLbl.setText(String.valueOf(fStudents));
                marksCountLbl.setText(String.valueOf(fMarks));
            });
        }).start();
    }

    private void showAssignedDuties() {
        JDialog dlg = new JDialog(this, "My Assigned Examination Duties & Classes", true);
        dlg.setSize(1020, 520);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        String[] cols = {"Alloc ID", "Class Code", "Class / Subject Name", "Exam ID", "Exam Name", "Duty Date", "Session / Timings", "Hall", "Role"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = new JTable(m);
        styleTable(tbl);

        String sql;
        boolean hasEmail = !facultyEmail.isEmpty();

        if (hasEmail) {
            sql = "SELECT sa.allocation_id, COALESCE(e.subject_id, 'N/A') AS class_code, "
                + "COALESCE(sub.subject_name, e.exam_name) AS class_name, "
                + "sa.exam_id, e.exam_name, sa.duty_date, sa.session_time, sa.hall_number, sa.duty_role "
                + "FROM staff_allocation sa "
                + "JOIN exam e ON sa.exam_id = e.exam_id "
                + "LEFT JOIN subject sub ON e.subject_id = sub.subject_id "
                + "JOIN faculty f ON sa.faculty_id = f.faculty_id "
                + "WHERE f.email = ? "
                + "ORDER BY sa.duty_date, sa.session_time";
        } else {
            sql = "SELECT sa.allocation_id, COALESCE(e.subject_id, 'N/A') AS class_code, "
                + "COALESCE(sub.subject_name, e.exam_name) AS class_name, "
                + "sa.exam_id, e.exam_name, sa.duty_date, sa.session_time, sa.hall_number, sa.duty_role "
                + "FROM staff_allocation sa "
                + "JOIN exam e ON sa.exam_id = e.exam_id "
                + "LEFT JOIN subject sub ON e.subject_id = sub.subject_id "
                + "ORDER BY sa.duty_date, sa.session_time";
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (hasEmail) ps.setString(1, facultyEmail);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    m.addRow(new Object[]{
                        rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getDate(6),
                        rs.getString(7), rs.getString(8), rs.getString(9)
                    });
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dlg, "Error loading duties: " + ex.getMessage());
        }

        JPanel topPnl = new JPanel(new BorderLayout());
        topPnl.setBackground(NAVY);
        topPnl.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel titleLbl = new JLabel(hasEmail ? "Assigned Classes & Examination Duties: " + facultyName : "All Examination Duties");
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLbl.setForeground(Color.WHITE);
        topPnl.add(titleLbl, BorderLayout.WEST);

        dlg.add(topPnl, BorderLayout.NORTH);
        dlg.add(new JScrollPane(tbl), BorderLayout.CENTER);

        JButton closeBtn = new JButton("Close");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setBackground(PRIMARY_BLUE);
        closeBtn.setFocusPainted(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setPreferredSize(new Dimension(100, 32));
        closeBtn.addActionListener(e -> dlg.dispose());

        JPanel btm = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        btm.add(closeBtn);
        dlg.add(btm, BorderLayout.SOUTH);

        dlg.setVisible(true);
    }

    private void showStudentDetails() {
        JDialog dlg = new JDialog(this, "Student Details Directory", true);
        dlg.setSize(950, 500);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout(10, 10));

        String[] cols = {"Student ID", "Name", "Department", "Degree", "Year", "Email", "Phone", "Roll Number"};
        DefaultTableModel m = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = new JTable(m);
        styleTable(tbl);

        String sql = "SELECT student_id, student_name, department, degree, year, email, phone, roll_number FROM student ORDER BY department, year";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                m.addRow(new Object[]{
                    rs.getString(1), rs.getString(2), rs.getString(3),
                    rs.getString(4), "Year " + rs.getInt(5), rs.getString(6), rs.getString(7), rs.getString(8)
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(dlg, "Error loading student details: " + ex.getMessage());
        }

        JPanel topPnl = new JPanel(new BorderLayout());
        topPnl.setBackground(NAVY);
        topPnl.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel titleLbl = new JLabel("College Student Directory");
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLbl.setForeground(Color.WHITE);
        topPnl.add(titleLbl, BorderLayout.WEST);

        dlg.add(topPnl, BorderLayout.NORTH);
        dlg.add(new JScrollPane(tbl), BorderLayout.CENTER);

        JButton closeBtn = new JButton("Close");
        closeBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        closeBtn.setForeground(Color.WHITE);
        closeBtn.setBackground(PRIMARY_BLUE);
        closeBtn.setFocusPainted(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setPreferredSize(new Dimension(100, 32));
        closeBtn.addActionListener(e -> dlg.dispose());

        JPanel btm = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        btm.add(closeBtn);
        dlg.add(btm, BorderLayout.SOUTH);

        dlg.setVisible(true);
    }
}
