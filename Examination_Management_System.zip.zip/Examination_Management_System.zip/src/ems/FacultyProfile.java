package ems;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Modern, Professional Faculty Profile
 * Organized into four distinct cards: Personal, Contact, Professional, Account.
 * Completely self-contained with no external UI dependencies.
 */
public class FacultyProfile extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private String facultyEmail;
    private int currentFacultyId = -1;
    private boolean isEditing = false;

    // Section A: Personal Information
    private JTextField facultyIdField;
    private JTextField nameField;
    private JTextField dobField;
    private JComboBox<String> genderBox;

    // Section B: Contact Information
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField altPhoneField;
    private JTextArea addressArea;
    private JTextField cityField;
    private JTextField stateField;
    private JTextField pincodeField;

    // Section C: Professional Information
    private JTextField departmentField;
    private JComboBox<String> designationBox;
    private JComboBox<String> qualificationBox;
    private JTextField specializationField;
    private JTextField experienceField;
    private JTextField dateOfJoiningField;
    private JTextField employeeIdField;

    // Section D: Account Information
    private JTextField usernameField;
    private JTextField roleField;
    private JPasswordField passwordField;

    // Action Buttons
    private JButton editButton;
    private JButton updateButton;
    private JButton cancelButton;
    private JButton backButton;

    public FacultyProfile() {
        this("");
    }

    public FacultyProfile(String facultyEmail) {
        this.facultyEmail = (facultyEmail != null) ? facultyEmail.trim() : "";

        setTitle("Examination Management System - Faculty Profile");
        setSize(1000, 850);
        setMinimumSize(new Dimension(880, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "FACULTY INFORMATION PROFILE",
                "Official Academic Credentials & Staff Verification Record"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Scrollable content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(20, 30, 20, 30));

        // SECTION A: PERSONAL INFORMATION
        JPanel cardA = createCard("A. PERSONAL INFORMATION");
        JPanel gridA = new JPanel(new GridLayout(0, 2, 20, 12));
        gridA.setOpaque(false);

        facultyIdField = createTextField(false);
        nameField = createTextField(false);
        dobField = createTextField(false);
        genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderBox.setFont(FONT_INPUT);
        genderBox.setEnabled(false);

        addField(gridA, "Faculty System ID:", facultyIdField);
        addField(gridA, "Full Name:", nameField);
        addField(gridA, "Date of Birth (YYYY-MM-DD):", dobField);
        addField(gridA, "Gender:", genderBox);

        cardA.add(gridA, BorderLayout.CENTER);
        contentPanel.add(cardA);
        contentPanel.add(Box.createVerticalStrut(18));

        // SECTION B: CONTACT INFORMATION
        JPanel cardB = createCard("B. CONTACT INFORMATION");
        JPanel gridB = new JPanel(new GridLayout(0, 2, 20, 12));
        gridB.setOpaque(false);

        emailField = createTextField(false);
        phoneField = createTextField(false);
        altPhoneField = createTextField(false);

        addressArea = new JTextArea(3, 20);
        addressArea.setFont(FONT_INPUT);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        addressArea.setEditable(false);
        addressArea.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        addressArea.setBackground(new Color(248, 250, 252));
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addressScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        cityField = createTextField(false);
        stateField = createTextField(false);
        pincodeField = createTextField(false);

        addField(gridB, "Email Address:", emailField);
        addField(gridB, "Primary Phone Number:", phoneField);
        addField(gridB, "Alternative Phone Number:", altPhoneField);
        addField(gridB, "Residential Address:", addressScroll);
        addField(gridB, "City:", cityField);
        addField(gridB, "State:", stateField);
        addField(gridB, "Postal Pincode:", pincodeField);

        cardB.add(gridB, BorderLayout.CENTER);
        contentPanel.add(cardB);
        contentPanel.add(Box.createVerticalStrut(18));

        // SECTION C: PROFESSIONAL INFORMATION
        JPanel cardC = createCard("C. PROFESSIONAL INFORMATION");
        JPanel gridC = new JPanel(new GridLayout(0, 2, 20, 12));
        gridC.setOpaque(false);

        departmentField = createTextField(false);

        designationBox = new JComboBox<>(new String[]{
                "Professor", "Associate Professor", "Assistant Professor",
                "Lecturer", "Head of Department", "Dean", "Other"
        });
        designationBox.setFont(FONT_INPUT);
        designationBox.setEnabled(false);

        qualificationBox = new JComboBox<>(new String[]{
                "Ph.D.", "M.Tech / M.E.", "M.Sc.", "MCA", "B.Tech / B.E.", "Post-Doctorate", "Other"
        });
        qualificationBox.setFont(FONT_INPUT);
        qualificationBox.setEnabled(false);

        specializationField = createTextField(false);
        experienceField = createTextField(false);
        dateOfJoiningField = createTextField(false);
        employeeIdField = createTextField(false);

        addField(gridC, "Department / Faculty:", departmentField);
        addField(gridC, "Current Designation:", designationBox);
        addField(gridC, "Highest Qualification:", qualificationBox);
        addField(gridC, "Area of Specialization:", specializationField);
        addField(gridC, "Teaching Experience (Years):", experienceField);
        addField(gridC, "Date of Joining (YYYY-MM-DD):", dateOfJoiningField);
        addField(gridC, "Official Employee ID:", employeeIdField);

        cardC.add(gridC, BorderLayout.CENTER);
        contentPanel.add(cardC);
        contentPanel.add(Box.createVerticalStrut(18));

        // SECTION D: ACCOUNT INFORMATION
        JPanel cardD = createCard("D. ACCOUNT INFORMATION");
        JPanel gridD = new JPanel(new GridLayout(0, 2, 20, 12));
        gridD.setOpaque(false);

        usernameField = createTextField(false);
        roleField = createTextField(false);
        roleField.setText("Faculty");

        passwordField = new JPasswordField("••••••••");
        passwordField.setFont(FONT_INPUT);
        passwordField.setEditable(false);
        passwordField.setBackground(new Color(248, 250, 252));
        passwordField.setBorder(createFieldBorder());

        addField(gridD, "Account Username:", usernameField);
        addField(gridD, "System Role:", roleField);
        addField(gridD, "Account Password:", passwordField);

        cardD.add(gridD, BorderLayout.CENTER);
        contentPanel.add(cardD);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Action Buttons Bar
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 14));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR));

        backButton = createButton("Back", SECONDARY_GRAY, SECONDARY_HOVER);
        cancelButton = createButton("Cancel", new Color(148, 163, 184), new Color(100, 116, 139));
        editButton = createButton("Edit Profile", PRIMARY_BLUE, PRIMARY_HOVER);
        updateButton = createButton("Update Profile", SUCCESS_GREEN, SUCCESS_HOVER);

        cancelButton.setEnabled(false);
        updateButton.setEnabled(false);

        buttonPanel.add(backButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(editButton);
        buttonPanel.add(updateButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Listeners
        backButton.addActionListener(e -> dispose());
        editButton.addActionListener(e -> setEditMode(true));
        cancelButton.addActionListener(e -> {
            loadFacultyProfile();
            setEditMode(false);
        });
        updateButton.addActionListener(e -> saveUpdatedProfile());

        loadFacultyProfile();

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private Border createFieldBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        );
    }

    private JTextField createTextField(boolean editable) {
        JTextField tf = new JTextField();
        tf.setFont(FONT_INPUT);
        tf.setEditable(editable);
        tf.setBorder(createFieldBorder());
        if (!editable) {
            tf.setBackground(new Color(248, 250, 252));
            tf.setForeground(TEXT_DARK);
        }
        return tf;
    }

    private JPanel createCard(String title) {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(16, 22, 18, 22)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(FONT_HEADER);
        titleLbl.setForeground(PRIMARY_BLUE);

        card.add(titleLbl, BorderLayout.NORTH);
        return card;
    }

    private void addField(JPanel panel, String labelText, Component comp) {
        JPanel wrap = new JPanel(new BorderLayout(0, 4));
        wrap.setOpaque(false);

        JLabel lbl = new JLabel(labelText);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        wrap.add(lbl, BorderLayout.NORTH);
        wrap.add(comp, BorderLayout.CENTER);
        panel.add(wrap);
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(130, 36));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void setEditMode(boolean enable) {
        this.isEditing = enable;

        // Editable fields
        nameField.setEditable(enable);
        dobField.setEditable(enable);
        genderBox.setEnabled(enable);
        phoneField.setEditable(enable);
        altPhoneField.setEditable(enable);
        addressArea.setEditable(enable);
        cityField.setEditable(enable);
        stateField.setEditable(enable);
        pincodeField.setEditable(enable);

        designationBox.setEnabled(enable);
        qualificationBox.setEnabled(enable);
        specializationField.setEditable(enable);
        experienceField.setEditable(enable);
        dateOfJoiningField.setEditable(enable);
        employeeIdField.setEditable(enable);

        Color fieldBg = enable ? Color.WHITE : new Color(248, 250, 252);
        nameField.setBackground(fieldBg);
        dobField.setBackground(fieldBg);
        phoneField.setBackground(fieldBg);
        altPhoneField.setBackground(fieldBg);
        addressArea.setBackground(fieldBg);
        cityField.setBackground(fieldBg);
        stateField.setBackground(fieldBg);
        pincodeField.setBackground(fieldBg);
        specializationField.setBackground(fieldBg);
        experienceField.setBackground(fieldBg);
        dateOfJoiningField.setBackground(fieldBg);
        employeeIdField.setBackground(fieldBg);

        editButton.setEnabled(!enable);
        updateButton.setEnabled(enable);
        cancelButton.setEnabled(enable);
    }

    private void loadFacultyProfile() {
        if (facultyEmail.isEmpty()) {
            String queryFirst = "SELECT email FROM faculty LIMIT 1";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(queryFirst);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    facultyEmail = rs.getString("email");
                }
            } catch (SQLException ignored) {}
        }

        String sql = "SELECT * FROM faculty WHERE email = ? OR employee_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, facultyEmail);
            ps.setString(2, facultyEmail);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    currentFacultyId = rs.getInt("faculty_id");
                    facultyIdField.setText("FAC" + String.format("%03d", currentFacultyId));
                    nameField.setText(rs.getString("faculty_name"));

                    java.sql.Date dob = rs.getDate("dob");
                    dobField.setText(dob != null ? dob.toString() : "");

                    String gender = rs.getString("gender");
                    if (gender != null) genderBox.setSelectedItem(gender);

                    emailField.setText(rs.getString("email"));
                    phoneField.setText(rs.getString("phone"));
                    altPhoneField.setText(rs.getString("alt_phone"));
                    addressArea.setText(rs.getString("address"));
                    cityField.setText(rs.getString("city"));
                    stateField.setText(rs.getString("state"));
                    pincodeField.setText(rs.getString("pincode"));

                    departmentField.setText(rs.getString("department"));

                    String desig = rs.getString("designation");
                    if (desig != null) designationBox.setSelectedItem(desig);

                    String qual = rs.getString("qualification");
                    if (qual != null) qualificationBox.setSelectedItem(qual);

                    specializationField.setText(rs.getString("specialization"));
                    experienceField.setText(String.valueOf(rs.getInt("experience")));

                    java.sql.Date doj = rs.getDate("date_of_joining");
                    dateOfJoiningField.setText(doj != null ? doj.toString() : "");

                    employeeIdField.setText(rs.getString("employee_id"));
                }
            }

            // Load username from users table
            String userSql = "SELECT username FROM users WHERE email = ?";
            try (PreparedStatement ps2 = con.prepareStatement(userSql)) {
                ps2.setString(1, emailField.getText().trim());
                try (ResultSet rs2 = ps2.executeQuery()) {
                    if (rs2.next()) {
                        usernameField.setText(rs2.getString("username"));
                    }
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Failed to load faculty profile: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveUpdatedProfile() {
        String name = nameField.getText().trim();
        String dob = dobField.getText().trim();
        String gender = (String) genderBox.getSelectedItem();
        String phone = phoneField.getText().trim();
        String altPhone = altPhoneField.getText().trim();
        String address = addressArea.getText().trim();
        String city = cityField.getText().trim();
        String state = stateField.getText().trim();
        String pincode = pincodeField.getText().trim();

        String designation = (String) designationBox.getSelectedItem();
        String qualification = (String) qualificationBox.getSelectedItem();
        String specialization = specializationField.getText().trim();
        String expStr = experienceField.getText().trim();
        String doj = dateOfJoiningField.getText().trim();
        String empId = employeeIdField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || empId.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Name, Phone, and Employee ID cannot be empty.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!phone.matches("^\\d{10}$")) {
            JOptionPane.showMessageDialog(this,
                    "Phone number must be exactly 10 digits.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int exp = 0;
        try {
            exp = Integer.parseInt(expStr);
        } catch (Exception ignored) {}

        String sql = "UPDATE faculty SET faculty_name = ?, dob = ?, gender = ?, "
                + "phone = ?, alt_phone = ?, address = ?, city = ?, state = ?, pincode = ?, "
                + "designation = ?, qualification = ?, specialization = ?, experience = ?, "
                + "date_of_joining = ?, employee_id = ? "
                + "WHERE faculty_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            if (!dob.isEmpty()) {
                ps.setDate(2, java.sql.Date.valueOf(dob));
            } else {
                ps.setNull(2, java.sql.Types.DATE);
            }
            ps.setString(3, gender);
            ps.setString(4, phone);
            ps.setString(5, altPhone);
            ps.setString(6, address);
            ps.setString(7, city);
            ps.setString(8, state);
            ps.setString(9, pincode);
            ps.setString(10, designation);
            ps.setString(11, qualification);
            ps.setString(12, specialization);
            ps.setInt(13, exp);
            if (!doj.isEmpty()) {
                ps.setDate(14, java.sql.Date.valueOf(doj));
            } else {
                ps.setNull(14, java.sql.Types.DATE);
            }
            ps.setString(15, empId);
            ps.setInt(16, currentFacultyId);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                JOptionPane.showMessageDialog(this,
                        "Faculty Profile Updated Successfully!",
                        "Profile Update", JOptionPane.INFORMATION_MESSAGE);
                setEditMode(false);
                loadFacultyProfile();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Could not update profile. Record not found.",
                        "Update Failed", JOptionPane.WARNING_MESSAGE);
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    "Invalid date format. Please use YYYY-MM-DD.",
                    "Date Format Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Database update error: " + e.getMessage(),
                    "System Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
