package ems;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Modern, Professional Faculty Registration Form
 * Completely self-contained with no external UI dependencies.
 * Saves complete Personal, Professional, and Account details into MySQL.
 */
public class FacultyRegistration extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    // Personal Details
    private JTextField facultyIdField;
    private JTextField nameField;
    private JTextField dobField;
    private JRadioButton maleRadio, femaleRadio, otherRadio;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField altPhoneField;
    private JTextArea addressArea;
    private JTextField cityField;
    private JTextField stateField;
    private JTextField pincodeField;

    // Professional Details
    private JComboBox<String> departmentBox;
    private JComboBox<String> designationBox;
    private JComboBox<String> qualificationBox;
    private JTextField specializationField;
    private JTextField experienceField;
    private JTextField dateOfJoiningField;
    private JTextField employeeIdField;

    // Account Details
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JCheckBox showPasswordCheck;
    private JCheckBox declarationCheck;

    public FacultyRegistration() {
        setTitle("Examination Management System - Faculty Registration");
        setSize(920, 850);
        setMinimumSize(new Dimension(850, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header Banner
        JPanel header = createHeader(
                "COLLEGE EXAMINATION MANAGEMENT SYSTEM",
                "Official Faculty & Staff Registration Portal"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Form Container inside ScrollPane
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setBackground(BG_LIGHT);
        formContainer.setBorder(new EmptyBorder(20, 30, 20, 30));

        // 1. PERSONAL DETAILS CARD
        JPanel personalCard = createSectionCard("A. PERSONAL DETAILS");
        JPanel personalGrid = new JPanel(new GridLayout(0, 2, 18, 12));
        personalGrid.setOpaque(false);

        facultyIdField = createTextField(false);
        nameField = createTextField(true);
        dobField = createTextField(true);
        dobField.setToolTipText("Format: YYYY-MM-DD");

        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        genderPanel.setOpaque(false);
        maleRadio = new JRadioButton("Male");
        femaleRadio = new JRadioButton("Female");
        otherRadio = new JRadioButton("Other");
        maleRadio.setFont(FONT_INPUT);
        femaleRadio.setFont(FONT_INPUT);
        otherRadio.setFont(FONT_INPUT);
        maleRadio.setOpaque(false);
        femaleRadio.setOpaque(false);
        otherRadio.setOpaque(false);
        ButtonGroup bg = new ButtonGroup();
        bg.add(maleRadio);
        bg.add(femaleRadio);
        bg.add(otherRadio);
        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        genderPanel.add(otherRadio);

        emailField = createTextField(true);
        phoneField = createTextField(true);
        altPhoneField = createTextField(true);

        addressArea = new JTextArea(3, 20);
        addressArea.setFont(FONT_INPUT);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        addressArea.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addressScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        cityField = createTextField(true);
        stateField = createTextField(true);
        pincodeField = createTextField(true);

        addFormField(personalGrid, "Faculty ID (Auto):", facultyIdField);
        addFormField(personalGrid, "Full Name *:", nameField);
        addFormField(personalGrid, "Date of Birth (YYYY-MM-DD) *:", dobField);
        addFormField(personalGrid, "Gender *:", genderPanel);
        addFormField(personalGrid, "Email Address *:", emailField);
        addFormField(personalGrid, "Phone Number (10 digits) *:", phoneField);
        addFormField(personalGrid, "Alternative Phone:", altPhoneField);
        addFormField(personalGrid, "Residential Address *:", addressScroll);
        addFormField(personalGrid, "City *:", cityField);
        addFormField(personalGrid, "State *:", stateField);
        addFormField(personalGrid, "Pincode *:", pincodeField);

        personalCard.add(personalGrid, BorderLayout.CENTER);
        formContainer.add(personalCard);
        formContainer.add(Box.createVerticalStrut(18));

        // 2. PROFESSIONAL DETAILS CARD
        JPanel profCard = createSectionCard("B. PROFESSIONAL DETAILS");
        JPanel profGrid = new JPanel(new GridLayout(0, 2, 18, 12));
        profGrid.setOpaque(false);

        departmentBox = new JComboBox<>(loadDepartments());
        departmentBox.setFont(FONT_INPUT);

        designationBox = new JComboBox<>(new String[]{
                "Select Designation", "Professor", "Associate Professor", "Assistant Professor",
                "Lecturer", "Head of Department", "Dean"
        });
        designationBox.setFont(FONT_INPUT);

        qualificationBox = new JComboBox<>(new String[]{
                "Select Qualification", "Ph.D.", "M.Tech / M.E.", "M.Sc.", "MCA",
                "B.Tech / B.E.", "Post-Doctorate", "Other"
        });
        qualificationBox.setFont(FONT_INPUT);

        specializationField = createTextField(true);
        experienceField = createTextField(true);
        experienceField.setToolTipText("Experience in years (e.g. 5)");

        dateOfJoiningField = createTextField(true);
        dateOfJoiningField.setToolTipText("Format: YYYY-MM-DD");

        employeeIdField = createTextField(true);
        employeeIdField.setToolTipText("e.g. EMP-101");

        addFormField(profGrid, "Department *:", departmentBox);
        addFormField(profGrid, "Designation *:", designationBox);
        addFormField(profGrid, "Highest Qualification *:", qualificationBox);
        addFormField(profGrid, "Specialization / Research Area *:", specializationField);
        addFormField(profGrid, "Experience in Years *:", experienceField);
        addFormField(profGrid, "Date of Joining (YYYY-MM-DD) *:", dateOfJoiningField);
        addFormField(profGrid, "Official Employee ID *:", employeeIdField);

        profCard.add(profGrid, BorderLayout.CENTER);
        formContainer.add(profCard);
        formContainer.add(Box.createVerticalStrut(18));

        // 3. ACCOUNT CREDENTIALS CARD
        JPanel accountCard = createSectionCard("C. ACCOUNT CREDENTIALS");
        JPanel accountGrid = new JPanel(new GridLayout(0, 2, 18, 12));
        accountGrid.setOpaque(false);

        usernameField = createTextField(true);
        passwordField = new JPasswordField();
        passwordField.setFont(FONT_INPUT);
        passwordField.setBorder(createFieldBorder());

        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setFont(FONT_INPUT);
        confirmPasswordField.setBorder(createFieldBorder());

        showPasswordCheck = new JCheckBox("Show Password");
        showPasswordCheck.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        showPasswordCheck.setOpaque(false);
        showPasswordCheck.addActionListener(e -> {
            char echo = showPasswordCheck.isSelected() ? (char) 0 : '•';
            passwordField.setEchoChar(echo);
            confirmPasswordField.setEchoChar(echo);
        });

        declarationCheck = new JCheckBox(
                "I confirm that all provided faculty credentials and qualifications are authentic."
        );
        declarationCheck.setFont(new Font("Segoe UI", Font.BOLD, 12));
        declarationCheck.setForeground(NAVY);
        declarationCheck.setOpaque(false);

        addFormField(accountGrid, "Account Username *:", usernameField);
        addFormField(accountGrid, "Account Password *:", passwordField);
        addFormField(accountGrid, "Confirm Password *:", confirmPasswordField);
        addFormField(accountGrid, "", showPasswordCheck);

        JPanel accountWrap = new JPanel(new BorderLayout(0, 10));
        accountWrap.setOpaque(false);
        accountWrap.add(accountGrid, BorderLayout.CENTER);
        accountWrap.add(declarationCheck, BorderLayout.SOUTH);

        accountCard.add(accountWrap, BorderLayout.CENTER);
        formContainer.add(accountCard);

        JScrollPane scrollPane = new JScrollPane(formContainer);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // 4. ACTION BUTTONS PANEL
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR));

        JButton registerButton = createButton("Register Faculty", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton clearButton = createButton("Clear Form", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backButton = createButton("Back to Login", new Color(71, 85, 105), new Color(51, 65, 85));

        registerButton.setPreferredSize(new Dimension(160, 38));
        clearButton.setPreferredSize(new Dimension(130, 38));
        backButton.setPreferredSize(new Dimension(140, 38));

        buttonPanel.add(backButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(registerButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Listeners
        registerButton.addActionListener(e -> validateAndRegister());
        clearButton.addActionListener(e -> clearForm());
        backButton.addActionListener(e -> {
            new Login().setVisible(true);
            dispose();
        });

        generateFacultyId();

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private Border createFieldBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        );
    }

    private JTextField createTextField(boolean editable) {
        JTextField tf = new JTextField();
        tf.setFont(FONT_INPUT);
        tf.setEditable(editable);
        tf.setBorder(createFieldBorder());
        if (!editable) {
            tf.setBackground(new Color(241, 245, 249));
            tf.setForeground(TEXT_MUTED);
        }
        return tf;
    }

    private JPanel createSectionCard(String title) {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(16, 20, 18, 20)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(FONT_HEADER);
        titleLbl.setForeground(PRIMARY_BLUE);

        card.add(titleLbl, BorderLayout.NORTH);
        return card;
    }

    private void addFormField(JPanel panel, String labelText, Component field) {
        JPanel group = new JPanel(new BorderLayout(0, 4));
        group.setOpaque(false);

        JLabel label = new JLabel(labelText);
        label.setFont(FONT_LABEL);
        label.setForeground(TEXT_DARK);

        group.add(label, BorderLayout.NORTH);
        group.add(field, BorderLayout.CENTER);
        panel.add(group);
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(bg);
            }
        });
        return btn;
    }

    private String[] loadDepartments() {
        List<String> list = new ArrayList<>();
        list.add("Select Department");
        String sql = "SELECT department_name FROM department ORDER BY department_name ASC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(rs.getString("department_name"));
            }
        } catch (Exception ignored) {}
        if (list.size() <= 1) {
            list.add("Computer Science and Engineering");
            list.add("Information Technology");
            list.add("Electronics and Communication Engineering");
            list.add("Electrical and Electronics Engineering");
            list.add("Mechanical Engineering");
            list.add("Civil Engineering");
        }
        return list.toArray(new String[0]);
    }

    private void generateFacultyId() {
        String sql = "SELECT MAX(faculty_id) FROM faculty";
        int nextId = 1;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                nextId = rs.getInt(1) + 1;
            }
        } catch (SQLException ignored) {}
        facultyIdField.setText(String.format("FAC%03d", nextId));
    }

    private void validateAndRegister() {
        String fullName = nameField.getText().trim();
        String dob = dobField.getText().trim();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String altPhone = altPhoneField.getText().trim();
        String address = addressArea.getText().trim();
        String city = cityField.getText().trim();
        String state = stateField.getText().trim();
        String pincode = pincodeField.getText().trim();

        String department = (String) departmentBox.getSelectedItem();
        String designation = (String) designationBox.getSelectedItem();
        String qualification = (String) qualificationBox.getSelectedItem();
        String specialization = specializationField.getText().trim();
        String experienceStr = experienceField.getText().trim();
        String dateOfJoining = dateOfJoiningField.getText().trim();
        String employeeId = employeeIdField.getText().trim();

        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        // 1. Mandatory Fields Validation
        if (fullName.isEmpty() || dob.isEmpty() || email.isEmpty() || phone.isEmpty()
                || address.isEmpty() || city.isEmpty() || state.isEmpty() || pincode.isEmpty()
                || specialization.isEmpty() || experienceStr.isEmpty()
                || dateOfJoining.isEmpty() || employeeId.isEmpty()
                || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fill in all mandatory fields.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Gender Check
        String gender = "";
        if (maleRadio.isSelected()) gender = "Male";
        else if (femaleRadio.isSelected()) gender = "Female";
        else if (otherRadio.isSelected()) gender = "Other";
        else {
            JOptionPane.showMessageDialog(this, "Please select a Gender.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Dropdowns Check
        if (department == null || department.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select a Department.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (designation == null || designation.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select a Designation.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (qualification == null || qualification.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select a Qualification.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Date formats (DD-MM-YYYY)
        if (!dob.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            JOptionPane.showMessageDialog(this,
                    "Date of Birth must be in YYYY-MM-DD format (e.g. 1989-06-20).",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!dateOfJoining.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            JOptionPane.showMessageDialog(this,
                    "Date of Joining must be in YYYY-MM-DD format (e.g. 2020-08-01).",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Email validation
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid email address.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Phone validation (10 digits)
        if (!phone.matches("^\\d{10}$")) {
            JOptionPane.showMessageDialog(this,
                    "Phone number must be exactly 10 digits.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!altPhone.isEmpty() && !altPhone.matches("^\\d{10}$")) {
            JOptionPane.showMessageDialog(this,
                    "Alternative phone number must be 10 digits if provided.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Experience validation (number)
        int experience = 0;
        try {
            experience = Integer.parseInt(experienceStr);
            if (experience < 0 || experience > 60) {
                JOptionPane.showMessageDialog(this, "Please enter a valid experience between 0 and 60 years.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Experience must be a whole number of years.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Password strength: >= 8 chars, 1 uppercase, 1 lowercase, 1 digit, 1 special character
        if (password.length() < 8
                || !password.matches(".*[A-Z].*")
                || !password.matches(".*[a-z].*")
                || !password.matches(".*\\d.*")
                || !password.matches(".*[^A-Za-z0-9].*")) {
            JOptionPane.showMessageDialog(this,
                    "Password does not meet strength requirements:\n"
                            + "• Minimum 8 characters\n"
                            + "• At least one uppercase letter (A-Z)\n"
                            + "• At least one lowercase letter (a-z)\n"
                            + "• At least one numeric digit (0-9)\n"
                            + "• At least one special character (!@#$%^&*...)",
                    "Password Requirements", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Password confirmation
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                    "Password and Confirm Password do not match.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Declaration check
        if (!declarationCheck.isSelected()) {
            JOptionPane.showMessageDialog(this,
                    "Please check the declaration box to confirm your credentials.",
                    "Declaration Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Duplicate Checks: email, username, employee_id
        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Database connection unavailable.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check email in users
            String checkEmailSQL = "SELECT email FROM users WHERE email = ?";
            try (PreparedStatement ps = con.prepareStatement(checkEmailSQL)) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this,
                                "An account with email '" + email + "' already exists.",
                                "Duplicate Record", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // Check username in users
            String checkUserSQL = "SELECT username FROM users WHERE username = ?";
            try (PreparedStatement ps = con.prepareStatement(checkUserSQL)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this,
                                "Username '" + username + "' is already taken. Please choose another.",
                                "Duplicate Record", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // Check employee_id in faculty
            String checkEmpSQL = "SELECT employee_id FROM faculty WHERE employee_id = ?";
            try (PreparedStatement ps = con.prepareStatement(checkEmpSQL)) {
                ps.setString(1, employeeId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this,
                                "Employee ID '" + employeeId + "' is already registered to another faculty member.",
                                "Duplicate Employee ID", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // 3. Insert in Transaction: faculty and users tables
            con.setAutoCommit(false);

            String insertFacultySQL =
                    "INSERT INTO faculty "
                    + "(faculty_name, department, email, phone, address, gender, designation, "
                    + "qualification, specialization, experience, employee_id, dob, alt_phone, "
                    + "city, state, pincode, date_of_joining) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            String insertUserSQL =
                    "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, 'Faculty')";

            try {
                try (PreparedStatement ps = con.prepareStatement(insertFacultySQL)) {
                    ps.setString(1, fullName);
                    ps.setString(2, department);
                    ps.setString(3, email);
                    ps.setString(4, phone);
                    ps.setString(5, address);
                    ps.setString(6, gender);
                    ps.setString(7, designation);
                    ps.setString(8, qualification);
                    ps.setString(9, specialization);
                    ps.setInt(10, experience);
                    ps.setString(11, employeeId);
                    ps.setDate(12, java.sql.Date.valueOf(dob));
                    ps.setString(13, altPhone);
                    ps.setString(14, city);
                    ps.setString(15, state);
                    ps.setString(16, pincode);
                    ps.setDate(17, java.sql.Date.valueOf(dateOfJoining));
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = con.prepareStatement(insertUserSQL)) {
                    ps.setString(1, username);
                    ps.setString(2, email);
                    ps.setString(3, hashPassword(password));
                    ps.executeUpdate();
                }

                con.commit();

                JOptionPane.showMessageDialog(this,
                        "Faculty Registration Successful!\n\n"
                                + "Employee ID: " + employeeId + "\n"
                                + "Faculty Name: " + fullName + "\n"
                                + "Username: " + username + "\n"
                                + "Email: " + email + "\n\n"
                                + "You can now login with your credentials.",
                        "Registration Completed", JOptionPane.INFORMATION_MESSAGE);

                clearForm();
                new Login().setVisible(true);
                dispose();

            } catch (SQLException ex) {
                con.rollback();
                JOptionPane.showMessageDialog(this,
                        "Registration failed during database save: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Database connection error: " + e.getMessage(),
                    "System Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        nameField.setText("");
        dobField.setText("");
        maleRadio.setSelected(false);
        femaleRadio.setSelected(false);
        otherRadio.setSelected(false);
        emailField.setText("");
        phoneField.setText("");
        altPhoneField.setText("");
        addressArea.setText("");
        cityField.setText("");
        stateField.setText("");
        pincodeField.setText("");

        departmentBox.setSelectedIndex(0);
        designationBox.setSelectedIndex(0);
        qualificationBox.setSelectedIndex(0);
        specializationField.setText("");
        experienceField.setText("");
        dateOfJoiningField.setText("");
        employeeIdField.setText("");

        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        showPasswordCheck.setSelected(false);
        declarationCheck.setSelected(false);

        passwordField.setEchoChar('•');
        confirmPasswordField.setEchoChar('•');
        generateFacultyId();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : hash) {
                result.append(String.format("%02x", b));
            }
            return result.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
