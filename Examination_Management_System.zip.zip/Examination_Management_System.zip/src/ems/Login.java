package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.GeneralPath;
import java.awt.geom.RoundRectangle2D;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Modern, Attractive, Professional Login & Welcome Window
 * College Examination Management System (EMS)
 * 
 * Features:
 * - Sophisticated academic theme with royal sapphire gradient & clean ivory canvas
 * - Custom anti-aliased educational visual artwork (Open Book of Knowledge, Graduation Cap, Verification Seal)
 * - Compact, sleek login card with smooth rounded borders and soft drop-shadow
 * - Full preservation of MySQL SHA-256 authentication and role-based navigation
 */
public class Login extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Color Palette
    private static final Color BRAND_NAVY = new Color(15, 30, 65);        // #0F1E41
    private static final Color BRAND_BLUE = new Color(26, 68, 148);       // #1A4494
    private static final Color ACCENT_ROYAL = new Color(37, 99, 235);     // #2563EB
    private static final Color ACCENT_HOVER = new Color(29, 78, 216);     // #1D4ED8
    private static final Color ACCENT_CYAN = new Color(56, 189, 248);     // #38BDF8
    private static final Color ACCENT_GOLD = new Color(245, 158, 11);     // #F59E0B
    private static final Color BG_CANVAS = new Color(245, 247, 251);      // #F5F7FB
    private static final Color CARD_BG = Color.WHITE;
    private static final Color BORDER_LIGHT = new Color(226, 232, 240);   // #E2E8F0
    private static final Color BORDER_FOCUS = new Color(59, 130, 246);    // #3B82F6
    private static final Color TEXT_PRIMARY = new Color(15, 23, 42);      // #0F172A
    private static final Color TEXT_MUTED = new Color(100, 116, 139);     // #64748B
    private static final Color TEXT_LIGHT = new Color(241, 245, 249);     // #F1F5F9

    // Typography
    private static final Font FONT_BRAND_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_BRAND_SUB = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_CARD_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_CARD_SUB = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_FIELD_LABEL = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 14);

    // Controls
    private JTextField userIdField;
    private JPasswordField passwordField;
    private JComboBox<String> roleBox;

    public Login() {
        setTitle("Examination Management System - Secure Portal Login");
        setSize(1000, 620);
        setMinimumSize(new Dimension(940, 580));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main split-screen panel
        JPanel mainContainer = new JPanel(new GridLayout(1, 2, 0, 0));
        mainContainer.setBackground(BG_CANVAS);

        // Left: Clean, Elegant Visual & Welcome Showcase
        JPanel leftShowcase = createWelcomeShowcase();
        mainContainer.add(leftShowcase);

        // Right: Compact, Modern Login Card Container
        JPanel rightLogin = createLoginFormPanel();
        mainContainer.add(rightLogin);

        setContentPane(mainContainer);
        setVisible(true);
    }

    
    private JPanel createWelcomeShowcase() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Refined royal navy-sapphire gradient
                GradientPaint bgGrad = new GradientPaint(
                        0, 0, BRAND_NAVY,
                        w, h, BRAND_BLUE
                );
                g2.setPaint(bgGrad);
                g2.fillRect(0, 0, w, h);

                // Subtle modern architectural geometric curves
                g2.setColor(new Color(255, 255, 255, 10));
                g2.fillOval(w - 180, -80, 320, 320);
                g2.fillOval(-80, h - 220, 340, 340);

                g2.setColor(new Color(56, 189, 248, 18));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawOval(w - 220, -120, 400, 400);

                // Subtle ambient dots pattern
                g2.setColor(new Color(255, 255, 255, 14));
                for (int x = 35; x < w - 20; x += 32) {
                    for (int y = 35; y < h - 20; y += 32) {
                        g2.fillOval(x, y, 2, 2);
                    }
                }

                g2.dispose();
            }
        };

        panel.setLayout(new BorderLayout());
        panel.setBorder(new EmptyBorder(38, 45, 34, 45));

        // Header Section
        JPanel headerPanel = new JPanel();
        headerPanel.setOpaque(false);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));

        // Institution Pill Badge
        JLabel badge = new JLabel("  OFFICIAL ACADEMIC PORTAL  ");
        badge.setOpaque(true);
        badge.setBackground(new Color(37, 99, 235, 180));
        badge.setForeground(Color.WHITE);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badge.setBorder(new EmptyBorder(5, 10, 5, 10));
        badge.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel titleLbl = new JLabel("<html>EXAMINATION<br>MANAGEMENT SYSTEM</html>");
        titleLbl.setFont(FONT_BRAND_TITLE);
        titleLbl.setForeground(Color.WHITE);
        titleLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subLbl = new JLabel("<html>Centralized institutional platform for verified examination schedules, candidate seating, roll numbers, and academic grade evaluations.</html>");
        subLbl.setFont(FONT_BRAND_SUB);
        subLbl.setForeground(new Color(203, 213, 225));
        subLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        headerPanel.add(badge);
        headerPanel.add(Box.createVerticalStrut(14));
        headerPanel.add(titleLbl);
        headerPanel.add(Box.createVerticalStrut(10));
        headerPanel.add(subLbl);

        panel.add(headerPanel, BorderLayout.NORTH);

        // Center Education & Examination Illustration
        EducationVisualGraphic visual = new EducationVisualGraphic();
        panel.add(visual, BorderLayout.CENTER);

        // Bottom Trust & Feature Highlights
        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));

        bottomPanel.add(createBadgeItem("Unified Student & Faculty Portals"));
        bottomPanel.add(Box.createVerticalStrut(6));
        bottomPanel.add(createBadgeItem("Automated Exam Registration & Seating"));
        bottomPanel.add(Box.createVerticalStrut(6));
        bottomPanel.add(createBadgeItem("Cryptographically Secure Authentication"));
        bottomPanel.add(Box.createVerticalStrut(14));

        JLabel sessionLbl = new JLabel("Office of Academic Examinations • Session 2026-2027");
        sessionLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sessionLbl.setForeground(new Color(148, 163, 184));
        sessionLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        bottomPanel.add(sessionLbl);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createBadgeItem(String text) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        p.setOpaque(false);
        p.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel check = new JLabel("✓");
        check.setFont(new Font("Segoe UI", Font.BOLD, 13));
        check.setForeground(ACCENT_CYAN);

        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        label.setForeground(TEXT_LIGHT);

        p.add(check);
        p.add(label);
        return p;
    }

    /**
     * Builds the right-side compact, modern login form.
     */
    private JPanel createLoginFormPanel() {
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_CANVAS);

        // Compact Modern Card with subtle curved shadow
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth();
                int h = getHeight();

                // Soft shadow
                g2.setColor(new Color(0, 0, 0, 15));
                g2.fillRoundRect(2, 2, w - 4, h - 4, 16, 16);

                // Card surface
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, w - 4, h - 4, 16, 16);

                // Border
                g2.setColor(BORDER_LIGHT);
                g2.setStroke(new BasicStroke(1.0f));
                g2.drawRoundRect(0, 0, w - 5, h - 5, 16, 16);

                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(410, 500));
        card.setBorder(new EmptyBorder(26, 32, 24, 32));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 4, 5, 4);

        // Form Title
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        JLabel formTitle = new JLabel("Portal Sign In");
        formTitle.setFont(FONT_CARD_TITLE);
        formTitle.setForeground(TEXT_PRIMARY);
        card.add(formTitle, gbc);

        gbc.gridy = 1;
        JLabel formSub = new JLabel("Enter your academic credentials to access your portal.");
        formSub.setFont(FONT_CARD_SUB);
        formSub.setForeground(TEXT_MUTED);
        card.add(formSub, gbc);

        // Divider
        gbc.gridy = 2;
        gbc.insets = new Insets(8, 4, 12, 4);
        JSeparator sep = new JSeparator();
        sep.setForeground(BORDER_LIGHT);
        card.add(sep, gbc);

        // User ID / Email Field
        gbc.gridy = 3;
        gbc.insets = new Insets(3, 4, 2, 4);
        JLabel userLbl = new JLabel("User ID or Registered Email");
        userLbl.setFont(FONT_FIELD_LABEL);
        userLbl.setForeground(TEXT_PRIMARY);
        card.add(userLbl, gbc);

        gbc.gridy = 4;
        gbc.insets = new Insets(2, 4, 8, 4);
        userIdField = createStyledTextField();
        card.add(userIdField, gbc);

        // Password Field
        gbc.gridy = 5;
        gbc.insets = new Insets(3, 4, 2, 4);
        JLabel passLbl = new JLabel("Password");
        passLbl.setFont(FONT_FIELD_LABEL);
        passLbl.setForeground(TEXT_PRIMARY);
        card.add(passLbl, gbc);

        gbc.gridy = 6;
        gbc.insets = new Insets(2, 4, 3, 4);
        passwordField = createStyledPasswordField();
        card.add(passwordField, gbc);

        // Show Password Toggle
        gbc.gridy = 7;
        gbc.insets = new Insets(0, 4, 6, 4);
        JCheckBox showPass = new JCheckBox("Show Password");
        showPass.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        showPass.setForeground(TEXT_MUTED);
        showPass.setOpaque(false);
        showPass.setFocusPainted(false);
        showPass.addActionListener(e -> passwordField.setEchoChar(showPass.isSelected() ? (char) 0 : '•'));
        card.add(showPass, gbc);

        // Role Selector
        gbc.gridy = 8;
        gbc.insets = new Insets(3, 4, 2, 4);
        JLabel roleLbl = new JLabel("Portal Role");
        roleLbl.setFont(FONT_FIELD_LABEL);
        roleLbl.setForeground(TEXT_PRIMARY);
        card.add(roleLbl, gbc);

        gbc.gridy = 9;
        gbc.insets = new Insets(2, 4, 14, 4);
        roleBox = new JComboBox<>(new String[]{"Student", "Faculty", "Admin"});
        roleBox.setFont(FONT_INPUT);
        roleBox.setPreferredSize(new Dimension(330, 38));
        roleBox.setBackground(Color.WHITE);
        card.add(roleBox, gbc);

        // Sign In Button
        gbc.gridy = 10;
        gbc.insets = new Insets(4, 4, 10, 4);
        JButton loginBtn = createPrimaryButton("Sign In to Portal →");
        loginBtn.setPreferredSize(new Dimension(330, 42));
        card.add(loginBtn, gbc);

        // Secondary Links: Registration & Forgot Password
        gbc.gridy = 11;
        gbc.insets = new Insets(6, 4, 2, 4);
        JPanel linksPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        linksPanel.setOpaque(false);

        JButton regBtn = new JButton("Register New Account");
        regBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        regBtn.setForeground(ACCENT_ROYAL);
        regBtn.setContentAreaFilled(false);
        regBtn.setBorderPainted(false);
        regBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JButton forgotBtn = new JButton("Forgot Password?");
        forgotBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        forgotBtn.setForeground(TEXT_MUTED);
        forgotBtn.setContentAreaFilled(false);
        forgotBtn.setBorderPainted(false);
        forgotBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        linksPanel.add(regBtn);
        linksPanel.add(new JLabel("•"));
        linksPanel.add(forgotBtn);
        card.add(linksPanel, gbc);

        wrapper.add(card);

        // Event Handlers
        loginBtn.addActionListener(e -> executeLogin());
        passwordField.addActionListener(e -> executeLogin());
        userIdField.addActionListener(e -> executeLogin());

        regBtn.addActionListener(e -> {
            String[] options = {"Student Registration", "Faculty Registration", "Cancel"};
            int choice = JOptionPane.showOptionDialog(
                    this,
                    "Select account registration type:",
                    "Account Registration",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (choice == 0) {
                new StudentRegistration();
                dispose();
            } else if (choice == 1) {
                new FacultyRegistration();
                dispose();
            }
        });

        forgotBtn.addActionListener(e -> {
            new ForgotPassword();
            dispose();
        });

        return wrapper;
    }

    private JTextField createStyledTextField() {
        JTextField tf = new JTextField();
        tf.setFont(FONT_INPUT);
        tf.setPreferredSize(new Dimension(330, 38));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_LIGHT, 1),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        tf.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_FOCUS, 1),
                        BorderFactory.createEmptyBorder(6, 12, 6, 12)
                ));
            }
            @Override
            public void focusLost(FocusEvent e) {
                tf.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_LIGHT, 1),
                        BorderFactory.createEmptyBorder(6, 12, 6, 12)
                ));
            }
        });
        return tf;
    }

    private JPasswordField createStyledPasswordField() {
        JPasswordField pf = new JPasswordField();
        pf.setFont(FONT_INPUT);
        pf.setPreferredSize(new Dimension(330, 38));
        pf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_LIGHT, 1),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        pf.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                pf.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_FOCUS, 1),
                        BorderFactory.createEmptyBorder(6, 12, 6, 12)
                ));
            }
            @Override
            public void focusLost(FocusEvent e) {
                pf.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_LIGHT, 1),
                        BorderFactory.createEmptyBorder(6, 12, 6, 12)
                ));
            }
        });
        return pf;
    }

    private JButton createPrimaryButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(ACCENT_ROYAL);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(ACCENT_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(ACCENT_ROYAL);
            }
        });
        return btn;
    }

    /**
     * Executes login verification against MySQL `users` table.
     * Supports authentication by User ID / Username OR Email.
     * Preserves exact SHA-256 verification and navigates to the respective dashboard.
     */
    private void executeLogin() {
        String input = userIdField.getText().trim();
        String password = new String(passwordField.getPassword());
        String selectedRole = (String) roleBox.getSelectedItem();

        if (input.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter both your User ID / Email address and password.",
                    "Input Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Support lookup by either username/User ID OR email address
        String sql = "SELECT user_id, username, email, password_hash, role FROM users WHERE email = ? OR username = ?";

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this,
                        "Unable to connect to database. Please check MySQL service.",
                        "Database Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, input);
                ps.setString(2, input);

                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        JOptionPane.showMessageDialog(this,
                                "No account found matching '" + input + "'. Please check your credentials or register first.",
                                "Authentication Failed", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    String storedHash = rs.getString("password_hash");
                    String dbRole = rs.getString("role");
                    String resolvedEmail = rs.getString("email");

                    if (!storedHash.equals(hashPassword(password))) {
                        JOptionPane.showMessageDialog(this,
                                "Incorrect password. Please verify and try again.",
                                "Authentication Failed", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    if (!dbRole.equalsIgnoreCase(selectedRole)) {
                        JOptionPane.showMessageDialog(this,
                                "Selected role ('" + selectedRole + "') does not match your registered role ('" + dbRole + "').",
                                "Role Mismatch", JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    // Successful login
                    JOptionPane.showMessageDialog(this,
                            "Welcome back! Logged in successfully as " + dbRole + ".",
                            "Login Successful", JOptionPane.INFORMATION_MESSAGE);

                    if (dbRole.equalsIgnoreCase("Student")) {
                        new StudentDashboard(resolvedEmail);
                    } else if (dbRole.equalsIgnoreCase("Faculty")) {
                        new FacultyDashboard(resolvedEmail);
                    } else if (dbRole.equalsIgnoreCase("Admin")) {
                        new AdminDashboard();
                    }
                    dispose();
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "System login error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : hash) {
                result.append(String.format("%02x", b));
            }
            return result.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Custom Java 2D artwork component rendering an elegant academic emblem:
     * Open Book of Knowledge, Academic Ribbon, and Graduation Mortarboard with Gold Tassel.
     */
    private static class EducationVisualGraphic extends JPanel {
        EducationVisualGraphic() {
            setOpaque(false);
            setPreferredSize(new Dimension(380, 170));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int cx = getWidth() / 2;
            int cy = getHeight() / 2;

            // 1. Soft Circular Radial Glow Behind Graphic
            g2.setColor(new Color(255, 255, 255, 18));
            g2.fillOval(cx - 90, cy - 75, 180, 150);

            // 2. Open Academic Book
            int bookW = 150;
            int bookH = 75;
            int bookX = cx - (bookW / 2);
            int bookY = cy - 10;

            // Soft drop shadow beneath book
            g2.setColor(new Color(0, 0, 0, 50));
            g2.fillRoundRect(bookX + 4, bookY + 8, bookW, bookH, 16, 16);

            // Left Page
            GeneralPath leftPage = new GeneralPath();
            leftPage.moveTo(bookX, bookY + 8);
            leftPage.curveTo(bookX + 35, bookY - 4, bookX + 65, bookY + 4, cx, bookY + 12);
            leftPage.lineTo(cx, bookY + bookH);
            leftPage.curveTo(bookX + 65, bookY + bookH - 8, bookX + 35, bookY + bookH - 12, bookX, bookY + bookH - 4);
            leftPage.closePath();

            // Right Page
            GeneralPath rightPage = new GeneralPath();
            rightPage.moveTo(cx, bookY + 12);
            rightPage.curveTo(cx + 10, bookY + 4, cx + 40, bookY - 4, bookX + bookW, bookY + 8);
            rightPage.lineTo(bookX + bookW, bookY + bookH - 4);
            rightPage.curveTo(cx + 40, bookY + bookH - 12, cx + 10, bookY + bookH - 8, cx, bookY + bookH);
            rightPage.closePath();

            // Paint book pages with soft ivory gradients
            GradientPaint leftGrad = new GradientPaint(bookX, bookY, new Color(248, 250, 252), cx, bookY, new Color(226, 232, 240));
            g2.setPaint(leftGrad);
            g2.fill(leftPage);

            GradientPaint rightGrad = new GradientPaint(cx, bookY, new Color(226, 232, 240), bookX + bookW, bookY, new Color(248, 250, 252));
            g2.setPaint(rightGrad);
            g2.fill(rightPage);

            // Page outlines
            g2.setColor(new Color(203, 213, 225));
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(leftPage);
            g2.draw(rightPage);

            // Center spine shadow
            g2.setColor(new Color(148, 163, 184, 180));
            g2.drawLine(cx, bookY + 12, cx, bookY + bookH);

            // Text lines on left page
            g2.setColor(new Color(148, 163, 184));
            g2.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.drawLine(bookX + 16, bookY + 24, cx - 14, bookY + 26);
            g2.drawLine(bookX + 16, bookY + 36, cx - 14, bookY + 38);
            g2.drawLine(bookX + 16, bookY + 48, cx - 22, bookY + 50);

            // Text lines on right page
            g2.drawLine(cx + 14, bookY + 26, bookX + bookW - 16, bookY + 24);
            g2.drawLine(cx + 14, bookY + 38, bookX + bookW - 16, bookY + 36);
            g2.drawLine(cx + 14, bookY + 50, bookX + bookW - 24, bookY + 48);

            // Golden ribbon bookmark hanging from book
            GeneralPath ribbon = new GeneralPath();
            ribbon.moveTo(cx - 3, bookY + 12);
            ribbon.lineTo(cx + 3, bookY + 12);
            ribbon.lineTo(cx + 5, bookY + bookH + 16);
            ribbon.lineTo(cx, bookY + bookH + 11);
            ribbon.lineTo(cx - 5, bookY + bookH + 16);
            ribbon.closePath();
            g2.setColor(ACCENT_GOLD);
            g2.fill(ribbon);

            // 3. Graduation Mortarboard Floating Above
            int capY = cy - 42;

            // Skull base
            g2.setColor(new Color(15, 23, 42));
            g2.fillArc(cx - 30, capY + 4, 60, 30, 180, 180);

            // Diamond Cap Top
            Polygon diamond = new Polygon();
            diamond.addPoint(cx, capY - 22);      // Top
            diamond.addPoint(cx + 58, capY - 2);  // Right
            diamond.addPoint(cx, capY + 16);      // Bottom
            diamond.addPoint(cx - 58, capY - 2);  // Left

            // Cap shadow
            g2.setColor(new Color(0, 0, 0, 40));
            Polygon shadowDiamond = new Polygon();
            shadowDiamond.addPoint(cx, capY - 18);
            shadowDiamond.addPoint(cx + 58, capY + 2);
            shadowDiamond.addPoint(cx, capY + 20);
            shadowDiamond.addPoint(cx - 58, capY + 2);
            g2.fill(shadowDiamond);

            // Cap fill
            GradientPaint capGrad = new GradientPaint(
                    cx - 58, capY, new Color(30, 41, 59),
                    cx + 58, capY, new Color(51, 65, 85)
            );
            g2.setPaint(capGrad);
            g2.fill(diamond);

            // Cap rim
            g2.setColor(new Color(148, 163, 184));
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(diamond);

            // Golden Center Button
            g2.setColor(ACCENT_GOLD);
            g2.fillOval(cx - 4, capY - 5, 8, 8);

            // Golden Hanging Tassel
            g2.setColor(new Color(251, 191, 36));
            g2.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            GeneralPath tassel = new GeneralPath();
            tassel.moveTo(cx, capY - 1);
            tassel.curveTo(cx + 32, capY + 2, cx + 46, capY + 14, cx + 42, capY + 34);
            g2.draw(tassel);

            // Tassel fringe
            g2.fillOval(cx + 39, capY + 32, 7, 10);

            // 4. Verification Checkmark Badge
            int sealX = bookX + bookW - 8;
            int sealY = bookY + bookH - 12;
            g2.setColor(new Color(34, 197, 94));
            g2.fillOval(sealX - 12, sealY - 12, 24, 24);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(2.2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.drawLine(sealX - 5, sealY, sealX - 1, sealY + 4);
            g2.drawLine(sealX - 1, sealY + 4, sealX + 5, sealY - 4);

            g2.dispose();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::new);
    }
}
