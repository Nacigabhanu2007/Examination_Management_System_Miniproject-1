package ems;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * RollNumberManager
 * Centralized automatic Roll Number generation & alphabetical ordering service.
 * Format: Admission Year (2 digits) + Department Code + 3-digit Serial Number.
 * Examples: 25BCS001, 25BIT001, 25BMG001, 25BCI001, 25BEE001, 25BEC001, 25BBM001.
 */
public class RollNumberManager {

    /**
     * Map confirmed department names to standardized department codes.
     */
    public static String getDepartmentCode(String department) {
        if (department == null) return "BCS";
        String d = department.trim().toLowerCase();

        // Exact & substring matching for confirmed departments
        if (d.contains("computer") || d.equals("cse") || d.contains("cs")) return "BCS";
        if (d.contains("information") || d.equals("it")) return "BIT";
        if (d.contains("mechanical") || d.equals("mech") || d.equals("me")) return "BMG";
        if (d.contains("civil") || d.equals("ce")) return "BCI";
        if (d.contains("electrical") && d.contains("electronic")) return "BEE";
        if (d.contains("electronic") || d.contains("communication") || d.equals("ece")) return "BEC";
        if (d.contains("biomedical") || d.contains("medical") || d.equals("bme")) return "BBM";
        if (d.contains("biotech")) return "BBT";
        if (d.contains("artificial") || d.contains("data science") || d.equals("aids") || d.equals("ai")) return "BAI";

        return "BCS";
    }

    /**
     * Resolve admission year from academic year or explicitly provided admission year.
     * Examples:
     * First Year -> 2026 (26)
     * Second Year -> 2025 (25)
     * Third Year -> 2024 (24)
     * Fourth Year -> 2023 (23)
     */
    public static int resolveAdmissionYear(int currentYear, int admissionYear) {
        if (admissionYear >= 2000 && admissionYear <= 2099) {
            return admissionYear;
        }
        // Fallback based on academic year
        switch (currentYear) {
            case 1: return 2026;
            case 2: return 2025;
            case 3: return 2024;
            case 4: return 2023;
            default: return 2025;
        }
    }

    /**
     * Data holder for a student record during alphabetical re-indexing.
     */
    public static class StudentRollEntry {
        public String studentId;
        public String studentName;
        public String currentRoll;

        public StudentRollEntry(String studentId, String studentName, String currentRoll) {
            this.studentId = studentId;
            this.studentName = (studentName != null) ? studentName.trim() : "";
            this.currentRoll = (currentRoll != null) ? currentRoll.trim() : "";
        }
    }

    /**
     * Reassign roll numbers alphabetically for all students in a given department and admission year.
     * Starts from 001 for each department + admission year combination.
     * Prevents duplicates and maintains permanent student_id references.
     */
    public static synchronized void reassignRollNumbers(Connection con, String department, int admissionYear) throws SQLException {
        if (con == null || department == null || department.trim().isEmpty()) return;

        int resolvedAdmYear = (admissionYear >= 2000) ? admissionYear : 2025;
        int currentYear = 2027 - resolvedAdmYear; // rough mapping if needed
        String deptCode = getDepartmentCode(department);
        String prefix = String.format("%02d%s", resolvedAdmYear % 100, deptCode);

        // Fetch all students for this department and admission year
        String selectSql = "SELECT student_id, student_name, roll_number FROM student "
                         + "WHERE LOWER(TRIM(department)) = LOWER(TRIM(?)) "
                         + "  AND (admission_year = ? OR (admission_year IS NULL AND year = ?))";

        List<StudentRollEntry> list = new ArrayList<>();
        try (PreparedStatement ps = con.prepareStatement(selectSql)) {
            ps.setString(1, department.trim());
            ps.setInt(2, resolvedAdmYear);
            ps.setInt(3, currentYear);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new StudentRollEntry(
                        rs.getString("student_id"),
                        rs.getString("student_name"),
                        rs.getString("roll_number")
                    ));
                }
            }
        }

        if (list.isEmpty()) return;

        // Sort alphabetically by student name (case-insensitive)
        Collections.sort(list, new Comparator<StudentRollEntry>() {
            @Override
            public int compare(StudentRollEntry a, StudentRollEntry b) {
                int cmp = a.studentName.compareToIgnoreCase(b.studentName);
                if (cmp != 0) return cmp;
                return a.studentId.compareToIgnoreCase(b.studentId);
            }
        });

        // Safe 2-pass update to avoid any collision
        // Pass 1: Assign temporary roll numbers
        String tempSql = "UPDATE student SET roll_number = ? WHERE student_id = ?";
        try (PreparedStatement ps = con.prepareStatement(tempSql)) {
            for (int i = 0; i < list.size(); i++) {
                StudentRollEntry s = list.get(i);
                ps.setString(1, "TMP_" + i + "_" + s.studentId);
                ps.setString(2, s.studentId);
                ps.addBatch();
            }
            ps.executeBatch();
        }

        // Pass 2: Assign final formatted roll numbers: Prefix + 3-digit serial (e.g. 25BCS001)
        String finalSql = "UPDATE student SET roll_number = ?, admission_year = ? WHERE student_id = ?";
        try (PreparedStatement ps = con.prepareStatement(finalSql)) {
            for (int i = 0; i < list.size(); i++) {
                StudentRollEntry s = list.get(i);
                String rollNo = String.format("%s%03d", prefix, i + 1);
                ps.setString(1, rollNo);
                ps.setInt(2, resolvedAdmYear);
                ps.setString(3, s.studentId);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    /**
     * Preview or calculate what roll number a new student would receive.
     */
    public static synchronized String previewNextRollNumber(String department, int admissionYear, String studentName) {
        int resolvedAdmYear = (admissionYear >= 2000) ? admissionYear : 2025;
        String deptCode = getDepartmentCode(department);
        String prefix = String.format("%02d%s", resolvedAdmYear % 100, deptCode);

        try (Connection con = DBConnection.getConnection()) {
            if (con == null) return prefix + "001";

            String selectSql = "SELECT student_id, student_name, roll_number FROM student "
                             + "WHERE LOWER(TRIM(department)) = LOWER(TRIM(?)) "
                             + "  AND (admission_year = ? OR (admission_year IS NULL AND year = ?))";

            List<StudentRollEntry> list = new ArrayList<>();
            int currentYear = 2027 - resolvedAdmYear;
            try (PreparedStatement ps = con.prepareStatement(selectSql)) {
                ps.setString(1, department.trim());
                ps.setInt(2, resolvedAdmYear);
                ps.setInt(3, currentYear);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        list.add(new StudentRollEntry(
                            rs.getString("student_id"),
                            rs.getString("student_name"),
                            rs.getString("roll_number")
                        ));
                    }
                }
            }

            // Include candidate if provided
            String candName = (studentName != null) ? studentName.trim() : "";
            list.add(new StudentRollEntry("CANDIDATE", candName, ""));

            Collections.sort(list, new Comparator<StudentRollEntry>() {
                @Override
                public int compare(StudentRollEntry a, StudentRollEntry b) {
                    int cmp = a.studentName.compareToIgnoreCase(b.studentName);
                    if (cmp != 0) return cmp;
                    return a.studentId.compareToIgnoreCase(b.studentId);
                }
            });

            for (int i = 0; i < list.size(); i++) {
                if ("CANDIDATE".equals(list.get(i).studentId)) {
                    return String.format("%s%03d", prefix, i + 1);
                }
            }
        } catch (Exception e) {
            // fallback
        }
        return prefix + "001";
    }

    /**
     * Convenience method to fetch a student's roll number by student ID.
     */
    public static String getRollNumberByStudentId(String studentId) {
        if (studentId == null || studentId.trim().isEmpty()) return "N/A";
        String sql = "SELECT roll_number FROM student WHERE student_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentId.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String r = rs.getString("roll_number");
                    return (r != null && !r.trim().isEmpty()) ? r.trim() : "N/A";
                }
            }
        } catch (SQLException ignored) {}
        return "N/A";
    }
}
