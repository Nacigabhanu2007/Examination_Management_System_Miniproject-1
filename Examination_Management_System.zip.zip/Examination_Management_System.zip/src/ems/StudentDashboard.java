package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Modern, Professional Student Dashboard
 * Personalized portal for the logged-in student.
 * Completely self-contained with no external UI dependencies.
 */
public class StudentDashboard extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color DANGER_RED = new Color(185, 28, 28);
    private final Color DANGER_HOVER = new Color(220, 38, 38);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);

    private String studentEmail = "";
    private String studentName = "Student";
    private String studentId = "";
    private String rollNumber = "";
    private String department = "";
    private int studentYear = 0;
    private String studentSemester = "";

    private JLabel subjectsCountLbl;
    private JLabel examsCountLbl;
    private JLabel resultsCountLbl;

    private DefaultTableModel classesModel;
    private JTable classesTable;

    public StudentDashboard() {
        this("");
    }

    public StudentDashboard(String studentEmail) {
        this.studentEmail = (studentEmail != null) ? studentEmail.trim() : "";
        fetchStudentInfo();

        setTitle("Examination Management System - Student Portal");
        setSize(1200, 780);
        setMinimumSize(new Dimension(1000, 680));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // LEFT SIDEBAR
        JPanel sidebar = new JPanel();
        sidebar.setBackground(NAVY);
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(new EmptyBorder(25, 16, 25, 16));

        JLabel logo = new JLabel(" EMS PORTAL");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitle = new JLabel(" Student Examination Portal");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(new Color(190, 205, 235));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(4));
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(25));

        // Navigation Sidebar Buttons
        addSidebarButton(sidebar, "Dashboard", () -> refreshDashboard());
        addSidebarButton(sidebar, "Student Profile", () -> new StudentProfile(studentEmail).setVisible(true));
        addSidebarButton(sidebar, "Registered Subjects", () -> new Subjects(studentEmail).setVisible(true));
        addSidebarButton(sidebar, "Exam Registration", () -> new ExamRegistration(studentEmail).setVisible(true));
        addSidebarButton(sidebar, "Exam Schedule", () -> new ExamSchedule().setVisible(true));
        addSidebarButton(sidebar, "Hall & Seat Allocation", () -> new HallSeatAllocation(studentEmail).setVisible(true));
        addSidebarButton(sidebar, "View Marks", () -> new ViewMarks(studentEmail).setVisible(true));
        addSidebarButton(sidebar, "View Results", () -> new ViewResults(studentEmail).setVisible(true));

        sidebar.add(Box.createVerticalGlue());

        JButton logoutButton = createDangerButton("Logout");
        logoutButton.setPreferredSize(new Dimension(218, 38));
        logoutButton.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        logoutButton.setAlignmentX(Component.LEFT_ALIGNMENT);

        logoutButton.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to log out of your student session?",
                    "Confirm Logout",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (choice == JOptionPane.YES_OPTION) {
                dispose();
                new Login().setVisible(true);
            }
        });

        sidebar.add(logoutButton);
        mainPanel.add(sidebar, BorderLayout.WEST);

        // RIGHT CONTENT PANEL
        JPanel content = new JPanel(new BorderLayout(0, 20));
        content.setBackground(BG_LIGHT);
        content.setBorder(new EmptyBorder(25, 30, 25, 30));

        // TOP HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel headingPanel = new JPanel();
        headingPanel.setOpaque(false);
        headingPanel.setLayout(new BoxLayout(headingPanel, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("Student Dashboard");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 28));
        heading.setForeground(NAVY);

        String yrSemInfo = "";
        if (studentYear > 0) {
            yrSemInfo = " • Year " + studentYear;
        }
        if (studentSemester != null && !studentSemester.trim().isEmpty() && !studentSemester.equalsIgnoreCase("null")) {
            yrSemInfo += " • " + (studentSemester.startsWith("Semester") ? studentSemester : "Semester " + studentSemester);
        }

        String rollInfo = (!rollNumber.isEmpty()) ? " • Roll No: " + rollNumber : "";
        JLabel welcome = new JLabel("Welcome back, " + studentName + "! (ID: " + (studentId.isEmpty() ? "N/A" : studentId) + rollInfo + " • " + department + yrSemInfo + ")");
        welcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        welcome.setForeground(TEXT_MUTED);

        headingPanel.add(heading);
        headingPanel.add(Box.createVerticalStrut(6));
        headingPanel.add(welcome);

        JLabel roleBadge = new JLabel(" STUDENT ");
        roleBadge.setOpaque(true);
        roleBadge.setBackground(new Color(224, 238, 255));
        roleBadge.setForeground(PRIMARY_BLUE);
        roleBadge.setFont(new Font("Segoe UI", Font.BOLD, 13));
        roleBadge.setBorder(new EmptyBorder(8, 14, 8, 14));

        header.add(headingPanel, BorderLayout.WEST);
        header.add(roleBadge, BorderLayout.EAST);
        content.add(header, BorderLayout.NORTH);

        // BODY CONTAINER
        JPanel bodyContainer = new JPanel();
        bodyContainer.setLayout(new BoxLayout(bodyContainer, BoxLayout.Y_AXIS));
        bodyContainer.setOpaque(false);

        // SUMMARY METRICS CARDS
        JPanel summaryPanel = new JPanel(new GridLayout(1, 3, 18, 0));
        summaryPanel.setOpaque(false);

        subjectsCountLbl = new JLabel("0", SwingConstants.LEFT);
        examsCountLbl = new JLabel("0", SwingConstants.LEFT);
        resultsCountLbl = new JLabel("0", SwingConstants.LEFT);

        summaryPanel.add(createSummaryCard("DEPARTMENT SUBJECTS", subjectsCountLbl, "Available in Curriculum", new Color(30, 64, 124)));
        summaryPanel.add(createSummaryCard("EXAM REGISTRATIONS", examsCountLbl, "Confirmed Registrations", new Color(13, 148, 136)));
        summaryPanel.add(createSummaryCard("PUBLISHED RESULTS", resultsCountLbl, "Academic Grades Awarded", new Color(217, 119, 6)));

        bodyContainer.add(summaryPanel);
        bodyContainer.add(Box.createVerticalStrut(20));

        // CLASSES & SUBJECTS LIVE TABLE CARD
        JPanel classesCard = new JPanel(new BorderLayout(0, 10));
        classesCard.setBackground(CARD_BG);
        classesCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(16, 20, 16, 20)
        ));

        JPanel classesCardHeader = new JPanel(new BorderLayout());
        classesCardHeader.setOpaque(false);

        JPanel classesTitlePanel = new JPanel();
        classesTitlePanel.setOpaque(false);
        classesTitlePanel.setLayout(new BoxLayout(classesTitlePanel, BoxLayout.Y_AXIS));

        JLabel classesTitle = new JLabel("My Department Curriculum Classes & Subjects");
        classesTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        classesTitle.setForeground(NAVY);

        JLabel classesSub = new JLabel("Live classes loaded dynamically from the examination database for " + department);
        classesSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        classesSub.setForeground(TEXT_MUTED);

        classesTitlePanel.add(classesTitle);
        classesTitlePanel.add(Box.createVerticalStrut(2));
        classesTitlePanel.add(classesSub);

        JPanel btnGroup = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnGroup.setOpaque(false);

        JButton viewAllBtn = new JButton("Open Full View");
        viewAllBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        viewAllBtn.setForeground(PRIMARY_BLUE);
        viewAllBtn.setBackground(new Color(239, 246, 255));
        viewAllBtn.setFocusPainted(false);
        viewAllBtn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(191, 219, 254), 1),
                BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        viewAllBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        viewAllBtn.addActionListener(e -> new Subjects(studentEmail).setVisible(true));

        JButton refreshClassesBtn = new JButton("Refresh");
        refreshClassesBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        refreshClassesBtn.setForeground(Color.WHITE);
        refreshClassesBtn.setBackground(PRIMARY_BLUE);
        refreshClassesBtn.setFocusPainted(false);
        refreshClassesBtn.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        refreshClassesBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        refreshClassesBtn.addActionListener(e -> refreshDashboard());

        btnGroup.add(viewAllBtn);
        btnGroup.add(refreshClassesBtn);

        classesCardHeader.add(classesTitlePanel, BorderLayout.WEST);
        classesCardHeader.add(btnGroup, BorderLayout.EAST);
        classesCard.add(classesCardHeader, BorderLayout.NORTH);

        String[] classCols = {"Class / Subject ID", "Subject Name", "Department ID", "Semester", "Credits"};
        classesModel = new DefaultTableModel(classCols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        classesTable = new JTable(classesModel);
        styleTable(classesTable);

        JScrollPane tableScroll = new JScrollPane(classesTable);
        tableScroll.setPreferredSize(new Dimension(0, 160));
        tableScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        classesCard.add(tableScroll, BorderLayout.CENTER);

        bodyContainer.add(classesCard);
        bodyContainer.add(Box.createVerticalStrut(20));

        // QUICK ACCESS MODULES
        JPanel centerPanel = new JPanel(new BorderLayout(0, 12));
        centerPanel.setOpaque(false);

        JLabel quickTitle = new JLabel("Academic Services & Tools");
        quickTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        quickTitle.setForeground(TEXT_DARK);

        JLabel quickSubtitle = new JLabel("Access your student profile, exam schedules, seat allocations, marks and final results.");
        quickSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        quickSubtitle.setForeground(TEXT_MUTED);

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.add(quickTitle);
        titlePanel.add(Box.createVerticalStrut(4));
        titlePanel.add(quickSubtitle);

        JPanel buttonGrid = new JPanel(new GridLayout(0, 3, 16, 16));
        buttonGrid.setOpaque(false);

        addModuleCard(buttonGrid, "My Student Profile", "View and update your personal and academic record.", () -> new StudentProfile(studentEmail).setVisible(true), new Color(30, 64, 124));
        addModuleCard(buttonGrid, "Registered Subjects", "Browse subjects and credits mapped to your branch.", () -> new Subjects(studentEmail).setVisible(true), new Color(109, 40, 217));
        addModuleCard(buttonGrid, "Exam Registration", "Register for upcoming university examination sessions.", () -> new ExamRegistration(studentEmail).setVisible(true), new Color(13, 148, 136));
        addModuleCard(buttonGrid, "Exam Schedule", "Check exam dates, session timings, and timetables.", () -> new ExamSchedule().setVisible(true), new Color(217, 119, 6));
        addModuleCard(buttonGrid, "Hall & Seat Allocation", "Find your allotted examination hall and seat number.", () -> new HallSeatAllocation(studentEmail).setVisible(true), new Color(225, 29, 72));
        addModuleCard(buttonGrid, "View Marks", "Review your subject-wise marks and evaluations.", () -> new ViewMarks(studentEmail).setVisible(true), new Color(2, 132, 199));
        addModuleCard(buttonGrid, "View Results", "Check your published examination grades and result status.", () -> new ViewResults(studentEmail).setVisible(true), new Color(194, 65, 12));

        centerPanel.add(titlePanel, BorderLayout.NORTH);
        centerPanel.add(buttonGrid, BorderLayout.CENTER);
        bodyContainer.add(centerPanel);

        JScrollPane scrollPane = new JScrollPane(bodyContainer);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        content.add(scrollPane, BorderLayout.CENTER);

        // FOOTER
        JLabel footer = new JLabel("College Examination Management System • Java SE 21 & MySQL • Student Portal", SwingConstants.CENTER);
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        footer.setForeground(TEXT_MUTED);
        content.add(footer, BorderLayout.SOUTH);

        mainPanel.add(content, BorderLayout.CENTER);

        setContentPane(mainPanel);
        refreshDashboard();
        setVisible(true);
    }

    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader th = table.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 13));
        th.setBackground(new Color(241, 245, 249));
        th.setForeground(TEXT_DARK);
        th.setReorderingAllowed(false);
        th.setPreferredSize(new Dimension(0, 34));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void addSidebarButton(JPanel sidebar, String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(new Color(226, 232, 240));
        button.setBackground(new Color(30, 48, 86));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(218, 38));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(new EmptyBorder(8, 14, 8, 14));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(PRIMARY_BLUE);
                button.setForeground(Color.WHITE);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(30, 48, 86));
                button.setForeground(new Color(226, 232, 240));
            }
        });

        button.addActionListener(e -> action.run());
        sidebar.add(button);
        sidebar.add(Box.createVerticalStrut(5));
    }

    private JButton createDangerButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(DANGER_RED);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(DANGER_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(DANGER_RED);
            }
        });
        return btn;
    }

    private JPanel createSummaryCard(String title, JLabel countLbl, String description, Color accent) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER_COLOR, 1),
                        new EmptyBorder(14, 16, 14, 16)
                )
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        titleLabel.setForeground(TEXT_MUTED);

        countLbl.setFont(new Font("Segoe UI", Font.BOLD, 26));
        countLbl.setForeground(accent);

        JLabel descLabel = new JLabel(description);
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(TEXT_MUTED);

        card.add(titleLabel);
        card.add(Box.createVerticalStrut(4));
        card.add(countLbl);
        card.add(Box.createVerticalStrut(4));
        card.add(descLabel);

        return card;
    }

    private void addModuleCard(JPanel grid, String title, String description, Runnable action, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(color);

        JLabel descLabel = new JLabel("<html>" + description + "</html>");
        descLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descLabel.setForeground(TEXT_MUTED);

        JButton openBtn = new JButton("Open Service");
        openBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        openBtn.setForeground(Color.WHITE);
        openBtn.setBackground(PRIMARY_BLUE);
        openBtn.setFocusPainted(false);
        openBtn.setBorderPainted(false);
        openBtn.setOpaque(true);
        openBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        openBtn.setPreferredSize(new Dimension(120, 32));

        openBtn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                openBtn.setBackground(PRIMARY_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                openBtn.setBackground(PRIMARY_BLUE);
            }
        });

        openBtn.addActionListener(e -> action.run());

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(descLabel, BorderLayout.CENTER);
        card.add(openBtn, BorderLayout.SOUTH);

        grid.add(card);
    }

    private void fetchStudentInfo() {
        if (studentEmail.isEmpty()) {
            String q = "SELECT email, student_name, student_id, roll_number, department, year, semester FROM student LIMIT 1";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(q);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    studentEmail = rs.getString("email");
                    studentName = rs.getString("student_name");
                    studentId = rs.getString("student_id");
                    rollNumber = rs.getString("roll_number");
                    if (rollNumber == null) rollNumber = "";
                    department = rs.getString("department");
                    studentYear = rs.getInt("year");
                    studentSemester = rs.getString("semester");
                }
            } catch (SQLException ignored) {}
            return;
        }

        String sql = "SELECT student_name, student_id, roll_number, department, year, semester FROM student WHERE email = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, studentEmail);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    studentName = rs.getString("student_name");
                    studentId = rs.getString("student_id");
                    rollNumber = rs.getString("roll_number");
                    if (rollNumber == null) rollNumber = "";
                    department = rs.getString("department");
                    studentYear = rs.getInt("year");
                    studentSemester = rs.getString("semester");
                }
            }
        } catch (SQLException ignored) {}
    }

    public void refreshDashboard() {
        loadStudentMetrics();
        loadStudentClasses();
    }

    private void loadStudentClasses() {
        new Thread(() -> {
            java.util.List<Object[]> rows = new java.util.ArrayList<>();
            boolean hasDept = (department != null && !department.trim().isEmpty());

            String sql;
            if (hasDept) {
                sql = "SELECT subject_id, subject_name, department_id, semester, credits "
                    + "FROM subject "
                    + "WHERE department_id = ? OR department_id LIKE ? "
                    + "ORDER BY semester, subject_id";
            } else {
                sql = "SELECT subject_id, subject_name, department_id, semester, credits FROM subject ORDER BY semester, subject_id";
            }

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                if (hasDept) {
                    ps.setString(1, department.trim());
                    ps.setString(2, "%" + department.trim().substring(0, Math.min(2, department.trim().length())) + "%");
                }

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        rows.add(new Object[]{
                            rs.getString("subject_id"),
                            rs.getString("subject_name"),
                            rs.getString("department_id"),
                            "Semester " + rs.getInt("semester"),
                            rs.getDouble("credits")
                        });
                    }
                }

                // If department filter produced 0 rows, fallback to all subjects
                if (rows.isEmpty() && hasDept) {
                    String allSql = "SELECT subject_id, subject_name, department_id, semester, credits FROM subject ORDER BY semester, subject_id";
                    try (PreparedStatement allPs = con.prepareStatement(allSql);
                         ResultSet allRs = allPs.executeQuery()) {
                        while (allRs.next()) {
                            rows.add(new Object[]{
                                allRs.getString("subject_id"),
                                allRs.getString("subject_name"),
                                allRs.getString("department_id"),
                                "Semester " + allRs.getInt("semester"),
                                allRs.getDouble("credits")
                            });
                        }
                    }
                }

            } catch (SQLException ignored) {}

            SwingUtilities.invokeLater(() -> {
                classesModel.setRowCount(0);
                for (Object[] row : rows) {
                    classesModel.addRow(row);
                }
            });
        }).start();
    }

    private void loadStudentMetrics() {
        new Thread(() -> {
            int subCount = 0;
            int regCount = 0;
            int resCount = 0;

            try (Connection con = DBConnection.getConnection()) {
                if (con != null) {
                    // Subjects count relevant to student's department
                    boolean hasDept = (department != null && !department.trim().isEmpty());
                    if (hasDept) {
                        String s1 = "SELECT COUNT(*) FROM subject WHERE department_id = ? OR department_id LIKE ?";
                        try (PreparedStatement ps = con.prepareStatement(s1)) {
                            ps.setString(1, department.trim());
                            ps.setString(2, "%" + department.trim().substring(0, Math.min(2, department.trim().length())) + "%");
                            try (ResultSet rs = ps.executeQuery()) {
                                if (rs.next()) subCount = rs.getInt(1);
                            }
                        }
                    }

                    if (subCount == 0) {
                        String sAll = "SELECT COUNT(*) FROM subject";
                        try (PreparedStatement ps = con.prepareStatement(sAll);
                             ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) subCount = rs.getInt(1);
                        }
                    }

                    // Registrations count for this student
                    String s2 = "SELECT COUNT(*) FROM examregistration WHERE studentId = ?";
                    try (PreparedStatement ps = con.prepareStatement(s2)) {
                        ps.setString(1, studentId);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) regCount = rs.getInt(1);
                        }
                    }

                    // Results count for this student
                    String s3 = "SELECT COUNT(*) FROM results WHERE student_id = ?";
                    try (PreparedStatement ps = con.prepareStatement(s3)) {
                        ps.setString(1, studentId);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) resCount = rs.getInt(1);
                        }
                    }
                }
            } catch (SQLException ignored) {}

            final int fSub = subCount;
            final int fReg = regCount;
            final int fRes = resCount;
            SwingUtilities.invokeLater(() -> {
                subjectsCountLbl.setText(String.valueOf(fSub));
                examsCountLbl.setText(String.valueOf(fReg));
                resultsCountLbl.setText(String.valueOf(fRes));
            });
        }).start();
    }
}
