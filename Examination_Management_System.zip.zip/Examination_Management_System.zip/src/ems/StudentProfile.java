package ems;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Modern, Professional Student Profile
 * Organized into four distinct cards: Personal, Contact, Academic, Account.
 * Completely self-contained with no external UI dependencies.
 */
public class StudentProfile extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SUCCESS_GREEN = new Color(22, 101, 52);
    private final Color SUCCESS_HOVER = new Color(21, 128, 61);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private String studentEmail;
    private String currentStudentId = "";
    private boolean isEditing = false;

    // Section A: Personal Information
    private JTextField studentIdField;
    private JTextField nameField;
    private JTextField dobField;
    private JComboBox<String> genderBox;
    private JComboBox<String> bloodGroupBox;

    // Section B: Contact Information
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField altPhoneField;
    private JTextArea addressArea;
    private JTextField cityField;
    private JTextField stateField;
    private JTextField pincodeField;

    // Section C: Academic Information
    private JTextField departmentField;
    private JTextField degreeField;
    private JTextField admissionYearField;
    private JComboBox<String> currentYearBox;
    private JComboBox<String> semesterBox;
    private JTextField rollNumberField;
    private JTextField registerNumberField;

    // Section D: Account Information
    private JTextField usernameField;
    private JTextField roleField;
    private JPasswordField passwordField;

    // Action Buttons
    private JButton editButton;
    private JButton updateButton;
    private JButton cancelButton;
    private JButton backButton;

    public StudentProfile() {
        this("");
    }

    public StudentProfile(String studentEmail) {
        this.studentEmail = (studentEmail != null) ? studentEmail.trim() : "";

        setTitle("Examination Management System - Student Profile");
        setSize(1000, 850);
        setMinimumSize(new Dimension(880, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "STUDENT INFORMATION PROFILE",
                "Official College Profile & Academic Verification Record"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Scrollable content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(20, 30, 20, 30));

        // SECTION A: PERSONAL INFORMATION
        JPanel cardA = createCard("A. PERSONAL INFORMATION");
        JPanel gridA = new JPanel(new GridLayout(0, 2, 20, 12));
        gridA.setOpaque(false);

        studentIdField = createTextField(false);
        nameField = createTextField(false);
        dobField = createTextField(false);
        genderBox = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        genderBox.setFont(FONT_INPUT);
        genderBox.setEnabled(false);

        bloodGroupBox = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"});
        bloodGroupBox.setFont(FONT_INPUT);
        bloodGroupBox.setEnabled(false);

        addField(gridA, "Student ID (Primary Key):", studentIdField);
        addField(gridA, "Full Name:", nameField);
        addField(gridA, "Date of Birth (YYYY-MM-DD):", dobField);
        addField(gridA, "Gender:", genderBox);
        addField(gridA, "Blood Group:", bloodGroupBox);

        cardA.add(gridA, BorderLayout.CENTER);
        contentPanel.add(cardA);
        contentPanel.add(Box.createVerticalStrut(18));

        // SECTION B: CONTACT INFORMATION
        JPanel cardB = createCard("B. CONTACT INFORMATION");
        JPanel gridB = new JPanel(new GridLayout(0, 2, 20, 12));
        gridB.setOpaque(false);

        emailField = createTextField(false);
        phoneField = createTextField(false);
        altPhoneField = createTextField(false);

        addressArea = new JTextArea(3, 20);
        addressArea.setFont(FONT_INPUT);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        addressArea.setEditable(false);
        addressArea.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        addressArea.setBackground(new Color(248, 250, 252));
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addressScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        cityField = createTextField(false);
        stateField = createTextField(false);
        pincodeField = createTextField(false);

        addField(gridB, "Email Address:", emailField);
        addField(gridB, "Primary Phone Number:", phoneField);
        addField(gridB, "Alternative Phone Number:", altPhoneField);
        addField(gridB, "Residential Address:", addressScroll);
        addField(gridB, "City:", cityField);
        addField(gridB, "State:", stateField);
        addField(gridB, "Postal Pincode:", pincodeField);

        cardB.add(gridB, BorderLayout.CENTER);
        contentPanel.add(cardB);
        contentPanel.add(Box.createVerticalStrut(18));

        // SECTION C: ACADEMIC INFORMATION
        JPanel cardC = createCard("C. ACADEMIC INFORMATION");
        JPanel gridC = new JPanel(new GridLayout(0, 2, 20, 12));
        gridC.setOpaque(false);

        departmentField = createTextField(false);
        degreeField = createTextField(false);
        admissionYearField = createTextField(false);

        currentYearBox = new JComboBox<>(new String[]{"1st Year", "2nd Year", "3rd Year", "4th Year"});
        currentYearBox.setFont(FONT_INPUT);
        currentYearBox.setEnabled(false);

        semesterBox = new JComboBox<>(new String[]{
                "Semester 1", "Semester 2", "Semester 3", "Semester 4",
                "Semester 5", "Semester 6", "Semester 7", "Semester 8"
        });
        semesterBox.setFont(FONT_INPUT);
        semesterBox.setEnabled(false);

        rollNumberField = createTextField(false);
        registerNumberField = createTextField(false);

        addField(gridC, "Department / Branch:", departmentField);
        addField(gridC, "Degree:", degreeField);
        addField(gridC, "Admission Year:", admissionYearField);
        addField(gridC, "Current Year of Study:", currentYearBox);
        addField(gridC, "Semester:", semesterBox);
        addField(gridC, "Class Roll Number:", rollNumberField);
        addField(gridC, "University Register Number:", registerNumberField);

        cardC.add(gridC, BorderLayout.CENTER);
        contentPanel.add(cardC);
        contentPanel.add(Box.createVerticalStrut(18));

        // SECTION D: ACCOUNT INFORMATION
        JPanel cardD = createCard("D. ACCOUNT INFORMATION");
        JPanel gridD = new JPanel(new GridLayout(0, 2, 20, 12));
        gridD.setOpaque(false);

        usernameField = createTextField(false);
        roleField = createTextField(false);
        roleField.setText("Student");

        passwordField = new JPasswordField("••••••••");
        passwordField.setFont(FONT_INPUT);
        passwordField.setEditable(false);
        passwordField.setBackground(new Color(248, 250, 252));
        passwordField.setBorder(createFieldBorder());

        addField(gridD, "Account Username:", usernameField);
        addField(gridD, "System Role:", roleField);
        addField(gridD, "Account Password:", passwordField);

        cardD.add(gridD, BorderLayout.CENTER);
        contentPanel.add(cardD);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Action Buttons Bar
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 14));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR));

        backButton = createButton("Back", SECONDARY_GRAY, SECONDARY_HOVER);
        cancelButton = createButton("Cancel", new Color(148, 163, 184), new Color(100, 116, 139));
        editButton = createButton("Edit Profile", PRIMARY_BLUE, PRIMARY_HOVER);
        updateButton = createButton("Update Profile", SUCCESS_GREEN, SUCCESS_HOVER);

        cancelButton.setEnabled(false);
        updateButton.setEnabled(false);

        buttonPanel.add(backButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(editButton);
        buttonPanel.add(updateButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Listeners
        backButton.addActionListener(e -> dispose());
        editButton.addActionListener(e -> setEditMode(true));
        cancelButton.addActionListener(e -> {
            loadStudentProfile();
            setEditMode(false);
        });
        updateButton.addActionListener(e -> saveUpdatedProfile());

        loadStudentProfile();

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private Border createFieldBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        );
    }

    private JTextField createTextField(boolean editable) {
        JTextField tf = new JTextField();
        tf.setFont(FONT_INPUT);
        tf.setEditable(editable);
        tf.setBorder(createFieldBorder());
        if (!editable) {
            tf.setBackground(new Color(248, 250, 252));
            tf.setForeground(TEXT_DARK);
        }
        return tf;
    }

    private JPanel createCard(String title) {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(16, 22, 18, 22)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(FONT_HEADER);
        titleLbl.setForeground(PRIMARY_BLUE);

        card.add(titleLbl, BorderLayout.NORTH);
        return card;
    }

    private void addField(JPanel panel, String labelText, Component comp) {
        JPanel wrap = new JPanel(new BorderLayout(0, 4));
        wrap.setOpaque(false);

        JLabel lbl = new JLabel(labelText);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(TEXT_DARK);

        wrap.add(lbl, BorderLayout.NORTH);
        wrap.add(comp, BorderLayout.CENTER);
        panel.add(wrap);
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(130, 36));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void setEditMode(boolean enable) {
        this.isEditing = enable;

        // Editable fields
        nameField.setEditable(enable);
        dobField.setEditable(enable);
        genderBox.setEnabled(enable);
        bloodGroupBox.setEnabled(enable);
        phoneField.setEditable(enable);
        altPhoneField.setEditable(enable);
        addressArea.setEditable(enable);
        cityField.setEditable(enable);
        stateField.setEditable(enable);
        pincodeField.setEditable(enable);

        currentYearBox.setEnabled(enable);
        semesterBox.setEnabled(enable);
        rollNumberField.setEditable(false);
        registerNumberField.setEditable(enable);

        Color fieldBg = enable ? Color.WHITE : new Color(248, 250, 252);
        nameField.setBackground(fieldBg);
        dobField.setBackground(fieldBg);
        phoneField.setBackground(fieldBg);
        altPhoneField.setBackground(fieldBg);
        addressArea.setBackground(fieldBg);
        cityField.setBackground(fieldBg);
        stateField.setBackground(fieldBg);
        pincodeField.setBackground(fieldBg);
        rollNumberField.setBackground(new Color(248, 250, 252));
        registerNumberField.setBackground(fieldBg);

        editButton.setEnabled(!enable);
        updateButton.setEnabled(enable);
        cancelButton.setEnabled(enable);
    }

    private void loadStudentProfile() {
        if (studentEmail.isEmpty()) {
            String queryFirst = "SELECT email FROM student LIMIT 1";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(queryFirst);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    studentEmail = rs.getString("email");
                }
            } catch (SQLException ignored) {}
        }

        String sql = "SELECT * FROM student WHERE email = ? OR student_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, studentEmail);
            ps.setString(2, studentEmail);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    currentStudentId = rs.getString("student_id");
                    studentIdField.setText(currentStudentId);
                    nameField.setText(rs.getString("student_name"));

                    java.sql.Date dob = rs.getDate("dob");
                    dobField.setText(dob != null ? dob.toString() : "");

                    String gender = rs.getString("gender");
                    if (gender != null) genderBox.setSelectedItem(gender);

                    String bg = rs.getString("blood_group");
                    if (bg != null) bloodGroupBox.setSelectedItem(bg);

                    emailField.setText(rs.getString("email"));
                    phoneField.setText(rs.getString("phone"));
                    altPhoneField.setText(rs.getString("alt_phone"));
                    addressArea.setText(rs.getString("address"));
                    cityField.setText(rs.getString("city"));
                    stateField.setText(rs.getString("state"));
                    pincodeField.setText(rs.getString("pincode"));

                    departmentField.setText(rs.getString("department"));
                    degreeField.setText(rs.getString("degree"));
                    admissionYearField.setText(String.valueOf(rs.getInt("admission_year")));

                    int yr = rs.getInt("year");
                    currentYearBox.setSelectedItem(yr + (yr == 1 ? "st Year" : yr == 2 ? "nd Year" : yr == 3 ? "rd Year" : "th Year"));

                    String sem = rs.getString("semester");
                    if (sem != null) semesterBox.setSelectedItem(sem);

                    rollNumberField.setText(rs.getString("roll_number"));
                    registerNumberField.setText(rs.getString("register_number"));
                }
            }

            // Load username from users table
            String userSql = "SELECT username FROM users WHERE email = ?";
            try (PreparedStatement ps2 = con.prepareStatement(userSql)) {
                ps2.setString(1, emailField.getText().trim());
                try (ResultSet rs2 = ps2.executeQuery()) {
                    if (rs2.next()) {
                        usernameField.setText(rs2.getString("username"));
                    }
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Failed to load student profile: " + e.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveUpdatedProfile() {
        String name = nameField.getText().trim();
        String dob = dobField.getText().trim();
        String gender = (String) genderBox.getSelectedItem();
        String bloodGroup = (String) bloodGroupBox.getSelectedItem();
        String phone = phoneField.getText().trim();
        String altPhone = altPhoneField.getText().trim();
        String address = addressArea.getText().trim();
        String city = cityField.getText().trim();
        String state = stateField.getText().trim();
        String pincode = pincodeField.getText().trim();

        String yrStr = (String) currentYearBox.getSelectedItem();
        int year = 1;
        try {
            year = Integer.parseInt(yrStr.substring(0, 1));
        } catch (Exception ignored) {}

        String sem = (String) semesterBox.getSelectedItem();
        String roll = rollNumberField.getText().trim();
        String reg = registerNumberField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || roll.isEmpty() || reg.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Name, Phone, Roll Number, and Register Number cannot be empty.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!phone.matches("^\\d{10}$")) {
            JOptionPane.showMessageDialog(this,
                    "Phone number must be exactly 10 digits.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String sql = "UPDATE student SET student_name = ?, dob = ?, gender = ?, blood_group = ?, "
                + "phone = ?, alt_phone = ?, address = ?, city = ?, state = ?, pincode = ?, "
                + "year = ?, semester = ?, roll_number = ?, register_number = ? "
                + "WHERE student_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, name);
            if (!dob.isEmpty()) {
                ps.setDate(2, java.sql.Date.valueOf(dob));
            } else {
                ps.setNull(2, java.sql.Types.DATE);
            }
            ps.setString(3, gender);
            ps.setString(4, bloodGroup);
            ps.setString(5, phone);
            ps.setString(6, altPhone);
            ps.setString(7, address);
            ps.setString(8, city);
            ps.setString(9, state);
            ps.setString(10, pincode);
            ps.setInt(11, year);
            ps.setString(12, sem);
            ps.setString(13, roll);
            ps.setString(14, reg);
            ps.setString(15, currentStudentId);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try {
                    String dept = departmentField.getText().trim();
                    int admYr = 2025;
                    try {
                        admYr = Integer.parseInt(admissionYearField.getText().trim());
                    } catch (Exception ignored) {
                        admYr = RollNumberManager.resolveAdmissionYear(year, 0);
                    }
                    RollNumberManager.reassignRollNumbers(con, dept, admYr);
                } catch (Exception ignored) {}

                JOptionPane.showMessageDialog(this,
                        "Student Profile Updated Successfully!",
                        "Profile Update", JOptionPane.INFORMATION_MESSAGE);
                setEditMode(false);
                loadStudentProfile();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Could not update profile. Record not found.",
                        "Update Failed", JOptionPane.WARNING_MESSAGE);
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    "Invalid date format for DOB. Please use YYYY-MM-DD.",
                    "Date Format Error", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Database update error: " + e.getMessage(),
                    "System Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
