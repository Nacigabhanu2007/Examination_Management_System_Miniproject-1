package ems;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Modern, Professional Student Registration Form
 * Completely self-contained with no external UI dependencies.
 * Saves complete Personal, Academic, and Account details into MySQL.
 */
public class StudentRegistration extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);
    private final Color TEXT_MUTED = new Color(100, 116, 139);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    // Personal Details
    private JTextField studentIdField;
    private JTextField nameField;
    private JTextField dobField;
    private JRadioButton maleRadio, femaleRadio, otherRadio;
    private JComboBox<String> bloodGroupBox;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField altPhoneField;
    private JTextArea addressArea;
    private JTextField cityField;
    private JTextField stateField;
    private JTextField pincodeField;

    // Academic Details
    private JComboBox<String> departmentBox;
    private JComboBox<String> degreeBox;
    private JComboBox<String> admissionYearBox;
    private JComboBox<String> currentYearBox;
    private JComboBox<String> semesterBox;
    private JTextField rollNumberField;
    private JTextField registerNumberField;

    // Account Details
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JPasswordField confirmPasswordField;
    private JCheckBox showPasswordCheck;
    private JCheckBox declarationCheck;

    public StudentRegistration() {
        setTitle("Examination Management System - Student Registration");
        setSize(920, 850);
        setMinimumSize(new Dimension(850, 700));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header Banner
        JPanel header = createHeader(
                "COLLEGE EXAMINATION MANAGEMENT SYSTEM",
                "Official Student Registration Portal"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Form Container inside ScrollPane
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setBackground(BG_LIGHT);
        formContainer.setBorder(new EmptyBorder(20, 30, 20, 30));

        // 1. PERSONAL DETAILS CARD
        JPanel personalCard = createSectionCard("A. PERSONAL DETAILS");
        JPanel personalGrid = new JPanel(new GridLayout(0, 2, 18, 12));
        personalGrid.setOpaque(false);

        studentIdField = createTextField(false);
        nameField = createTextField(true);
        dobField = createTextField(true);
        dobField.setToolTipText("Format: YYYY-MM-DD (e.g. 2004-05-15)");

        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        genderPanel.setOpaque(false);
        maleRadio = new JRadioButton("Male");
        femaleRadio = new JRadioButton("Female");
        otherRadio = new JRadioButton("Other");
        maleRadio.setFont(FONT_INPUT);
        femaleRadio.setFont(FONT_INPUT);
        otherRadio.setFont(FONT_INPUT);
        maleRadio.setOpaque(false);
        femaleRadio.setOpaque(false);
        otherRadio.setOpaque(false);
        ButtonGroup bg = new ButtonGroup();
        bg.add(maleRadio);
        bg.add(femaleRadio);
        bg.add(otherRadio);
        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        genderPanel.add(otherRadio);

        bloodGroupBox = new JComboBox<>(new String[]{
                "Select Blood Group", "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"
        });
        bloodGroupBox.setFont(FONT_INPUT);

        emailField = createTextField(true);
        phoneField = createTextField(true);
        altPhoneField = createTextField(true);

        addressArea = new JTextArea(3, 20);
        addressArea.setFont(FONT_INPUT);
        addressArea.setLineWrap(true);
        addressArea.setWrapStyleWord(true);
        addressArea.setBorder(BorderFactory.createEmptyBorder(6, 8, 6, 8));
        JScrollPane addressScroll = new JScrollPane(addressArea);
        addressScroll.setBorder(BorderFactory.createLineBorder(BORDER_COLOR));

        cityField = createTextField(true);
        stateField = createTextField(true);
        pincodeField = createTextField(true);

        addFormField(personalGrid, "Student ID (Auto):", studentIdField);
        addFormField(personalGrid, "Full Name *:", nameField);
        addFormField(personalGrid, "Date of Birth (YYYY-MM-DD) *:", dobField);
        addFormField(personalGrid, "Gender *:", genderPanel);
        addFormField(personalGrid, "Blood Group *:", bloodGroupBox);
        addFormField(personalGrid, "Email Address *:", emailField);
        addFormField(personalGrid, "Phone Number (10 digits) *:", phoneField);
        addFormField(personalGrid, "Alternative Phone:", altPhoneField);
        addFormField(personalGrid, "Address *:", addressScroll);
        addFormField(personalGrid, "City *:", cityField);
        addFormField(personalGrid, "State *:", stateField);
        addFormField(personalGrid, "Pincode *:", pincodeField);

        personalCard.add(personalGrid, BorderLayout.CENTER);
        formContainer.add(personalCard);
        formContainer.add(Box.createVerticalStrut(18));

        // 2. ACADEMIC DETAILS CARD
        JPanel academicCard = createSectionCard("B. ACADEMIC DETAILS");
        JPanel academicGrid = new JPanel(new GridLayout(0, 2, 18, 12));
        academicGrid.setOpaque(false);

        departmentBox = new JComboBox<>(loadDepartments());
        departmentBox.setFont(FONT_INPUT);
        departmentBox.addActionListener(e -> {
            generateStudentId();
            updateRollNumberPreview();
        });

        degreeBox = new JComboBox<>(new String[]{
                "Select Degree", "B.E", "B.Tech", "M.E", "M.Tech", "MCA", "B.Sc", "M.Sc"
        });
        degreeBox.setFont(FONT_INPUT);

        admissionYearBox = new JComboBox<>(new String[]{
                "Select Admission Year", "2026", "2025", "2024", "2023", "2022", "2021"
        });
        admissionYearBox.setFont(FONT_INPUT);
        admissionYearBox.addActionListener(e -> {
            syncAcademicYearFromAdmissionYear();
            updateRollNumberPreview();
        });

        currentYearBox = new JComboBox<>(new String[]{
                "Select Current Year", "1st Year", "2nd Year", "3rd Year", "4th Year"
        });
        currentYearBox.setFont(FONT_INPUT);
        currentYearBox.addActionListener(e -> {
            syncAdmissionYearFromAcademicYear();
            updateRollNumberPreview();
        });

        semesterBox = new JComboBox<>(new String[]{
                "Select Semester", "Semester 1", "Semester 2", "Semester 3", "Semester 4",
                "Semester 5", "Semester 6", "Semester 7", "Semester 8"
        });
        semesterBox.setFont(FONT_INPUT);

        rollNumberField = createTextField(false);
        rollNumberField.setText("Auto-generated (Alphabetical)");
        rollNumberField.setToolTipText("Auto-generated by department & admission year in alphabetical order");

        registerNumberField = createTextField(true);

        nameField.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { updateRollNumberPreview(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { updateRollNumberPreview(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { updateRollNumberPreview(); }
        });

        addFormField(academicGrid, "Department *:", departmentBox);
        addFormField(academicGrid, "Degree *:", degreeBox);
        addFormField(academicGrid, "Admission Year *:", admissionYearBox);
        addFormField(academicGrid, "Current Year *:", currentYearBox);
        addFormField(academicGrid, "Semester *:", semesterBox);
        addFormField(academicGrid, "Roll Number *:", rollNumberField);
        addFormField(academicGrid, "Register Number *:", registerNumberField);

        academicCard.add(academicGrid, BorderLayout.CENTER);
        formContainer.add(academicCard);
        formContainer.add(Box.createVerticalStrut(18));

        // 3. ACCOUNT CREDENTIALS CARD
        JPanel accountCard = createSectionCard("C. ACCOUNT CREDENTIALS");
        JPanel accountGrid = new JPanel(new GridLayout(0, 2, 18, 12));
        accountGrid.setOpaque(false);

        usernameField = createTextField(true);
        passwordField = new JPasswordField();
        passwordField.setFont(FONT_INPUT);
        passwordField.setBorder(createFieldBorder());

        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setFont(FONT_INPUT);
        confirmPasswordField.setBorder(createFieldBorder());

        showPasswordCheck = new JCheckBox("Show Password");
        showPasswordCheck.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        showPasswordCheck.setOpaque(false);
        showPasswordCheck.addActionListener(e -> {
            char echo = showPasswordCheck.isSelected() ? (char) 0 : '•';
            passwordField.setEchoChar(echo);
            confirmPasswordField.setEchoChar(echo);
        });

        declarationCheck = new JCheckBox(
                "I confirm that all provided personal and academic details are genuine and correct."
        );
        declarationCheck.setFont(new Font("Segoe UI", Font.BOLD, 12));
        declarationCheck.setForeground(NAVY);
        declarationCheck.setOpaque(false);

        addFormField(accountGrid, "Username *:", usernameField);
        addFormField(accountGrid, "Password *:", passwordField);
        addFormField(accountGrid, "Confirm Password *:", confirmPasswordField);
        addFormField(accountGrid, "", showPasswordCheck);

        JPanel accountWrap = new JPanel(new BorderLayout(0, 10));
        accountWrap.setOpaque(false);
        accountWrap.add(accountGrid, BorderLayout.CENTER);
        accountWrap.add(declarationCheck, BorderLayout.SOUTH);

        accountCard.add(accountWrap, BorderLayout.CENTER);
        formContainer.add(accountCard);

        JScrollPane scrollPane = new JScrollPane(formContainer);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // 4. ACTION BUTTONS PANEL
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 15));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_COLOR));

        JButton registerButton = createButton("Register Account", PRIMARY_BLUE, PRIMARY_HOVER);
        JButton clearButton = createButton("Clear Form", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backButton = createButton("Back to Login", new Color(71, 85, 105), new Color(51, 65, 85));

        registerButton.setPreferredSize(new Dimension(160, 38));
        clearButton.setPreferredSize(new Dimension(130, 38));
        backButton.setPreferredSize(new Dimension(140, 38));

        buttonPanel.add(backButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(registerButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Actions
        registerButton.addActionListener(e -> validateAndRegister());
        clearButton.addActionListener(e -> clearForm());
        backButton.addActionListener(e -> {
            new Login().setVisible(true);
            dispose();
        });

        generateStudentId();

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private Border createFieldBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
        );
    }

    private JTextField createTextField(boolean editable) {
        JTextField tf = new JTextField();
        tf.setFont(FONT_INPUT);
        tf.setEditable(editable);
        tf.setBorder(createFieldBorder());
        if (!editable) {
            tf.setBackground(new Color(241, 245, 249));
            tf.setForeground(TEXT_MUTED);
        }
        return tf;
    }

    private JPanel createSectionCard(String title) {
        JPanel card = new JPanel(new BorderLayout(0, 12));
        card.setBackground(CARD_BG);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(16, 20, 18, 20)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(FONT_HEADER);
        titleLbl.setForeground(PRIMARY_BLUE);

        card.add(titleLbl, BorderLayout.NORTH);
        return card;
    }

    private void addFormField(JPanel panel, String labelText, Component field) {
        JPanel group = new JPanel(new BorderLayout(0, 4));
        group.setOpaque(false);

        JLabel label = new JLabel(labelText);
        label.setFont(FONT_LABEL);
        label.setForeground(TEXT_DARK);

        group.add(label, BorderLayout.NORTH);
        group.add(field, BorderLayout.CENTER);
        panel.add(group);
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (btn.isEnabled()) btn.setBackground(bg);
            }
        });
        return btn;
    }

    private String[] loadDepartments() {
        List<String> list = new ArrayList<>();
        list.add("Select Department");
        String sql = "SELECT department_name FROM department ORDER BY department_name ASC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(rs.getString("department_name"));
            }
        } catch (Exception ignored) {}
        if (list.size() <= 1) {
            list.add("Computer Science and Engineering");
            list.add("Information Technology");
            list.add("Electronics and Communication Engineering");
            list.add("Electrical and Electronic Engineering");
            list.add("Mechanical Engineering");
            list.add("Civil Engineering");
        }
        return list.toArray(new String[0]);
    }

    private void generateStudentId() {
        String dept = (String) departmentBox.getSelectedItem();
        String prefix = "";
        if (dept != null) {
            if (dept.toUpperCase().contains("COMPUTER") || dept.equalsIgnoreCase("CSE")) prefix = "MSCS";
            else if (dept.toUpperCase().contains("INFO") || dept.equalsIgnoreCase("IT")) prefix = "MSIT";
            else if (dept.toUpperCase().contains("ELECTRONIC AND COMMUNICATION") || dept.equalsIgnoreCase("ECE")) prefix = "MSECE";
            else if (dept.toUpperCase().contains("ELECTRICAL") || dept.equalsIgnoreCase("EEE")) prefix = "MSEEE";
            else if (dept.toUpperCase().contains("MECH")) prefix = "MSMECH";
            else if (dept.toUpperCase().contains("CIVIL")) prefix = "MSCIV";
            else if (dept.toUpperCase().contains("ARTIFICIAL")) prefix = "MSAI";
            else if (dept.toUpperCase().contains("BIOTECH")) prefix = "MSBT";
            else if (dept.toUpperCase().contains("BIOMEDICAL")) prefix = "MSBM";
        }

        String sql = "SELECT student_id FROM student WHERE student_id LIKE ? ORDER BY student_id DESC";
        int maxNum = 0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, prefix + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("student_id");
                    if (id != null && id.startsWith(prefix)) {
                        String numPart = id.substring(prefix.length());
                        try {
                            int n = Integer.parseInt(numPart);
                            if (n > maxNum) maxNum = n;
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
        } catch (SQLException ignored) {}
        studentIdField.setText(prefix + String.format("%03d", maxNum + 1));
    }

    private void syncAcademicYearFromAdmissionYear() {
        String adm = (String) admissionYearBox.getSelectedItem();
        if (adm == null || adm.startsWith("Select")) return;
        try {
            int y = Integer.parseInt(adm.trim());
            if (y == 2026 && currentYearBox.getSelectedIndex() != 1) currentYearBox.setSelectedIndex(1); // 1st Year
            else if (y == 2025 && currentYearBox.getSelectedIndex() != 2) currentYearBox.setSelectedIndex(2); // 2nd Year
            else if (y == 2024 && currentYearBox.getSelectedIndex() != 3) currentYearBox.setSelectedIndex(3); // 3rd Year
            else if (y == 2023 && currentYearBox.getSelectedIndex() != 4) currentYearBox.setSelectedIndex(4); // 4th Year
        } catch (Exception ignored) {}
    }

    private void syncAdmissionYearFromAcademicYear() {
        String cy = (String) currentYearBox.getSelectedItem();
        if (cy == null || cy.startsWith("Select")) return;
        if (cy.startsWith("1") && !("2026".equals(admissionYearBox.getSelectedItem()))) admissionYearBox.setSelectedItem("2026");
        else if (cy.startsWith("2") && !("2025".equals(admissionYearBox.getSelectedItem()))) admissionYearBox.setSelectedItem("2025");
        else if (cy.startsWith("3") && !("2024".equals(admissionYearBox.getSelectedItem()))) admissionYearBox.setSelectedItem("2024");
        else if (cy.startsWith("4") && !("2023".equals(admissionYearBox.getSelectedItem()))) admissionYearBox.setSelectedItem("2023");
    }

    private void updateRollNumberPreview() {
        String dept = (String) departmentBox.getSelectedItem();
        String admYearStr = (String) admissionYearBox.getSelectedItem();
        String cyStr = (String) currentYearBox.getSelectedItem();
        String name = nameField.getText().trim();

        if (dept == null || dept.startsWith("Select")) {
            rollNumberField.setText("Auto-generated (Select Dept & Year)");
            return;
        }

        int admYear = 2025;
        if (admYearStr != null && admYearStr.matches("\\d{4}")) {
            admYear = Integer.parseInt(admYearStr);
        } else if (cyStr != null && cyStr.length() > 0 && Character.isDigit(cyStr.charAt(0))) {
            admYear = RollNumberManager.resolveAdmissionYear(Character.getNumericValue(cyStr.charAt(0)), 0);
        }

        String preview = RollNumberManager.previewNextRollNumber(dept, admYear, name);
        rollNumberField.setText(preview);
    }

    private void validateAndRegister() {
        String studentId = studentIdField.getText().trim();
        String fullName = nameField.getText().trim();
        String dob = dobField.getText().trim();
        String bloodGroup = (String) bloodGroupBox.getSelectedItem();
        String email = emailField.getText().trim();
        String phone = phoneField.getText().trim();
        String altPhone = altPhoneField.getText().trim();
        String address = addressArea.getText().trim();
        String city = cityField.getText().trim();
        String state = stateField.getText().trim();
        String pincode = pincodeField.getText().trim();

        String department = (String) departmentBox.getSelectedItem();
        String degree = (String) degreeBox.getSelectedItem();
        String admissionYear = (String) admissionYearBox.getSelectedItem();
        String currentYearStr = (String) currentYearBox.getSelectedItem();
        String semester = (String) semesterBox.getSelectedItem();
        String registerNumber = registerNumberField.getText().trim();

        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());

        // 1. Mandatory Fields Validation
        if (fullName.isEmpty() || dob.isEmpty() || email.isEmpty() || phone.isEmpty()
                || address.isEmpty() || city.isEmpty() || state.isEmpty() || pincode.isEmpty()
                || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fill in all mandatory fields.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (registerNumber.isEmpty()) {
            registerNumber = "REG" + studentId;
        }

        // Gender Check
        String gender = "";
        if (maleRadio.isSelected()) gender = "Male";
        else if (femaleRadio.isSelected()) gender = "Female";
        else if (otherRadio.isSelected()) gender = "Other";
        else {
            JOptionPane.showMessageDialog(this, "Please select a Gender.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Blood Group Check
        if (bloodGroup == null || bloodGroup.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select a valid Blood Group.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Department, Degree, Year, Semester selection check
        if (department == null || department.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select a Department.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (degree == null || degree.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select a Degree.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (admissionYear == null || admissionYear.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select an Admission Year.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (currentYearStr == null || currentYearStr.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select Current Year.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (semester == null || semester.startsWith("Select")) {
            JOptionPane.showMessageDialog(this, "Please select a Semester.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Date of Birth format check (YYYY-MM-DD)
        if (!dob.matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            JOptionPane.showMessageDialog(this,
                    "Date of Birth must be in YYYY-MM-DD format (e.g. 2004-05-15).",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Email validation
        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid email address.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Phone number validation (10 digits)
        if (!phone.matches("^\\d{10}$")) {
            JOptionPane.showMessageDialog(this,
                    "Phone number must be exactly 10 digits.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!altPhone.isEmpty() && !altPhone.matches("^\\d{10}$")) {
            JOptionPane.showMessageDialog(this,
                    "Alternative phone number must be 10 digits if provided.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Password strength validation: >= 8 chars, 1 uppercase, 1 lowercase, 1 digit, 1 special character
        if (password.length() < 8
                || !password.matches(".*[A-Z].*")
                || !password.matches(".*[a-z].*")
                || !password.matches(".*\\d.*")
                || !password.matches(".*[^A-Za-z0-9].*")) {
            JOptionPane.showMessageDialog(this,
                    "Password does not meet strength requirements:\n"
                            + "• Minimum 8 characters\n"
                            + "• At least one uppercase letter (A-Z)\n"
                            + "• At least one lowercase letter (a-z)\n"
                            + "• At least one numeric digit (0-9)\n"
                            + "• At least one special character (!@#$%^&*...)",
                    "Password Requirements", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Password confirmation
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                    "Password and Confirm Password do not match.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Declaration check
        if (!declarationCheck.isSelected()) {
            JOptionPane.showMessageDialog(this,
                    "Please check the declaration box to confirm your details.",
                    "Declaration Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Parse numerical values
        int currentYear = 1;
        try {
            currentYear = Integer.parseInt(currentYearStr.substring(0, 1));
        } catch (Exception ignored) {}

        int admYearVal = 2025;
        if (admissionYear != null && admissionYear.matches("\\d{4}")) {
            admYearVal = Integer.parseInt(admissionYear);
        } else {
            admYearVal = RollNumberManager.resolveAdmissionYear(currentYear, 0);
        }

        String initialRoll = RollNumberManager.previewNextRollNumber(department, admYearVal, fullName);

        // 2. Duplicate Checks: Check email, username, student_id
        try (Connection con = DBConnection.getConnection()) {
            if (con == null) {
                JOptionPane.showMessageDialog(this, "Database connection unavailable.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check email in users
            String checkEmailSQL = "SELECT email FROM users WHERE email = ?";
            try (PreparedStatement ps = con.prepareStatement(checkEmailSQL)) {
                ps.setString(1, email);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this,
                                "An account with email '" + email + "' already exists.",
                                "Duplicate Record", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // Check username in users
            String checkUserSQL = "SELECT username FROM users WHERE username = ?";
            try (PreparedStatement ps = con.prepareStatement(checkUserSQL)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this,
                                "Username '" + username + "' is already taken. Please choose another.",
                                "Duplicate Record", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            // Check student_id in student
            String checkIdSQL = "SELECT student_id FROM student WHERE student_id = ?";
            try (PreparedStatement ps = con.prepareStatement(checkIdSQL)) {
                ps.setString(1, studentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        generateStudentId();
                        studentId = studentIdField.getText().trim();
                    }
                }
            }

            // 3. Insert in Transaction: student and users tables
            con.setAutoCommit(false);

            String insertStudentSQL =
                    "INSERT INTO student "
                    + "(student_id, student_name, department, year, email, phone, roll_number, "
                    + "address, gender, dob, blood_group, alt_phone, city, state, pincode, "
                    + "degree, admission_year, semester, register_number) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            String insertUserSQL =
                    "INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, 'Student')";

            try {
                try (PreparedStatement ps = con.prepareStatement(insertStudentSQL)) {
                    ps.setString(1, studentId);
                    ps.setString(2, fullName);
                    ps.setString(3, department);
                    ps.setInt(4, currentYear);
                    ps.setString(5, email);
                    ps.setString(6, phone);
                    ps.setString(7, initialRoll);
                    ps.setString(8, address);
                    ps.setString(9, gender);
                    ps.setString(10, dob);
                    ps.setString(11, bloodGroup);
                    ps.setString(12, altPhone);
                    ps.setString(13, city);
                    ps.setString(14, state);
                    ps.setString(15, pincode);
                    ps.setString(16, degree);
                    ps.setInt(17, admYearVal);
                    ps.setString(18, semester);
                    ps.setString(19, registerNumber);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = con.prepareStatement(insertUserSQL)) {
                    ps.setString(1, username);
                    ps.setString(2, email);
                    ps.setString(3, hashPassword(password));
                    ps.executeUpdate();
                }

                // Reassign roll numbers alphabetically for this department and admission year
                RollNumberManager.reassignRollNumbers(con, department, admYearVal);

                String finalRoll = initialRoll;
                try (PreparedStatement psRoll = con.prepareStatement("SELECT roll_number FROM student WHERE student_id = ?")) {
                    psRoll.setString(1, studentId);
                    try (ResultSet rsRoll = psRoll.executeQuery()) {
                        if (rsRoll.next()) {
                            String r = rsRoll.getString("roll_number");
                            if (r != null && !r.trim().isEmpty()) finalRoll = r.trim();
                        }
                    }
                }

                con.commit();

                JOptionPane.showMessageDialog(this,
                        "Registration Successful!\n\n"
                                + "Student ID: " + studentId + "\n"
                                + "Roll Number: " + finalRoll + "\n"
                                + "Username: " + username + "\n"
                                + "Email: " + email + "\n\n"
                                + "You can now login with your credentials.",
                        "Registration Completed", JOptionPane.INFORMATION_MESSAGE);

                clearForm();
                new Login().setVisible(true);
                dispose();

            } catch (SQLException ex) {
                con.rollback();
                JOptionPane.showMessageDialog(this,
                        "Registration failed during database save: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Database connection error: " + e.getMessage(),
                    "System Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        nameField.setText("");
        dobField.setText("");
        maleRadio.setSelected(false);
        femaleRadio.setSelected(false);
        otherRadio.setSelected(false);
        bloodGroupBox.setSelectedIndex(0);
        emailField.setText("");
        phoneField.setText("");
        altPhoneField.setText("");
        addressArea.setText("");
        cityField.setText("");
        stateField.setText("");
        pincodeField.setText("");

        departmentBox.setSelectedIndex(0);
        degreeBox.setSelectedIndex(0);
        admissionYearBox.setSelectedIndex(0);
        currentYearBox.setSelectedIndex(0);
        semesterBox.setSelectedIndex(0);
        rollNumberField.setText("");
        registerNumberField.setText("");

        usernameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        showPasswordCheck.setSelected(false);
        declarationCheck.setSelected(false);

        passwordField.setEchoChar('•');
        confirmPasswordField.setEchoChar('•');
        generateStudentId();
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte b : hash) {
                result.append(String.format("%02x", b));
            }
            return result.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
