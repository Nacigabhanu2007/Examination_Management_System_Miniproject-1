package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Subject extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private DefaultTableModel model;
    private String userEmail = "";
    private JLabel title;

    public Subject() {
        this("");
    }

    public Subject(String userEmail) {
        this.userEmail = (userEmail != null) ? userEmail.trim() : "";

        setTitle("Examination Management System - Curriculum Subjects & Classes");
        setSize(780, 540);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        title = new JLabel("AVAILABLE CURRICULUM SUBJECTS");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);

        header.add(title, BorderLayout.WEST);
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Subject Table
        String[] columns = {
            "Subject ID", "Subject Name", "Department", "Semester", "Credits"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable subjectTable = new JTable(model);
        subjectTable.setFont(FONT_INPUT);
        subjectTable.setRowHeight(32);
        subjectTable.setGridColor(BORDER_COLOR);
        subjectTable.setShowGrid(true);
        subjectTable.setSelectionBackground(new Color(219, 234, 254));
        subjectTable.setSelectionForeground(TEXT_DARK);

        JTableHeader tableHeader = subjectTable.getTableHeader();
        tableHeader.setFont(FONT_HEADER);
        tableHeader.setBackground(new Color(241, 245, 249));
        tableHeader.setForeground(TEXT_DARK);
        tableHeader.setReorderingAllowed(false);
        tableHeader.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        subjectTable.setDefaultRenderer(Object.class, center);

        JScrollPane scrollPane = new JScrollPane(subjectTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Bottom Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 12));
        bottomPanel.setBackground(BG_LIGHT);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setFont(FONT_BTN);
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setBackground(PRIMARY_BLUE);
        refreshButton.setFocusPainted(false);
        refreshButton.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        refreshButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        refreshButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                refreshButton.setBackground(PRIMARY_HOVER);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                refreshButton.setBackground(PRIMARY_BLUE);
            }
        });

        JButton backButton = new JButton("Back to Dashboard");
        backButton.setFont(FONT_BTN);
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(71, 85, 105));
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        backButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        backButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                backButton.setBackground(new Color(51, 65, 85));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                backButton.setBackground(new Color(71, 85, 105));
            }
        });

        bottomPanel.add(refreshButton);
        bottomPanel.add(backButton);
        contentPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);

        // Actions
        backButton.addActionListener(e -> dispose());
        refreshButton.addActionListener(e -> loadClassesFromDB());

        loadClassesFromDB();

        setVisible(true);
    }

    private void loadClassesFromDB() {
        model.setRowCount(0);

        String deptFilter = "";
        String roleInfo = "";

        if (!userEmail.isEmpty()) {
            // Check student first
            String stuSql = "SELECT department, year, semester FROM student WHERE email = ?";
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement(stuSql)) {
                ps.setString(1, userEmail);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        deptFilter = rs.getString("department");
                        int yr = rs.getInt("year");
                        roleInfo = " (Student: " + deptFilter + (yr > 0 ? ", Year " + yr : "") + ")";
                    }
                }
            } catch (SQLException ignored) {}

            // If not found in student, check faculty
            if (deptFilter.isEmpty()) {
                String facSql = "SELECT department FROM faculty WHERE email = ?";
                try (Connection con = DBConnection.getConnection();
                     PreparedStatement ps = con.prepareStatement(facSql)) {
                    ps.setString(1, userEmail);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            deptFilter = rs.getString("department");
                            roleInfo = " (Faculty: " + deptFilter + ")";
                        }
                    }
                } catch (SQLException ignored) {}
            }
        }

        if (!roleInfo.isEmpty()) {
            title.setText("CURRICULUM CLASSES" + roleInfo.toUpperCase());
        } else {
            title.setText("AVAILABLE CURRICULUM SUBJECTS & CLASSES");
        }

        String sql;
        boolean hasFilter = (deptFilter != null && !deptFilter.trim().isEmpty());

        if (hasFilter) {
            sql = "SELECT subject_id, subject_name, department_id, semester, credits "
                + "FROM subject "
                + "WHERE department_id = ? OR department_id LIKE ? "
                + "ORDER BY semester, subject_id";
        } else {
            sql = "SELECT subject_id, subject_name, department_id, semester, credits "
                + "FROM subject "
                + "ORDER BY semester, subject_id";
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (hasFilter) {
                ps.setString(1, deptFilter.trim());
                ps.setString(2, "%" + deptFilter.trim().substring(0, Math.min(2, deptFilter.trim().length())) + "%");
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("subject_id"),
                        rs.getString("subject_name"),
                        rs.getString("department_id"),
                        "Semester " + rs.getInt("semester"),
                        rs.getDouble("credits")
                    });
                }
            }

            // Fallback: If filtered returned 0 rows, load all subjects so student/faculty still see curriculum
            if (model.getRowCount() == 0 && hasFilter) {
                String allSql = "SELECT subject_id, subject_name, department_id, semester, credits FROM subject ORDER BY semester, subject_id";
                try (PreparedStatement allPs = con.prepareStatement(allSql);
                     ResultSet allRs = allPs.executeQuery()) {
                    while (allRs.next()) {
                        model.addRow(new Object[]{
                            allRs.getString("subject_id"),
                            allRs.getString("subject_name"),
                            allRs.getString("department_id"),
                            "Semester " + allRs.getInt("semester"),
                            allRs.getDouble("credits")
                        });
                    }
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading classes from database: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Subject::new);
    }
}
