package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Subjects extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTable subjectTable;
    private DefaultTableModel model;
    private JComboBox<String> departmentFilter;
    private JComboBox<String> semesterFilter;
    private String userEmail = "";
    private boolean isPopulating = false;

    public Subjects() {
        this("");
    }

    public Subjects(String userEmail) {
        this.userEmail = (userEmail != null) ? userEmail.trim() : "";

        setTitle("Examination Management System - Available Curriculum Subjects & Classes");
        setSize(1020, 640);
        setMinimumSize(new Dimension(880, 520));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header Panel
        JPanel header = createHeader(
                "CURRICULUM COURSES & SUBJECTS",
                "Browse syllabus offerings, course codes, semester mappings, and degree credits"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Filter Bar Card
        JPanel filterBar = new JPanel(new BorderLayout());
        filterBar.setBackground(CARD_BG);
        filterBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1),
                new EmptyBorder(10, 15, 10, 15)
        ));

        JPanel filterGroup = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        filterGroup.setOpaque(false);

        JLabel filterLabel = new JLabel("Department Filter:");
        filterLabel.setFont(FONT_LABEL);
        filterLabel.setForeground(TEXT_DARK);

        departmentFilter = new JComboBox<>();
        departmentFilter.setFont(FONT_INPUT);
        departmentFilter.setPreferredSize(new Dimension(280, 36));

        JLabel semLabel = new JLabel("Semester:");
        semLabel.setFont(FONT_LABEL);
        semLabel.setForeground(TEXT_DARK);

        semesterFilter = new JComboBox<>(new String[]{
            "All Semesters", "Semester 1", "Semester 2", "Semester 3",
            "Semester 4", "Semester 5", "Semester 6", "Semester 7", "Semester 8"
        });
        semesterFilter.setFont(FONT_INPUT);
        semesterFilter.setPreferredSize(new Dimension(150, 36));

        JButton refreshButton = createButton("Refresh", SECONDARY_GRAY, SECONDARY_HOVER);

        filterGroup.add(filterLabel);
        filterGroup.add(departmentFilter);
        filterGroup.add(semLabel);
        filterGroup.add(semesterFilter);
        filterGroup.add(refreshButton);
        filterBar.add(filterGroup, BorderLayout.WEST);

        contentPanel.add(filterBar, BorderLayout.NORTH);

        // Table
        String[] columns = {"Subject ID", "Subject Name", "Department ID", "Semester", "Credits"};
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        subjectTable = new JTable(model);
        styleTable(subjectTable);

        JScrollPane scrollPane = new JScrollPane(subjectTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        bottomPanel.setBackground(BG_LIGHT);

        JButton backButton = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));
        bottomPanel.add(backButton);
        contentPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);

        // Action Listeners
        backButton.addActionListener(e -> dispose());
        refreshButton.addActionListener(e -> loadSubjects());
        departmentFilter.addActionListener(e -> {
            if (!isPopulating) loadSubjects();
        });
        semesterFilter.addActionListener(e -> {
            if (!isPopulating) loadSubjects();
        });

        loadDepartments();
        loadSubjects();

        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private boolean matchDeptItem(String item, String targetDept) {
        if (item == null || targetDept == null) return false;
        String iLow = item.toLowerCase();
        String tLow = targetDept.trim().toLowerCase();
        if (tLow.isEmpty()) return false;
        if (iLow.startsWith(tLow) || iLow.contains(tLow)) return true;

        if (tLow.startsWith("cs") && (iLow.contains("computer science") || iLow.contains("cs5496") || iLow.contains("cse"))) return true;
        if (tLow.startsWith("ec") && (iLow.contains("electronic and comm") || iLow.contains("ec7323") || iLow.contains("ece"))) return true;
        if (tLow.startsWith("ee") && (iLow.contains("electrical") || iLow.contains("ee3594") || iLow.contains("eee"))) return true;
        if (tLow.startsWith("it") && (iLow.contains("information tech") || iLow.contains("it2257"))) return true;
        if (tLow.startsWith("me") && (iLow.contains("mechanical") || iLow.contains("me6547"))) return true;

        return false;
    }

    private void loadDepartments() {
        isPopulating = true;
        departmentFilter.removeAllItems();
        departmentFilter.addItem("All Departments");

        String sql = "SELECT department_id, department_name FROM department ORDER BY department_id";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                departmentFilter.addItem(rs.getString("department_id") + " - " + rs.getString("department_name"));
            }

            if (!userEmail.isEmpty()) {
                String userDept = "";

                // Check student
                String stuSql = "SELECT department FROM student WHERE email = ?";
                try (PreparedStatement stuPs = con.prepareStatement(stuSql)) {
                    stuPs.setString(1, userEmail);
                    try (ResultSet stuRs = stuPs.executeQuery()) {
                        if (stuRs.next()) {
                            userDept = stuRs.getString("department");
                        }
                    }
                }

                // If not student, check faculty
                if (userDept == null || userDept.isEmpty()) {
                    String facSql = "SELECT department FROM faculty WHERE email = ?";
                    try (PreparedStatement facPs = con.prepareStatement(facSql)) {
                        facPs.setString(1, userEmail);
                        try (ResultSet facRs = facPs.executeQuery()) {
                            if (facRs.next()) {
                                userDept = facRs.getString("department");
                            }
                        }
                    }
                }

                if (userDept != null && !userDept.isEmpty()) {
                    for (int i = 0; i < departmentFilter.getItemCount(); i++) {
                        String item = departmentFilter.getItemAt(i);
                        if (matchDeptItem(item, userDept)) {
                            departmentFilter.setSelectedIndex(i);
                            break;
                        }
                    }
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading departments: " + ex.getMessage());
        } finally {
            isPopulating = false;
        }
    }

    private void loadSubjects() {
        model.setRowCount(0);

        String selected = (String) departmentFilter.getSelectedItem();
        String filterDept = "";
        if (selected != null && !selected.equals("All Departments")) {
            filterDept = selected.split(" - ")[0].trim();
        }

        String semSelected = (String) semesterFilter.getSelectedItem();
        int filterSem = -1;
        if (semSelected != null && semSelected.startsWith("Semester ")) {
            try {
                filterSem = Integer.parseInt(semSelected.replace("Semester ", "").trim());
            } catch (NumberFormatException ignored) {}
        }

        StringBuilder sql = new StringBuilder("SELECT subject_id, subject_name, department_id, semester, credits FROM subject WHERE 1=1 ");
        if (!filterDept.isEmpty()) {
            sql.append("AND department_id = ? ");
        }
        if (filterSem > 0) {
            sql.append("AND semester = ? ");
        }
        sql.append("ORDER BY semester, subject_id");

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {

            int paramIndex = 1;
            if (!filterDept.isEmpty()) {
                ps.setString(paramIndex++, filterDept);
            }
            if (filterSem > 0) {
                ps.setInt(paramIndex++, filterSem);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("subject_id"),
                        rs.getString("subject_name"),
                        rs.getString("department_id"),
                        "Semester " + rs.getInt("semester"),
                        rs.getDouble("credits")
                    });
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading subjects: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Subjects::new);
    }
}
