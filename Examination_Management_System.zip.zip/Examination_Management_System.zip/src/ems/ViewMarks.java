package ems;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewMarks extends JFrame {

    private static final long serialVersionUID = 1L;

    // Theme Palette
    private final Color NAVY = new Color(22, 40, 75);
    private final Color PRIMARY_BLUE = new Color(30, 64, 124);
    private final Color PRIMARY_HOVER = new Color(42, 85, 160);
    private final Color SECONDARY_GRAY = new Color(100, 116, 139);
    private final Color SECONDARY_HOVER = new Color(71, 85, 105);
    private final Color BG_LIGHT = new Color(246, 248, 252);
    private final Color CARD_BG = Color.WHITE;
    private final Color BORDER_COLOR = new Color(226, 232, 240);
    private final Color TEXT_DARK = new Color(15, 23, 42);

    // Fonts
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 13);
    private final Font FONT_INPUT = new Font("Segoe UI", Font.PLAIN, 13);
    private final Font FONT_BTN = new Font("Segoe UI", Font.BOLD, 13);

    private JTable table;
    private DefaultTableModel model;
    private JLabel messageLabel;
    private String studentEmail = "";

    public ViewMarks() {
        this("");
    }

    public ViewMarks(String studentEmail) {
        this.studentEmail = studentEmail;

        setTitle("Examination Management System - Student Subject Marks");
        setSize(1050, 620);
        setMinimumSize(new Dimension(880, 500));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BG_LIGHT);

        // Header
        JPanel header = createHeader(
                "STUDENT EXAMINATION MARKS & SCORES",
                "Review subject-wise marks obtained, maximum scale marks, percentages, and faculty remarks"
        );
        mainPanel.add(header, BorderLayout.NORTH);

        // Content Area
        JPanel contentPanel = new JPanel(new BorderLayout(15, 15));
        contentPanel.setBackground(BG_LIGHT);
        contentPanel.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Table
        String[] columns = {
            "Mark ID", "Exam ID", "Exam Name", "Subject ID", "Subject Name", "Marks Obtained", "Max Marks", "Percentage", "Remarks"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        styleTable(table);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));

        messageLabel = new JLabel("", JLabel.CENTER);
        messageLabel.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        messageLabel.setForeground(new Color(185, 28, 28));
        messageLabel.setBorder(new EmptyBorder(6, 0, 6, 0));

        JPanel centerPanel = new JPanel(new BorderLayout(0, 5));
        centerPanel.setOpaque(false);
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        centerPanel.add(messageLabel, BorderLayout.SOUTH);

        contentPanel.add(centerPanel, BorderLayout.CENTER);

        // Bottom
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        bottomPanel.setBackground(BG_LIGHT);

        JButton refreshBtn = createButton("Refresh", SECONDARY_GRAY, SECONDARY_HOVER);
        JButton backButton = createButton("Back to Dashboard", new Color(71, 85, 105), new Color(51, 65, 85));

        bottomPanel.add(refreshBtn);
        bottomPanel.add(backButton);
        contentPanel.add(bottomPanel, BorderLayout.SOUTH);

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);

        backButton.addActionListener(e -> dispose());
        refreshBtn.addActionListener(e -> loadMarks());

        loadMarks();
        setVisible(true);
    }

    private JPanel createHeader(String title, String subtitle) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(18, 25, 18, 25));

        JPanel textPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        textPanel.setOpaque(false);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLbl.setForeground(Color.WHITE);

        JLabel subLbl = new JLabel(subtitle);
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subLbl.setForeground(new Color(203, 213, 225));

        textPanel.add(titleLbl);
        textPanel.add(subLbl);
        header.add(textPanel, BorderLayout.WEST);
        return header;
    }

    private JButton createButton(String text, Color bg, Color hover) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BTN);
        btn.setForeground(Color.WHITE);
        btn.setBackground(bg);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleTable(JTable table) {
        table.setFont(FONT_INPUT);
        table.setRowHeight(30);
        table.setGridColor(BORDER_COLOR);
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(TEXT_DARK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_HEADER);
        header.setBackground(new Color(241, 245, 249));
        header.setForeground(TEXT_DARK);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 36));

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, center);
    }

    private void loadMarks() {
        model.setRowCount(0);
        messageLabel.setText("");

        String studentId = "";
        if (studentEmail != null && !studentEmail.trim().isEmpty()) {
            try (Connection con = DBConnection.getConnection();
                 PreparedStatement ps = con.prepareStatement("SELECT student_id FROM student WHERE email = ?")) {
                ps.setString(1, studentEmail.trim());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        studentId = rs.getString("student_id");
                    }
                }
            } catch (SQLException ex) {
                // ignore
            }
        }

        String sql;
        boolean filterStudent = !studentId.isEmpty();

        if (filterStudent) {
            sql = "SELECT m.mark_id, m.exam_id, e.exam_name, m.subject_id, s.subject_name, "
                + "m.marks_obtained, m.max_marks, m.remarks "
                + "FROM marks m "
                + "JOIN exam e ON m.exam_id = e.exam_id "
                + "JOIN subject s ON m.subject_id = s.subject_id "
                + "WHERE m.student_id = ? "
                + "ORDER BY m.mark_id DESC";
        } else {
            sql = "SELECT m.mark_id, m.exam_id, e.exam_name, m.subject_id, s.subject_name, "
                + "m.marks_obtained, m.max_marks, m.remarks "
                + "FROM marks m "
                + "JOIN exam e ON m.exam_id = e.exam_id "
                + "JOIN subject s ON m.subject_id = s.subject_id "
                + "ORDER BY m.mark_id DESC";
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (filterStudent) {
                ps.setString(1, studentId);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    double obt = rs.getDouble("marks_obtained");
                    double max = rs.getDouble("max_marks");
                    double pct = (max > 0) ? (obt / max) * 100.0 : 0.0;

                    model.addRow(new Object[]{
                        rs.getInt("mark_id"),
                        rs.getString("exam_id"),
                        rs.getString("exam_name"),
                        rs.getString("subject_id"),
                        rs.getString("subject_name"),
                        obt,
                        max,
                        String.format("%.1f%%", pct),
                        rs.getString("remarks")
                    });
                }
            }

            if (model.getRowCount() == 0) {
                messageLabel.setText(filterStudent
                    ? "No Marks Available Yet for Student ID: " + studentId
                    : "No Marks Found in the System.");
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading marks: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ViewMarks::new);
    }
}
