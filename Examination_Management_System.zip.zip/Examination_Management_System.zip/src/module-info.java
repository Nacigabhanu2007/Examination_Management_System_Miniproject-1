/**
 * 
 */
/**
 * 
 */
module ExaminationManagementSystem {
	requires java.desktop;
	requires transitive java.sql;
	requires jdk.httpserver;
	exports ems;
}
